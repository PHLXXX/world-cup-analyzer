# 世界杯分析终端

这是一个可本地运行、也可部署成公网产品的世界杯赛事分析工具。后端实时抓取 football-data 官方赛程/名单、场馆、天气、海拔、阵容伤停新闻、盘口/推荐网页摘要，并用透明的 Poisson 启发式模型输出比分预测和推荐倾向。

部署到云平台后，会得到一个公网链接。访问者打开链接即可直接使用，不需要安装软件，也不需要填写 API Key。

## 产品化部署

项目已包含：

- `Dockerfile`：通用容器部署
- `render.yaml`：Render Blueprint 部署
- `Procfile`：支持 Procfile 的 Node Web 平台
- `.env.example`：生产环境变量模板
- `DEPLOY.md`：公网部署步骤

最直接的正式分享方式：

1. 把本目录推送到 GitHub 仓库。
2. 在 Render、Railway、Fly.io 或其他 Node/Docker 平台部署。
3. 在平台环境变量中配置 `FOOTBALL_DATA_API_KEY` 和 `ODDS_API_KEY`。
4. 将平台生成的 `https://...` 地址分享给别人。

长期在线部署步骤见 [DEPLOY-LONGTERM.md](./DEPLOY-LONGTERM.md)。

## 启动

本地使用时推荐直接双击项目目录里的：

```text
Open-WorldCupAnalyzer.cmd
```

或者桌面的：

```text
World Cup Analyzer
```

启动器会自动检查 `5177` 端口，如果服务没运行就后台启动，然后打开：

```text
http://127.0.0.1:5177/
```

不会开机自启。需要使用时双击桌面快捷方式或项目目录中的启动脚本即可。

开发模式备用命令：

```powershell
npm.cmd install
npm.cmd start
```

健康检查：

```text
http://127.0.0.1:5177/api/health
```

## 数据源

- football-data.org：世界杯赛程、球队、26 人名单、教练、比赛状态
- `worldcup26.ir/get/games`：球场和本地开球时间补充
- Open-Meteo：比赛日逐小时天气、海拔
- OpenStreetMap Nominatim：球场/城市地理编码
- Bing News RSS：赛前新闻、阵容伤停、盘口/预测文章
- DuckDuckGo HTML Search：阵容、伤停、盘口推荐、球场情况的网页搜索和摘要抓取
- ESPN Soccer API：近期状态、赛前链接、ESPN/DraftKings 盘口摘要
- The Odds API：可选，部署时配置 `ODDS_API_KEY` 后获取结构化实时赔率均值

## 说明

未配置 The Odds API Key 时，盘口部分来自网页搜索和可抓取正文，可信度低于结构化赔率 API。工具会展示来源链接和抓取摘要，便于人工复核。

预测结果仅用于赛前研究，不构成投注建议。
