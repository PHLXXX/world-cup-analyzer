@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-PublicWorldCupAnalyzer.ps1"
if errorlevel 1 (
  echo.
  echo Public sharing failed. Please send the error above to Codex.
  pause
  exit /b 1
)
echo.
echo The public link has been saved to public-url.txt.
echo Keep this window or the tunnel process running while sharing the link.
pause
