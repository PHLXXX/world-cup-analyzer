param(
  [int]$Port = 5177
)

$ErrorActionPreference = "Stop"

$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$StartScript = Join-Path $AppDir "Start-WorldCupAnalyzer.ps1"
$RunId = Get-Date -Format "yyyyMMdd-HHmmss"
$OutLog = Join-Path $AppDir "tunnelmole-$RunId.out.log"
$ErrLog = Join-Path $AppDir "tunnelmole-$RunId.err.log"
$PublicInfo = Join-Path $AppDir "public-url.txt"
$RunLog = Join-Path $AppDir "public-share-run.log"

function Write-RunLog {
  param([string]$Message)
  Add-Content -LiteralPath $RunLog -Value "$(Get-Date -Format o) $Message" -Encoding UTF8
}

function Find-Npx {
  $cmd = Get-Command npx.cmd -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  $cmd = Get-Command npx -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  throw "npx was not found. Install Node.js/npm first."
}

function Stop-OldPublicTunnels {
  $old = Get-CimInstance Win32_Process |
    Where-Object {
      $_.Name -match "node|cmd" -and
      $_.CommandLine -match "localtunnel|lt\.js|tunnelmole" -and
      $_.CommandLine -notmatch "Get-CimInstance"
    }

  foreach ($process in $old) {
    try {
      Stop-Process -Id $process.ProcessId -Force -ErrorAction Stop
      Write-RunLog "stopped old tunnel process $($process.ProcessId)"
    } catch {
      Write-RunLog "failed to stop old tunnel process $($process.ProcessId): $($_.Exception.Message)"
    }
  }
}

function Read-TunnelUrl {
  if (-not (Test-Path $OutLog)) { return "" }
  try {
    $text = Get-Content -LiteralPath $OutLog -Raw -ErrorAction Stop
  } catch {
    return ""
  }
  if ([string]::IsNullOrWhiteSpace($text)) { return "" }

  $match = [regex]::Match($text, "https://[a-z0-9-]+\.tunnelmole\.net")
  if ($match.Success) { return $match.Value }
  return ""
}

function Test-PublicUrl {
  param([string]$Url)
  try {
    $response = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 25
    return $response.StatusCode -eq 200 -and $response.Content -match "app\.js|/api/matches|root"
  } catch {
    Write-RunLog "public url verification failed: $($_.Exception.Message)"
    return $false
  }
}

if (-not (Test-Path $StartScript)) {
  throw "Start-WorldCupAnalyzer.ps1 was not found in $AppDir"
}

Write-RunLog "starting local analyzer"
powershell -NoProfile -ExecutionPolicy Bypass -File $StartScript -NoBrowser
Write-RunLog "local analyzer start command finished with $LASTEXITCODE"

Stop-OldPublicTunnels

Set-Content -LiteralPath $OutLog -Value "" -Encoding UTF8
Set-Content -LiteralPath $ErrLog -Value "" -Encoding UTF8

$npx = Find-Npx
Write-RunLog "starting tunnelmole with $npx"
Start-Process `
  -FilePath $npx `
  -ArgumentList @("--yes", "tunnelmole", "$Port") `
  -WorkingDirectory $AppDir `
  -RedirectStandardOutput $OutLog `
  -RedirectStandardError $ErrLog `
  -WindowStyle Hidden
Write-RunLog "tunnelmole process started"

$deadline = (Get-Date).AddSeconds(90)
$url = ""
while ((Get-Date) -lt $deadline) {
  $url = Read-TunnelUrl
  if ($url) { break }
  Start-Sleep -Milliseconds 800
}

if (-not $url) {
  $err = ""
  if (Test-Path $ErrLog) {
    $err = (Get-Content -LiteralPath $ErrLog -Tail 60 -ErrorAction SilentlyContinue) -join "`n"
  }
  throw "Public tunnel startup timed out. Error log:`n$err"
}

$verified = $false
$verifyDeadline = (Get-Date).AddSeconds(70)
while ((Get-Date) -lt $verifyDeadline) {
  if (Test-PublicUrl -Url $url) {
    $verified = $true
    break
  }
  Start-Sleep -Seconds 3
}

$status = if ($verified) { "verified" } else { "not verified yet" }
$content = @"
World Cup Analyzer public URL

URL:
$url

Status:
$status

Notes:
- Keep this computer on.
- Keep the World Cup Analyzer and tunnelmole process running.
- This is a temporary public link. For a permanent product link, deploy the app to Render, Railway, Fly.io, or Cloudflare.
"@

Set-Content -LiteralPath $PublicInfo -Value $content -Encoding UTF8
Write-RunLog "public info written to $PublicInfo with status $status"

Write-Host ""
Write-Host "Public URL:"
Write-Host $url
Write-Host ""
Write-Host "Status:"
Write-Host $status
Write-Host ""
Write-Host "Saved to:"
Write-Host $PublicInfo
