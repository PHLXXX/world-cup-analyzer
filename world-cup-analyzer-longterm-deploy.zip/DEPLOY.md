# 公网部署说明

目标：部署后得到一个公网 URL，任何人打开链接即可直接使用。

## 推荐方式：Render Blueprint

1. 将 `outputs/world-cup-analyzer` 目录推送到 GitHub 仓库。
2. 登录 Render，选择 New Blueprint，并连接这个仓库。
3. Render 会读取 `render.yaml`，自动安装依赖并启动 `npm start`。
4. 在 Render 服务的 Environment 中配置：
   - `FOOTBALL_DATA_API_KEY`：可选，用于更完整的赛程/球队数据。
   - `ODDS_API_KEY`：可选，用于 The Odds API 结构化赔率。
5. 部署完成后，Render 会生成一个 `https://...` 的公网地址，把这个地址发给别人即可。

## 通用 Docker 部署

任何支持 Docker Web 服务的平台都可以用：

```bash
docker build -t world-cup-analyzer .
docker run -p 5177:5177 --env-file .env world-cup-analyzer
```

云平台需要设置端口环境变量时，使用平台分配的 `PORT`；本应用会自动读取 `PORT`。

## 本地临时公网链接

如果只是临时演示，可以在本机服务运行后使用 Cloudflare Tunnel、ngrok 或 localtunnel 暴露 `http://127.0.0.1:5177`。这种方式依赖你的电脑和隧道进程一直在线，不适合作为正式产品链接。

## 生产注意事项

- 不要把 `.env` 提交到仓库。
- API Key 只放在云平台环境变量里，不显示给访问者。
- `/api/analyze` 已加基础限流，默认每个 IP 每 15 分钟 120 次。
- 历史推荐统计文件保存在 `data/prediction-history.json`。如果云平台文件系统重启后会清空，需要配置持久磁盘或后续接数据库。
