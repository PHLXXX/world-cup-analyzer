const state = {
  matches: [],
  filtered: [],
  selectedTab: "odds",
  lastAnalysis: null,
  activeAnalysisId: 0,
  activeController: null,
  autoAnalyzeTimer: null,
  historyController: null,
  historyLoadedAt: 0,
  prefetchTimer: null,
  backgroundRefreshTimer: null,
  prefetching: new Set(),
  analysisCache: new Map(),
};

const TEAM_ZH = {
  ALG: "阿尔及利亚",
  ARG: "阿根廷",
  AUS: "澳大利亚",
  AUT: "奥地利",
  BOL: "玻利维亚",
  BEL: "比利时",
  BIH: "波黑",
  BRA: "巴西",
  CAN: "加拿大",
  CHI: "智利",
  CPV: "佛得角",
  COL: "哥伦比亚",
  COD: "刚果（金）",
  CRO: "克罗地亚",
  CUW: "库拉索",
  CZE: "捷克",
  DEN: "丹麦",
  ECU: "厄瓜多尔",
  EGY: "埃及",
  ENG: "英格兰",
  FIN: "芬兰",
  FRA: "法国",
  GER: "德国",
  GHA: "加纳",
  GRE: "希腊",
  HAI: "海地",
  HON: "洪都拉斯",
  HUN: "匈牙利",
  IRN: "伊朗",
  IRQ: "伊拉克",
  IRL: "爱尔兰",
  ISR: "以色列",
  ITA: "意大利",
  CIV: "科特迪瓦",
  JPN: "日本",
  JOR: "约旦",
  KSA: "沙特阿拉伯",
  KOR: "韩国",
  MLI: "马里",
  MAR: "摩洛哥",
  MEX: "墨西哥",
  NED: "荷兰",
  NGA: "尼日利亚",
  NIR: "北爱尔兰",
  NOR: "挪威",
  NZL: "新西兰",
  PAN: "巴拿马",
  PAR: "巴拉圭",
  PER: "秘鲁",
  POL: "波兰",
  POR: "葡萄牙",
  QAT: "卡塔尔",
  ROU: "罗马尼亚",
  RSA: "南非",
  SRB: "塞尔维亚",
  SCO: "苏格兰",
  SEN: "塞内加尔",
  SVK: "斯洛伐克",
  ESP: "西班牙",
  SUI: "瑞士",
  SWE: "瑞典",
  TUN: "突尼斯",
  TUR: "土耳其",
  USA: "美国",
  URU: "乌拉圭",
  URY: "乌拉圭",
  UZB: "乌兹别克斯坦",
  VEN: "委内瑞拉",
  WAL: "威尔士",
  UAE: "阿联酋",
  CRC: "哥斯达黎加",
  JAM: "牙买加",
};

const FLAG_ISO_BY_CODE = {
  ALG: "dz",
  ARG: "ar",
  AUS: "au",
  AUT: "at",
  BEL: "be",
  BIH: "ba",
  BRA: "br",
  CAN: "ca",
  CIV: "ci",
  COD: "cd",
  COL: "co",
  CPV: "cv",
  CRO: "hr",
  CUW: "cw",
  CZE: "cz",
  ECU: "ec",
  EGY: "eg",
  ENG: "gb-eng",
  ESP: "es",
  FRA: "fr",
  GER: "de",
  GHA: "gh",
  HAI: "ht",
  IRN: "ir",
  IRQ: "iq",
  JOR: "jo",
  JPN: "jp",
  KOR: "kr",
  KSA: "sa",
  MAR: "ma",
  MEX: "mx",
  NED: "nl",
  NOR: "no",
  NZL: "nz",
  PAN: "pa",
  PAR: "py",
  POR: "pt",
  QAT: "qa",
  RSA: "za",
  SCO: "gb-sct",
  SEN: "sn",
  SUI: "ch",
  SWE: "se",
  TUN: "tn",
  TUR: "tr",
  URU: "uy",
  USA: "us",
  UZB: "uz",
};

const NAME_ZH = {
  Algeria: "阿尔及利亚",
  Argentina: "阿根廷",
  Australia: "澳大利亚",
  Austria: "奥地利",
  Belgium: "比利时",
  "Bosnia and Herzegovina": "波黑",
  "South Africa": "南非",
  "United States": "美国",
  "United States of America": "美国",
  "Congo DR": "刚果（金）",
  "DR Congo": "刚果（金）",
  "Cape Verde Islands": "佛得角",
  "Cape Verde": "佛得角",
  "Bosnia-Herzegovina": "波黑",
  "Curaçao": "库拉索",
  Curacao: "库拉索",
  Czechia: "捷克",
  "Czech Republic": "捷克",
  Denmark: "丹麦",
  Ecuador: "厄瓜多尔",
  Egypt: "埃及",
  England: "英格兰",
  Finland: "芬兰",
  France: "法国",
  Germany: "德国",
  Ghana: "加纳",
  Greece: "希腊",
  Haiti: "海地",
  Honduras: "洪都拉斯",
  Hungary: "匈牙利",
  Iran: "伊朗",
  Iraq: "伊拉克",
  Ireland: "爱尔兰",
  Israel: "以色列",
  Italy: "意大利",
  "Ivory Coast": "科特迪瓦",
  "Côte d'Ivoire": "科特迪瓦",
  Japan: "日本",
  Jordan: "约旦",
  "Saudi Arabia": "沙特阿拉伯",
  "South Korea": "韩国",
  "Korea Republic": "韩国",
  Mali: "马里",
  Morocco: "摩洛哥",
  Mexico: "墨西哥",
  Netherlands: "荷兰",
  Nigeria: "尼日利亚",
  "Northern Ireland": "北爱尔兰",
  Norway: "挪威",
  "New Zealand": "新西兰",
  Panama: "巴拿马",
  Paraguay: "巴拉圭",
  Peru: "秘鲁",
  Poland: "波兰",
  Portugal: "葡萄牙",
  Qatar: "卡塔尔",
  Romania: "罗马尼亚",
  Serbia: "塞尔维亚",
  Scotland: "苏格兰",
  Senegal: "塞内加尔",
  Slovakia: "斯洛伐克",
  Spain: "西班牙",
  Switzerland: "瑞士",
  Sweden: "瑞典",
  Tunisia: "突尼斯",
  Turkey: "土耳其",
  Turkiye: "土耳其",
  Türkiye: "土耳其",
  Uruguay: "乌拉圭",
  Uzbekistan: "乌兹别克斯坦",
  Venezuela: "委内瑞拉",
  Wales: "威尔士",
  "United Arab Emirates": "阿联酋",
  "Costa Rica": "哥斯达黎加",
  Jamaica: "牙买加",
  TBD: "待定",
};

const VENUE_ZH = {
  "Estadio Azteca": "阿兹特克体育场",
  "SoFi Stadium": "SoFi 体育场",
  "Levi's Stadium": "李维斯体育场",
  "MetLife Stadium": "大都会人寿体育场",
  "Gillette Stadium": "吉列体育场",
  "BC Place": "卑诗体育馆",
  "NRG Stadium": "NRG 体育场",
  "AT&T Stadium": "AT&T 体育场",
  "Lincoln Financial Field": "林肯金融球场",
  "Estadio BBVA": "BBVA 体育场",
  "Lumen Field": "流明球场",
  "Hard Rock Stadium": "硬石体育场",
  "GEHA Field at Arrowhead Stadium": "箭头体育场",
  "BMO Field": "BMO 球场",
  "Estadio Akron": "阿克伦体育场",
  "Mercedes-Benz Stadium": "梅赛德斯-奔驰体育场",
};

const CITY_ZH = {
  "Mexico City": "墨西哥城",
  "Los Angeles (Inglewood)": "洛杉矶（英格尔伍德）",
  "San Francisco Bay Area (Santa Clara)": "旧金山湾区（圣克拉拉）",
  "New York/New Jersey (East Rutherford)": "纽约/新泽西（东卢瑟福）",
  "Boston (Foxborough)": "波士顿（福克斯伯勒）",
  Vancouver: "温哥华",
  Houston: "休斯敦",
  "Dallas (Arlington, Texas)": "达拉斯（阿灵顿）",
  Philadelphia: "费城",
  "Monterrey (Guadalupe)": "蒙特雷（瓜达卢佩）",
  Seattle: "西雅图",
  "Miami (Miami Gardens)": "迈阿密（迈阿密花园）",
  "Kansas City": "堪萨斯城",
  Toronto: "多伦多",
  "Guadalajara (Zapopan)": "瓜达拉哈拉（萨波潘）",
  Atlanta: "亚特兰大",
};

const COUNTRY_ZH = {
  Mexico: "墨西哥",
  "United States": "美国",
  Canada: "加拿大",
};

const TEXT_REPLACEMENTS = [
  ["United States of America", "美国"],
  ["Korea Republic", "韩国"],
  ["Bosnia and Herzegovina", "波黑"],
  ["Bosnia-Herzegovina", "波黑"],
  ["Cape Verde Islands", "佛得角"],
  ["Congo DR", "刚果（金）"],
  ["DR Congo", "刚果（金）"],
  ["South Africa", "南非"],
  ["South Korea", "韩国"],
  ["Saudi Arabia", "沙特阿拉伯"],
  ["New Zealand", "新西兰"],
  ["Northern Ireland", "北爱尔兰"],
  ["United Arab Emirates", "阿联酋"],
  ["Costa Rica", "哥斯达黎加"],
  ["Goalkeeper", "门将"],
  ["Keeper", "门将"],
  ["Centre-Back", "中后卫"],
  ["Center-Back", "中后卫"],
  ["Central Defender", "中后卫"],
  ["Left-Back", "左后卫"],
  ["Right-Back", "右后卫"],
  ["Full-Back", "边后卫"],
  ["Wing-Back", "翼卫"],
  ["Defender", "后卫"],
  ["Defence", "防线"],
  ["Defense", "防线"],
  ["Defensive Midfield", "防守型中场"],
  ["Central Midfield", "中前卫"],
  ["Centre Midfield", "中前卫"],
  ["Attacking Midfield", "攻击型中场"],
  ["Midfielder", "中场"],
  ["Midfield", "中场"],
  ["Centre-Forward", "中锋"],
  ["Center-Forward", "中锋"],
  ["Left Winger", "左边锋"],
  ["Right Winger", "右边锋"],
  ["Winger", "边锋"],
  ["Striker", "前锋"],
  ["Forward", "前锋"],
  ["Coach", "主教练"],
  ["Official squad", "官方名单"],
  ["official squad", "官方名单"],
  ["Predicted Lineups", "预测首发"],
  ["predicted lineups", "预测首发"],
  ["Lineups", "阵容"],
  ["lineups", "阵容"],
  ["Predicted lineup", "预测首发"],
  ["predicted lineup", "预测首发"],
  ["Starting XI", "首发十一人"],
  ["starting XI", "首发十一人"],
  ["starting xi", "首发十一人"],
  ["Starting 11", "首发十一人"],
  ["starting 11", "首发十一人"],
  ["Formation", "阵型"],
  ["formation", "阵型"],
  ["Lineup", "阵容"],
  ["lineup", "阵容"],
  ["Squad", "名单"],
  ["squad", "名单"],
  ["Bench candidates", "替补候选"],
  ["bench candidates", "替补候选"],
  ["Team news", "球队新闻"],
  ["team news", "球队新闻"],
  ["Injuries", "伤停"],
  ["injuries", "伤停"],
  ["Injury", "伤停"],
  ["injury", "伤停"],
  ["Suspensions", "停赛"],
  ["suspensions", "停赛"],
  ["Suspension", "停赛"],
  ["suspension", "停赛"],
  ["Suspended", "停赛"],
  ["suspended", "停赛"],
  ["Doubtful", "出战成疑"],
  ["doubtful", "出战成疑"],
  ["Unavailable", "缺阵"],
  ["unavailable", "缺阵"],
  ["Under 2.5", "小于 2.5"],
  ["Over 2.5", "大于 2.5"],
  ["BTTS Yes", "双方进球：是"],
  ["BTTS No", "双方进球：否"],
  ["Moneyline", "胜平负"],
  ["moneyline", "胜平负"],
  ["Handicap", "让球"],
  ["handicap", "让球"],
  ["Spread", "让球"],
  ["spread", "让球"],
  ["Over", "大于"],
  ["over", "大于"],
  ["Under", "小于"],
  ["under", "小于"],
  ["Corners", "角球"],
  ["corners", "角球"],
  ["Corner", "角球"],
  ["corner", "角球"],
  ["Corner kicks", "角球"],
  ["corner kicks", "角球"],
  ["Bookings", "罚牌"],
  ["bookings", "罚牌"],
  ["Booking", "罚牌"],
  ["booking", "罚牌"],
  ["Yellow cards", "黄牌"],
  ["yellow cards", "黄牌"],
  ["Yellow card", "黄牌"],
  ["yellow card", "黄牌"],
  ["Red cards", "红牌"],
  ["red cards", "红牌"],
  ["Red card", "红牌"],
  ["red card", "红牌"],
  ["Cards", "罚牌"],
  ["cards", "罚牌"],
  ["Card", "罚牌"],
  ["card", "罚牌"],
  ["Odds provider", "赔率来源"],
  ["odds provider", "赔率来源"],
  ["Odds", "赔率"],
  ["odds", "赔率"],
  ["Bookmaker", "博彩公司"],
  ["bookmaker", "博彩公司"],
  ["Betting", "投注"],
  ["betting", "投注"],
  ["Preview", "前瞻"],
  ["preview", "前瞻"],
  ["Prediction", "预测"],
  ["prediction", "预测"],
  ["Predictions", "预测"],
  ["predictions", "预测"],
  ["Picks", "推荐"],
  ["picks", "推荐"],
  ["Best bets", "推荐玩法"],
  ["best bets", "推荐玩法"],
  ["Markets", "市场"],
  ["markets", "市场"],
  ["Kick-off time", "开赛时间"],
  ["kick-off time", "开赛时间"],
  ["Opening match", "揭幕战"],
  ["opening match", "揭幕战"],
  ["victory over", "战胜"],
  ["Victory over", "战胜"],
  ["rule explained", "规则说明"],
  ["Rule explained", "规则说明"],
  ["denied", "被判无效"],
  ["Denied", "被判无效"],
  ["delivered plenty of drama", "充满戏剧性"],
  ["Delivered plenty of drama", "充满戏剧性"],
  ["compares to records", "与纪录对比"],
  ["Compares to records", "与纪录对比"],
  ["Most red cards", "最多红牌"],
  ["most red cards", "最多红牌"],
  ["Most 红牌", "最多红牌"],
  ["most 红牌", "最多红牌"],
  ["Team stats", "球队数据"],
  ["team stats", "球队数据"],
  ["News", "新闻"],
  ["news", "新闻"],
  [" for World Cup", "：世界杯"],
  [" for world cup", "：世界杯"],
  [" in Group", "，小组"],
  [" in group", "，小组"],
  ["World Cup", "世界杯"],
  ["world cup", "世界杯"],
  ["Group", "小组"],
  ["group", "小组"],
  [" vs ", " 对 "],
];

const el = {
  matchFilter: document.querySelector("#matchFilter"),
  matchSelect: document.querySelector("#matchSelect"),
  oddsKey: document.querySelector("#oddsKey"),
  analyzeBtn: document.querySelector("#analyzeBtn"),
  refreshBtn: document.querySelector("#refreshBtn"),
  matchCount: document.querySelector("#matchCount"),
  appStatus: document.querySelector("#appStatus"),
  sidebarDigest: document.querySelector("#sidebarDigest"),
  homeFlag: document.querySelector("#homeFlag"),
  awayFlag: document.querySelector("#awayFlag"),
  homeName: document.querySelector("#homeName"),
  awayName: document.querySelector("#awayName"),
  matchDate: document.querySelector("#matchDate"),
  matchVenue: document.querySelector("#matchVenue"),
  scoreTitle: document.querySelector("#scoreTitle"),
  qualityBadge: document.querySelector("#qualityBadge"),
  updatedAt: document.querySelector("#updatedAt"),
  predHome: document.querySelector("#predHome"),
  predAway: document.querySelector("#predAway"),
  xgHome: document.querySelector("#xgHome"),
  xgAway: document.querySelector("#xgAway"),
  xgTotal: document.querySelector("#xgTotal"),
  scoreCompact: document.querySelector("#scoreCompact"),
  probabilities: document.querySelector("#probabilities"),
  probabilitySummary: document.querySelector("#probabilitySummary"),
  recommendations: document.querySelector("#recommendations"),
  platformBadge: document.querySelector("#platformBadge"),
  platformInfo: document.querySelector("#platformInfo"),
  sportteryBadge: document.querySelector("#sportteryBadge"),
  sportteryInfo: document.querySelector("#sportteryInfo"),
  intelligenceBadge: document.querySelector("#intelligenceBadge"),
  intelligenceInfo: document.querySelector("#intelligenceInfo"),
  simulationBadge: document.querySelector("#simulationBadge"),
  simulationInfo: document.querySelector("#simulationInfo"),
  historyUpdated: document.querySelector("#historyUpdated"),
  historyStats: document.querySelector("#historyStats"),
  historyTable: document.querySelector("#historyTable"),
  derivativeHistoryUpdated: document.querySelector("#derivativeHistoryUpdated"),
  derivativeHistoryStats: document.querySelector("#derivativeHistoryStats"),
  derivativeHistoryTable: document.querySelector("#derivativeHistoryTable"),
  sportteryHistoryUpdated: document.querySelector("#sportteryHistoryUpdated"),
  sportteryHistoryStats: document.querySelector("#sportteryHistoryStats"),
  sportteryHistoryTable: document.querySelector("#sportteryHistoryTable"),
  weatherInfo: document.querySelector("#weatherInfo"),
  marketInfo: document.querySelector("#marketInfo"),
  derivativeInfo: document.querySelector("#derivativeInfo"),
  teamCompare: document.querySelector("#teamCompare"),
  injuryInfo: document.querySelector("#injuryInfo"),
  factors: document.querySelector("#factors"),
  scoreChips: document.querySelector("#scoreChips"),
  sources: document.querySelector("#sources"),
  disclaimer: document.querySelector("#disclaimer"),
  loadingOverlay: document.querySelector("#loadingOverlay"),
};

document.addEventListener("DOMContentLoaded", () => {
  wireEvents();
  loadMatches();
});

function wireEvents() {
  el.matchFilter.addEventListener("input", () => {
    const selectionChanged = renderMatchOptions();
    if (selectionChanged) queueAnalyzeSelected(250);
  });

  el.matchSelect.addEventListener("change", () => {
    const match = selectedMatch();
    if (match) {
      renderMatchHero(match);
      queueAnalyzeSelected(0);
    }
  });

  el.analyzeBtn.addEventListener("click", () => {
    analyzeSelected();
  });

  el.refreshBtn.addEventListener("click", () => {
    loadMatches(true);
  });

  document.querySelectorAll(".tab").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedTab = button.dataset.tab;
      document.querySelectorAll(".tab").forEach((tab) => tab.classList.remove("active"));
      button.classList.add("active");
      renderSources();
    });
  });
}

async function loadMatches(force = false) {
  setStatus(force ? "重新拉取赛程" : "加载赛程");
  setLoading(true);
  try {
    const fast = !force;
    const response = await fetch(`/api/matches${force ? `?t=${Date.now()}` : "?fast=1"}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || data.message || "赛程接口失败");
    state.matches = data.matches || [];
    renderMatchOptions();
    el.matchCount.textContent = `${state.matches.length} 场`;
    setStatus("赛程已更新");
    const match = selectedMatch();
    if (match) {
      renderMatchHero(match);
      queueAnalyzeSelected(0);
    }
    loadHistoryStats(true);
    if (fast) scheduleBackgroundMatchRefresh();
  } catch (error) {
    setStatus("赛程失败");
    showError(error.message);
  } finally {
    setLoading(false);
    refreshIcons();
  }
}

function scheduleBackgroundMatchRefresh() {
  clearTimeout(state.backgroundRefreshTimer);
  state.backgroundRefreshTimer = setTimeout(refreshMatchesInBackground, 1200);
}

async function refreshMatchesInBackground() {
  const currentId = el.matchSelect.value;
  const currentMatch = selectedMatch();
  try {
    const response = await fetch(`/api/matches?t=${Date.now()}`);
    const data = await response.json();
    if (!response.ok || !Array.isArray(data.matches) || !data.matches.length) return;
    state.matches = data.matches;
    renderMatchOptions();
    let selectedChanged = false;
    if (currentId && state.matches.some((match) => match.id === currentId)) {
      el.matchSelect.value = currentId;
    } else {
      const equivalent = state.matches.find((match) => sameMatchIdentity(match, currentMatch));
      if (equivalent) {
        el.matchSelect.value = equivalent.id;
        selectedChanged = true;
      }
    }
    el.matchCount.textContent = `${state.matches.length} 场`;
    setStatus("赛程已后台刷新");
    const refreshedMatch = selectedMatch();
    if (refreshedMatch) renderMatchHero(refreshedMatch);
    if (selectedChanged || state.lastAnalysis?.mode === "quick") {
      queueAnalyzeSelected(0);
    }
  } catch {
    setStatus("快照模式可用");
  } finally {
    refreshIcons();
  }
}

function sameMatchIdentity(a, b) {
  if (!a || !b) return false;
  const homeA = teamLabel(a.home);
  const awayA = teamLabel(a.away);
  const homeB = teamLabel(b.home);
  const awayB = teamLabel(b.away);
  return (
    homeA === homeB &&
    awayA === awayB &&
    (a.dateInfo?.date || "") === (b.dateInfo?.date || "")
  );
}

function renderMatchOptions() {
  const previousId = el.matchSelect.value;
  const keyword = el.matchFilter.value.trim().toLowerCase();
  state.filtered = state.matches.filter((match) => {
    if (!keyword) return true;
    return [
      match.home.name,
      teamLabel(match.home),
      match.away.name,
      teamLabel(match.away),
      match.dateInfo.label,
      match.stadium.name,
      venueName(match.stadium),
      match.stadium.city,
      cityName(match.stadium?.city),
      match.group,
    ]
      .join(" ")
      .toLowerCase()
      .includes(keyword);
  });

  el.matchSelect.innerHTML = state.filtered
    .map((match) => {
      const venue = cityName(match.stadium.city) || venueName(match.stadium) || "待定";
      return `<option value="${escapeHtml(match.id)}">${escapeHtml(match.dateInfo.label)} · ${escapeHtml(teamLabel(match.home))} 对 ${escapeHtml(teamLabel(match.away))} · ${escapeHtml(venue)}</option>`;
    })
    .join("");

  if (previousId && state.filtered.some((match) => match.id === previousId)) {
    el.matchSelect.value = previousId;
  }

  const match = selectedMatch();
  if (match) renderMatchHero(match);
  return previousId !== el.matchSelect.value;
}

function queueAnalyzeSelected(delay = 0) {
  const match = selectedMatch();
  if (!match) return;
  clearTimeout(state.autoAnalyzeTimer);
  showAnalysisLoading(match);
  state.autoAnalyzeTimer = setTimeout(() => {
    analyzeSelected(match);
  }, delay);
}

async function analyzeSelected(match = selectedMatch()) {
  if (!match) return;
  const requestId = state.activeAnalysisId + 1;
  state.activeAnalysisId = requestId;
  if (state.activeController) {
    state.activeController.abort();
  }
  const controller = new AbortController();
  state.activeController = controller;
  showAnalysisLoading(match);
  setStatus("快速建模中");
  const oddsKey = el.oddsKey.value.trim();
  try {
    const fullHit = getCachedAnalysis(match.id, oddsKey, "full");
    if (fullHit) {
      state.lastAnalysis = fullHit;
      renderAnalysis(fullHit);
      setStatus("缓存结果");
      scheduleQuickPrefetch(match.id, oddsKey);
      loadHistoryStats();
      return;
    }

    let renderedQuick = false;
    const quickHit = getCachedAnalysis(match.id, oddsKey, "quick");
    if (quickHit) {
      state.lastAnalysis = quickHit;
      renderAnalysis(quickHit);
      setStatus("快速结果已显示，深度更新中");
      scheduleQuickPrefetch(match.id, oddsKey);
      renderedQuick = true;
    } else {
      const quickData = await fetchAnalysis(match, oddsKey, true, controller);
      if (!isCurrentAnalysis(requestId, quickData)) return;
      setCachedAnalysis(match.id, oddsKey, "quick", quickData);
      state.lastAnalysis = quickData;
      renderAnalysis(quickData);
      setStatus("快速结果已显示，深度更新中");
      scheduleQuickPrefetch(match.id, oddsKey);
      renderedQuick = true;
    }

    try {
      const fullData = await fetchAnalysis(match, oddsKey, false, controller);
      if (!isCurrentAnalysis(requestId, fullData)) return;
      setCachedAnalysis(match.id, oddsKey, "full", fullData);
      state.lastAnalysis = fullData;
      renderAnalysis(fullData);
      setStatus("分析完成");
      scheduleQuickPrefetch(match.id, oddsKey);
      loadHistoryStats();
    } catch (fullError) {
      if (fullError.name === "AbortError") return;
      if (!renderedQuick) throw fullError;
      setStatus("快速结果可用，深度更新失败");
      scheduleQuickPrefetch(match.id, oddsKey);
      loadHistoryStats();
    }
  } catch (error) {
    if (error.name === "AbortError") return;
    if (requestId !== state.activeAnalysisId) return;
    setStatus("分析失败");
    showError(friendlyFetchError(error));
  } finally {
    if (requestId === state.activeAnalysisId) {
      state.activeController = null;
      refreshIcons();
    }
  }
}

async function fetchAnalysis(match, oddsKey, quick, controller) {
  const params = new URLSearchParams({ matchId: match.id });
  if (quick) params.set("quick", "1");
  if (oddsKey) params.set("oddsKey", oddsKey);
  const response = await fetch(`/api/analyze?${params.toString()}`, {
    signal: controller.signal,
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.detail || data.message || "分析接口失败");
  return data;
}

function isCurrentAnalysis(requestId, data) {
  const currentMatch = selectedMatch();
  return requestId === state.activeAnalysisId && data.match?.id === currentMatch?.id;
}

function getCachedAnalysis(matchId, oddsKey, mode) {
  const hit = state.analysisCache.get(analysisCacheKey(matchId, oddsKey, mode));
  if (!hit) return null;
  const ttl = mode === "quick" ? 8 * 60 * 1000 : 5 * 60 * 1000;
  if (Date.now() - hit.created > ttl) {
    state.analysisCache.delete(analysisCacheKey(matchId, oddsKey, mode));
    return null;
  }
  return hit.data;
}

function setCachedAnalysis(matchId, oddsKey, mode, data) {
  state.analysisCache.set(analysisCacheKey(matchId, oddsKey, mode), {
    created: Date.now(),
    data,
  });
}

function analysisCacheKey(matchId, oddsKey, mode) {
  return `${mode}:${matchId}:${oddsKey ? "odds" : "no-odds"}`;
}

function scheduleQuickPrefetch(matchId, oddsKey) {
  clearTimeout(state.prefetchTimer);
  state.prefetchTimer = setTimeout(() => {
    prefetchNeighborAnalyses(matchId, oddsKey);
  }, 450);
}

function prefetchNeighborAnalyses(matchId, oddsKey) {
  const list = state.filtered.length ? state.filtered : state.matches;
  const index = list.findIndex((match) => match.id === matchId);
  if (index < 0) return;
  const candidateIndexes = [index + 1, index - 1, index + 2, index - 2]
    .filter((item) => item >= 0 && item < list.length)
    .slice(0, 3);

  for (const candidateIndex of candidateIndexes) {
    const match = list[candidateIndex];
    if (!match || getCachedAnalysis(match.id, oddsKey, "quick")) continue;
    const key = analysisCacheKey(match.id, oddsKey, "quick");
    if (state.prefetching.has(key)) continue;
    state.prefetching.add(key);
    const params = new URLSearchParams({ matchId: match.id, quick: "1" });
    if (oddsKey) params.set("oddsKey", oddsKey);
    fetch(`/api/analyze?${params.toString()}`)
      .then((response) => response.ok ? response.json() : null)
      .then((data) => {
        if (data?.mode === "quick" && data.match?.id === match.id) {
          setCachedAnalysis(match.id, oddsKey, "quick", data);
        }
      })
      .catch(() => {})
      .finally(() => {
        state.prefetching.delete(key);
      });
  }
}

function showAnalysisLoading(match) {
  state.lastAnalysis = null;
  renderMatchHero(match);
  el.predHome.textContent = "-";
  el.predAway.textContent = "-";
  el.xgHome.textContent = "主预期进球 --";
  el.xgAway.textContent = "客预期进球 --";
  el.xgTotal.textContent = "总预期进球 --";
  el.qualityBadge.textContent = "更新中";
  el.updatedAt.textContent = "抓取中";
  renderSidebarDigestLoading(match);
  el.probabilities.innerHTML = ["主胜", "平局", "客胜", "大 2.5", "小 2.5", "双方进球"]
    .map(
      (label) => `
        <div class="bar-row">
          <span>${escapeHtml(label)}</span>
          <div class="bar-track"><div class="bar-fill" style="width:0%"></div></div>
          <strong>--</strong>
        </div>
      `
    )
    .join("");
  el.probabilitySummary.innerHTML = `
    <div class="mini-stat"><span>盘口线</span><strong>等待</strong></div>
    <div class="mini-stat"><span>让球</span><strong>等待</strong></div>
    <div class="mini-stat"><span>进球</span><strong>等待</strong></div>
  `;
  el.recommendations.innerHTML = `
    <div class="recommendation">
      <span>${escapeHtml(match.dateInfo.label)}</span>
      <strong>正在更新 ${escapeHtml(teamLabel(match.home))} 对 ${escapeHtml(teamLabel(match.away))}</strong>
      <span>正在抓取该场比赛的天气、海拔、近期状态、阵容伤停和盘口信息。</span>
    </div>
  `;
  el.weatherInfo.innerHTML = [
    ["比赛", `${teamLabel(match.home)} 对 ${teamLabel(match.away)}`],
    ["球场", `${venueName(match.stadium) || "--"}，${cityName(match.stadium.city) || "--"}`],
    ["状态", "正在抓取天气、海拔和球场信息"],
  ].map(metricHtml).join("");
  el.marketInfo.innerHTML = [
    ["盘口", "正在抓取 ESPN/DraftKings 与可用赔率接口"],
    ["大小球", "等待实际盘口线"],
    ["让球", "等待盘口与模型概率"],
  ].map(metricHtml).join("");
  if (el.derivativeInfo) {
    el.derivativeInfo.innerHTML = `
      <div class="derivative-card">
        <span>角球盘口</span>
        <strong>正在抓取角球大小与让球线</strong>
        <em>等待网页信号</em>
      </div>
      <div class="derivative-card">
        <span>罚牌盘口</span>
        <strong>正在抓取罚牌大小与让球线</strong>
        <em>等待网页信号</em>
      </div>
    `;
  }
  if (el.platformBadge) el.platformBadge.textContent = "联机中";
  if (el.platformInfo) {
    el.platformInfo.innerHTML = `
      <div class="platform-card platform-wide">
        <span>全球博彩数据层</span>
        <strong>正在拉取直连源、赔率聚合站、中文彩经和本地缓存</strong>
        <p>完成后会显示源覆盖、盘口矩阵、一致性校验和缓存状态。</p>
      </div>
    `;
  }
  if (el.sportteryBadge) el.sportteryBadge.textContent = "抓取中";
  if (el.sportteryInfo) {
    el.sportteryInfo.innerHTML = `
      <div class="sporttery-card">
        <span>中国体彩网/竞彩网</span>
        <strong>正在匹配官方受注赛程</strong>
        <p>将读取胜平负、让球胜平负、总进球数和比分固定奖金。</p>
      </div>
    `;
  }
  el.teamCompare.innerHTML = [
    ["FIFA 排名", "正在读取国际排名"],
    ["近况", "正在聚合近10场战绩"],
    ["交锋", "正在查找历史交锋"],
  ].map(metricHtml).join("");
  el.injuryInfo.innerHTML = [
    ["主队", teamLabel(match.home)],
    ["客队", teamLabel(match.away)],
    ["状态", "正在抓取阵容、伤停和近期状态"],
  ].map(metricHtml).join("");
  if (el.simulationBadge) el.simulationBadge.textContent = "推演中";
  if (el.simulationInfo) {
    el.simulationInfo.innerHTML = `
      <div class="simulation-card simulation-score">
        <span>事件流</span>
        <strong>正在生成比赛模拟</strong>
        <p>合并官方名单、阵型推断、伤停、天气和盘口信号。</p>
      </div>
      <div class="simulation-card">
        <span>角球/罚牌</span>
        <strong>等待衍生盘口</strong>
        <p>深度分析返回后显示模拟终局。</p>
      </div>
    `;
  }
  if (el.intelligenceBadge) el.intelligenceBadge.textContent = "抓取中";
  if (el.intelligenceInfo) {
    el.intelligenceInfo.innerHTML = `
      <div class="intelligence-card primary">
        <span>24小时情报</span>
        <strong>正在抓取新闻、伤停、盘口与战术信号</strong>
        <p>完成后会按中文摘要、推荐结论和来源核对展示。</p>
      </div>
    `;
  }
  el.factors.innerHTML = `
    <div class="factor">
      <strong><span>模型因子</span><em>更新中</em></strong>
      <p>等待该场比赛的实时数据返回后生成。</p>
    </div>
  `;
  el.scoreCompact.innerHTML = `
    <div class="score-mini-title">候选比分</div>
    <div class="score-mini-list">
      <span>--</span>
      <span>--</span>
      <span>--</span>
    </div>
  `;
  el.scoreChips.innerHTML = "";
  el.sources.innerHTML = `
    <div class="source-item">
      <strong>正在抓取来源</strong>
      <p>${escapeHtml(teamLabel(match.home))} 对 ${escapeHtml(teamLabel(match.away))} 的结构化接口和网页来源正在更新。</p>
    </div>
  `;
}

function renderAnalysis(data) {
  renderMatchHero(data.match);
  const prediction = data.prediction;
  const scoreDisplayScores = renderScorePanel(data);
  el.updatedAt.textContent = formatTime(data.refreshedAt);
  el.disclaimer.textContent = prediction.disclaimer;

  renderProbabilities(prediction, data.match);
  renderProbabilitySummary(prediction, data.match);
  renderRecommendations(prediction.recommendations, data.match, prediction);
  renderSidebarDigest(data);
  renderWeather(data);
  renderMarketInfo(data);
  renderDerivativeMarkets(data);
  renderPlatform(data);
  renderSporttery(data);
  renderTeamCompare(data);
  renderIntelligence(data);
  renderMatchSimulation(data);
  renderInjuries(data);
  renderFactors(prediction.factors);
  renderScoreChips(scoreDisplayScores);
  renderSources();
}

function renderScorePanel(data) {
  const prediction = data.prediction || {};
  const context = prediction.resultContext || {};
  const prematch = context.prematch || {};
  const actual = context.actual || null;
  const liveModel = context.liveModel || {};
  const completed = Boolean(context.completed && actual?.score);
  const scores = completed
    ? prematch.topScores?.length
      ? prematch.topScores
      : liveModel.topScores || prediction.scorePortfolio || prediction.topScores || []
    : prediction.scorePortfolio || prediction.topScores || [];

  if (completed) {
    const [homeScore, awayScore] = String(actual.score || "0-0").split("-");
    if (el.scoreTitle) el.scoreTitle.textContent = "完场比分";
    el.predHome.textContent = homeScore;
    el.predAway.textContent = awayScore;
    el.xgHome.textContent = `赛前推荐 ${prematch.recommendedScore || "--"}`;
    el.xgTotal.textContent = `体彩锚点 ${prematch.sportteryScore?.score || prematch.sportteryScore?.pick || "--"}`;
    el.xgAway.textContent = `复盘模型 ${liveModel.score || prediction.primaryScore?.score || "--"}`;
    el.qualityBadge.textContent = `完场 · ${actual.source || "赛果已确认"}`;
    renderActualScoreCompact(context, prediction);
    return scores;
  }

  const top = prediction.primaryScore || prediction.topScores?.[0] || { score: "0-0" };
  const [homeScore, awayScore] = String(top.score || "0-0").split("-");
  if (el.scoreTitle) el.scoreTitle.textContent = "比分预测";
  el.predHome.textContent = homeScore;
  el.predAway.textContent = awayScore;
  el.xgHome.textContent = `主预期进球 ${prediction.expectedGoals.home}`;
  el.xgAway.textContent = `客预期进球 ${prediction.expectedGoals.away}`;
  el.xgTotal.textContent = `总预期进球 ${prediction.expectedGoals.total}`;
  el.qualityBadge.textContent = `${data.mode === "quick" ? "快速" : "深度"} · 数据质量 ${prediction.quality.label} · ${prediction.quality.score}`;
  renderScoreCompact(scores);
  return scores;
}

async function loadHistoryStats(force = false) {
  if (!el.historyStats || !el.historyTable) return;
  if (!force && state.historyLoadedAt && Date.now() - state.historyLoadedAt < 120000) return;
  if (state.historyController) state.historyController.abort();
  const controller = new AbortController();
  state.historyController = controller;
  el.historyUpdated.textContent = "统计中";
  try {
    const response = await fetch(`/api/history?t=${Date.now()}`, { signal: controller.signal });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || data.message || "历史统计接口失败");
    state.historyLoadedAt = Date.now();
    renderHistoryStats(data);
  } catch (error) {
    if (error.name === "AbortError") return;
    el.historyUpdated.textContent = "统计失败";
    el.historyStats.innerHTML = `<div class="history-empty">历史推荐统计暂不可用：${escapeHtml(friendlyFetchError(error))}</div>`;
    el.historyTable.innerHTML = "";
    if (el.derivativeHistoryUpdated) el.derivativeHistoryUpdated.textContent = "统计失败";
    if (el.derivativeHistoryStats) el.derivativeHistoryStats.innerHTML = `<div class="history-empty">角球/罚牌统计暂不可用：${escapeHtml(friendlyFetchError(error))}</div>`;
    if (el.derivativeHistoryTable) el.derivativeHistoryTable.innerHTML = "";
    if (el.sportteryHistoryUpdated) el.sportteryHistoryUpdated.textContent = "统计失败";
    if (el.sportteryHistoryStats) el.sportteryHistoryStats.innerHTML = `<div class="history-empty">体彩推荐统计暂不可用：${escapeHtml(friendlyFetchError(error))}</div>`;
    if (el.sportteryHistoryTable) el.sportteryHistoryTable.innerHTML = "";
  } finally {
    if (state.historyController === controller) state.historyController = null;
  }
}

function renderHistoryStats(data) {
  const summary = data.summary || {};
  el.historyUpdated.textContent = formatTime(data.refreshedAt);
  renderDerivativeHistoryStats(data);
  renderSportteryHistoryStats(data);
  const rows = data.rows || [];
  el.historyStats.innerHTML = [
    ["完场样本", `${summary.evaluatedMatches ?? 0} 场`],
    ["比分准确率", formatNullablePercent(summary.exactScoreAccuracy)],
    ["胜平负命中", formatNullablePercent(summary.resultDirectionAccuracy)],
    ["Top3 比分命中", formatNullablePercent(summary.top3ScoreAccuracy)],
    ["平均偏差", summary.averageScoreDistance === null || summary.averageScoreDistance === undefined ? "--" : `${summary.averageScoreDistance} 球`],
    ["待赛记录", `${summary.pendingRecords ?? 0} 场`],
  ]
    .map(
      ([label, value]) => `
        <div class="history-card">
          <span>${escapeHtml(label)}</span>
          <strong>${escapeHtml(value)}</strong>
        </div>
      `
    )
    .join("");

  if (!rows.length) {
    el.historyTable.innerHTML = `
      <div class="history-empty">
        暂无可对账的完场样本。之后比赛完场后，系统会自动对比“推荐比分”和“结果比分”，并计算历史推荐比分准确率。
      </div>
    `;
    return;
  }

  el.historyTable.innerHTML = `
    <div class="history-row history-head">
      <span>比赛</span>
      <span>推荐比分</span>
      <span>结果比分</span>
      <span>准确性</span>
      <span>来源</span>
    </div>
    ${rows
      .map(
        (row) => `
          <div class="history-row">
            <span>
              <strong>${escapeHtml(localizeText(row.match, selectedMatch()))}</strong>
              <em>${escapeHtml(row.matchDate || "--")}</em>
            </span>
            <span><em class="history-mobile-label">推荐比分</em>${escapeHtml(row.recommendedScore || "--")}</span>
            <span><em class="history-mobile-label">结果比分</em>${escapeHtml(row.resultScore || "--")}</span>
            <span><em class="history-mobile-label">准确性</em>${historyHitLabel(row)}</span>
            <span>
              <strong>${escapeHtml(row.predictionSource || "--")}</strong>
              <em>${escapeHtml(row.resultSource || "--")}</em>
            </span>
          </div>
        `
      )
      .join("")}
  `;
}

function historyHitLabel(row) {
  if (row.exactScoreHit) return `<b class="hit exact">比分命中</b>`;
  if (row.top3ScoreHit) return `<b class="hit top">Top3 命中</b>`;
  if (row.resultDirectionHit) return `<b class="hit lean">方向命中</b>`;
  return `<b class="hit miss">未命中</b>`;
}

function renderDerivativeHistoryStats(data) {
  if (!el.derivativeHistoryStats || !el.derivativeHistoryTable) return;
  const summary = data.derivativeSummary || {};
  const rows = data.derivativeRows || [];
  if (el.derivativeHistoryUpdated) el.derivativeHistoryUpdated.textContent = formatTime(data.refreshedAt);
  const metric = (item) => {
    const evaluated = item?.evaluated ?? 0;
    return `${formatNullablePercent(item?.accuracy)} · ${evaluated} 场`;
  };
  el.derivativeHistoryStats.innerHTML = [
    ["可对账样本", `${summary.evaluated ?? 0} 条`],
    ["总体命中率", formatNullablePercent(summary.accuracy)],
    ["高质量样本", `${formatNullablePercent(summary.highQualityAccuracy)} · ${summary.highQualityEvaluated ?? 0} 条`],
    ["角球大小", metric(summary.cornersTotal)],
    ["角球让球", metric(summary.cornersHandicap)],
    ["罚牌大小", metric(summary.cardsTotal)],
    ["罚牌让球", metric(summary.cardsHandicap)],
  ]
    .map(
      ([label, value]) => `
        <div class="history-card">
          <span>${escapeHtml(label)}</span>
          <strong>${escapeHtml(value)}</strong>
        </div>
      `
    )
    .join("");

  if (!rows.length) {
    el.derivativeHistoryTable.innerHTML = `
      <div class="history-empty">
        暂无可对账的角球/罚牌样本。系统会在比赛完场后读取 ESPN 技术统计，并对比赛前角球大小、角球让球、罚牌大小、罚牌让球推荐。
      </div>
    `;
    return;
  }

  el.derivativeHistoryTable.innerHTML = `
    <div class="history-row derivative-history-row history-head">
      <span>比赛</span>
      <span>市场</span>
      <span>推荐</span>
      <span>实际</span>
      <span>命中</span>
    </div>
    ${rows
      .slice(0, 32)
      .map(
        (row) => `
          <div class="history-row derivative-history-row">
            <span>
              <strong>${escapeHtml(localizeText(row.match, selectedMatch()))}</strong>
              <em>${escapeHtml(row.matchDate || "--")}</em>
            </span>
            <span><em class="history-mobile-label">市场</em>${escapeHtml(row.label || "--")} · ${escapeHtml(row.market || "--")}</span>
            <span><em class="history-mobile-label">推荐</em>${escapeHtml(localizeText(row.recommended || "--", selectedMatch()))}</span>
            <span><em class="history-mobile-label">实际</em>${escapeHtml(row.resultText || "--")}</span>
            <span><em class="history-mobile-label">命中</em>${derivativeHistoryHitLabel(row)}</span>
          </div>
        `
      )
      .join("")}
  `;
}

function derivativeHistoryHitLabel(row) {
  if (!row.settled) return `<b class="hit top">未结算</b>`;
  return row.hit ? `<b class="hit exact">命中</b>` : `<b class="hit miss">未命中</b>`;
}

function renderSportteryHistoryStats(data) {
  if (!el.sportteryHistoryStats || !el.sportteryHistoryTable) return;
  const summary = data.sportterySummary || {};
  const rows = data.sportteryRows || [];
  if (el.sportteryHistoryUpdated) el.sportteryHistoryUpdated.textContent = formatTime(data.refreshedAt);
  const metric = (item) => {
    const evaluated = item?.evaluated ?? 0;
    return `${formatNullablePercent(item?.accuracy)} · ${evaluated} 条`;
  };
  el.sportteryHistoryStats.innerHTML = [
    ["可对账样本", `${summary.evaluated ?? 0} 条`],
    ["总体命中率", formatNullablePercent(summary.accuracy)],
    ["胜平负", metric(summary.result)],
    ["让球胜平负", metric(summary.handicap)],
    ["总进球数", metric(summary.totalGoals)],
    ["比分", metric(summary.score)],
  ]
    .map(
      ([label, value]) => `
        <div class="history-card">
          <span>${escapeHtml(label)}</span>
          <strong>${escapeHtml(value)}</strong>
        </div>
      `
    )
    .join("");

  if (!rows.length) {
    el.sportteryHistoryTable.innerHTML = `
      <div class="history-empty">
        暂无可对账的体彩推荐样本。系统会在赛前保存体彩推荐，比赛完场后按胜平负、让球胜平负、总进球数、比分四项结算命中。
      </div>
    `;
    return;
  }

  el.sportteryHistoryTable.innerHTML = `
    <div class="history-row sporttery-history-row history-head">
      <span>比赛</span>
      <span>玩法</span>
      <span>推荐</span>
      <span>结果</span>
      <span>命中</span>
    </div>
    ${rows
      .slice(0, 48)
      .map(
        (row) => `
          <div class="history-row sporttery-history-row">
            <span>
              <strong>${escapeHtml(localizeText(row.match, selectedMatch()))}</strong>
              <em>${escapeHtml(row.matchDate || "--")} · ${escapeHtml(row.matchNum || "--")}</em>
            </span>
            <span><em class="history-mobile-label">玩法</em>${escapeHtml(row.market || "--")}</span>
            <span><em class="history-mobile-label">推荐</em>${escapeHtml(localizeText(row.recommended || "--", selectedMatch()))}</span>
            <span><em class="history-mobile-label">结果</em>${escapeHtml(localizeText(row.resultText || "--", selectedMatch()))}</span>
            <span><em class="history-mobile-label">命中</em>${derivativeHistoryHitLabel(row)}</span>
          </div>
        `
      )
      .join("")}
  `;
}

function renderMatchHero(match) {
  el.homeName.textContent = teamLabel(match.home);
  el.awayName.textContent = teamLabel(match.away);
  setFlag(el.homeFlag, match.home);
  setFlag(el.awayFlag, match.away);
  el.matchDate.textContent = `${match.dateInfo.label} · ${labelStage(match)}`;
  el.matchVenue.textContent = `${venueName(match.stadium) || "待定球场"} · ${cityName(match.stadium.city) || ""}`;
}

function renderProbabilities(prediction, match) {
  const probabilities = prediction.probabilities || prediction;
  const marketTotal = prediction.totalLines?.market?.available ? prediction.totalLines.market : null;
  const twoPointFive = prediction.totalLines?.twoPointFive || probabilities.totals?.twoPointFive;
  const rows = [
    { label: `${teamLabel(match.home)}胜`, value: probabilities.homeWin, color: "green" },
    { label: "平局", value: probabilities.draw, color: "amber" },
    { label: `${teamLabel(match.away)}胜`, value: probabilities.awayWin, color: "blue" },
  ];
  if (marketTotal) {
    rows.push(
      { label: `盘口大 ${formatLine(marketTotal.line)}`, value: marketTotal.over, color: "green" },
      { label: `盘口小 ${formatLine(marketTotal.line)}`, value: marketTotal.under, color: "blue" }
    );
    if (Number(marketTotal.line) !== 2.5 && twoPointFive) {
      rows.push({ label: "常规大 2.5", value: twoPointFive.over, color: "amber" });
    }
  } else {
    rows.push(
      { label: "大 2.5", value: probabilities.over25, color: "green" },
      { label: "小 2.5", value: probabilities.under25, color: "blue" }
    );
  }
  rows.push({ label: "双方进球", value: probabilities.btts, color: "amber" });
  el.probabilities.innerHTML = rows
    .map(
      (row) => `
        <div class="bar-row">
          <span>${escapeHtml(row.label)}</span>
          <div class="bar-track">
            <div class="bar-fill ${row.color === "blue" ? "blue" : row.color === "amber" ? "amber" : ""}" style="width:${Math.round(row.value * 100)}%"></div>
          </div>
          <strong>${percent(row.value)}</strong>
        </div>
      `
    )
    .join("");
}

function renderProbabilitySummary(prediction, match) {
  const summary = prediction.marketSummary || buildClientMarketSummary(prediction, match);
  const cards = [
    { title: "大小球", item: summary.total },
    { title: "让球", item: summary.spread },
    { title: "双方进球", item: summary.btts },
  ];
  el.probabilitySummary.innerHTML = cards
    .map((card) => {
      const item = card.item || {};
      const caution = item.consistent === false || item.side === "watch";
      const label = localizeText(item.label || "--", match);
      const note = item.reason ? localizeText(item.reason, match) : "";
      return `
        <div class="mini-stat ${caution ? "caution" : ""}">
          <span>${escapeHtml(card.title)}</span>
          <strong>${escapeHtml(label)}</strong>
          ${note ? `<em>${escapeHtml(note)}</em>` : ""}
        </div>
      `;
    })
    .join("");
}

function buildClientMarketSummary(prediction, match) {
  const probabilities = prediction.probabilities || {};
  const marketTotal = prediction.totalLines?.market?.available ? prediction.totalLines.market : prediction.totalLines?.twoPointFive;
  const line = Number(marketTotal?.line ?? 2.5);
  const over = Number(marketTotal?.over ?? probabilities.over25);
  const under = Number(marketTotal?.under ?? probabilities.under25);
  const primaryScore = prediction.primaryScore || prediction.topScores?.[0] || {};
  const scoreTotal = Number(primaryScore.homeGoals ?? 0) + Number(primaryScore.awayGoals ?? 0);
  const scoreSide = scoreTotal > line ? "over" : scoreTotal < line ? "under" : "push";
  const probabilitySide = over >= under ? "over" : "under";
  const topProbability = Math.max(over, under);
  const weakEdge = Math.abs(over - under) < 0.06 || topProbability < 0.55;
  const conflict = scoreSide !== "push" && scoreSide !== probabilitySide;
  const total = !Number.isFinite(over) || !Number.isFinite(under)
    ? { label: "暂无盘口", side: "watch", consistent: false }
    : weakEdge || conflict || scoreSide === "push"
    ? {
        label: `观望 · 大 ${percent(over)} / 小 ${percent(under)}`,
        side: "watch",
        consistent: false,
        reason: `最高概率比分 ${primaryScore.score || "--"} 与盘口方向未形成强一致。`,
      }
    : {
        label: `${probabilitySide === "over" ? "大于" : "小于"} ${formatLine(line)} · ${percent(topProbability)}`,
        side: probabilitySide,
        consistent: true,
      };

  const spread = prediction.spreadLine;
  const dogName = spread?.favoriteSide === "home" ? teamLabel(match.away) : teamLabel(match.home);
  const favoriteCover = Number(spread?.favoriteCover);
  const underdogCover = Number(spread?.underdogCover);
  const spreadSummary = !spread?.available || !Number.isFinite(favoriteCover) || !Number.isFinite(underdogCover)
    ? { label: "暂无盘口", side: "watch", consistent: false }
    : favoriteCover >= 0.56 && favoriteCover >= underdogCover
    ? { label: `${spread.favoriteName} -${formatLine(spread.line)} · ${percent(favoriteCover)}`, side: "favorite", consistent: true }
    : underdogCover >= 0.56 && underdogCover > favoriteCover
    ? { label: `${dogName} +${formatLine(spread.line)} · ${percent(underdogCover)}`, side: "underdog", consistent: true }
    : {
        label: `观望 · 让方 ${percent(favoriteCover)} / 受让 ${percent(underdogCover)}`,
        side: "watch",
        consistent: false,
      };

  const btts = Number(probabilities.btts);
  const bttsNo = Number.isFinite(btts) ? 1 - btts : null;
  return {
    total,
    spread: spreadSummary,
    btts: bttsNo !== null
      ? { label: `${btts >= bttsNo ? "是" : "否"} · ${percent(Math.max(btts, bttsNo))}`, consistent: true }
      : { label: "--" },
  };
}

function renderRecommendations(recommendations, match, prediction = {}) {
  const context = prediction.resultContext || {};
  if (context.completed && context.actual?.score) {
    const prematch = context.prematch || {};
    const sportteryScore = prematch.sportteryScore || {};
    const actualScore = context.actual.score;
    const prematchScore = prematch.recommendedScore || "--";
    const liveScore = context.liveModel?.score || prediction.primaryScore?.score || "--";
    const prematchHit = prematchScore === actualScore;
    const prematchDirectionHit = scoreDirectionText(prematchScore) === scoreDirectionText(actualScore);
    const sportteryHit = sportteryScore.score && sportteryScore.score === actualScore;
    el.recommendations.innerHTML = `
      <div class="recommendation">
        <span>赛果确认 · ${escapeHtml(context.actual.source || "已完场")}</span>
        <strong>${escapeHtml(teamLabel(match.home))} ${escapeHtml(actualScore)} ${escapeHtml(teamLabel(match.away))}</strong>
        <span>该场已完场，当前页面切换为赛后复盘，不再展示新的赛前投注推荐。</span>
      </div>
      <div class="recommendation">
        <span>赛前推荐对账 · ${prematchHit ? "比分命中" : prematchDirectionHit ? "方向命中" : "未命中"}</span>
        <strong>赛前推荐 ${escapeHtml(prematchScore)}</strong>
        <span>历史保存时间 ${escapeHtml(formatTime(prematch.generatedAt))}，实际比分 ${escapeHtml(actualScore)}。</span>
      </div>
      <div class="recommendation">
        <span>体彩锚点对账 · ${sportteryScore.score ? sportteryHit ? "命中" : "未命中" : "暂无"}</span>
        <strong>体彩锚点 ${escapeHtml(sportteryScore.score || sportteryScore.pick || "--")}</strong>
        <span>当前复盘模型为 ${escapeHtml(liveScore)}，仅用于赛后误差分析，不覆盖赛前历史推荐。</span>
      </div>
    `;
    return;
  }
  const coreRecommendations = (recommendations || []).filter((item) => !/角球|罚牌/.test(String(item.market || "")));
  const recommendationHtml = (coreRecommendations.length ? coreRecommendations : recommendations || [])
    .map(
      (item) => `
        <div class="recommendation">
          <span>${escapeHtml(item.market)} · 置信 ${escapeHtml(item.confidence)}</span>
          <strong>${escapeHtml(localizeText(item.pick, match))}</strong>
          <span>${escapeHtml(localizeText(item.reason, match))}</span>
        </div>
      `
    )
    .join("");
  const toolkit = prediction.bettingToolkit || [];
  const toolkitHtml = toolkit.length
    ? `
      <div class="recommendation-divider">组合盘与风险核对</div>
      <div class="betting-toolkit">
        ${toolkit
          .map(
            (item) => `
              <div class="betting-card">
                <span>${escapeHtml(item.title || "参考")}${item.confidence ? ` · 置信 ${escapeHtml(item.confidence)}` : ""}</span>
                <strong>${escapeHtml(localizeText(item.pick || "--", match))}</strong>
                <p>${escapeHtml(localizeText(item.body || "", match))}</p>
                <div class="betting-tags">
                  ${(item.tags || []).map((tag) => `<em>${escapeHtml(localizeText(tag, match))}</em>`).join("")}
                </div>
              </div>
            `
          )
          .join("")}
      </div>
    `
    : "";
  el.recommendations.innerHTML = `${recommendationHtml}${toolkitHtml}`;
}

function scoreDirectionText(score) {
  const match = String(score || "").match(/(\d+)\s*[-:]\s*(\d+)/);
  if (!match) return "";
  const home = Number(match[1]);
  const away = Number(match[2]);
  if (home > away) return "home";
  if (home < away) return "away";
  return "draw";
}

function renderIntelligence(data) {
  if (!el.intelligenceBadge || !el.intelligenceInfo) return;
  const match = data.match;
  const intel = data.prediction?.intelligence24h;
  if (!intel?.available) {
    el.intelligenceBadge.textContent = "暂无情报";
    el.intelligenceInfo.innerHTML = `
      <div class="intelligence-card primary">
        <span>24小时情报</span>
        <strong>暂未抓到可用赛事情报</strong>
        <p>请稍后刷新，系统会重新抓取新闻、伤停、盘口和彩经摘要。</p>
      </div>
    `;
    return;
  }

  el.intelligenceBadge.textContent = intel.verifiedRecentCount
    ? `近24小时 ${intel.verifiedRecentCount} 条`
    : `情报汇总 ${intel.sourceCount || 0} 条`;
  const recommendation = intel.recommendation || {};
  const briefs = intel.briefs?.length
    ? intel.briefs
    : (intel.cards || []).map((card) => ({
        title: card.title || "情报",
        verdict: card.text || "--",
        impact: "",
        tone: card.tone || "",
        confidence: "--",
        sourceCount: 0,
        sources: [],
      }));
  const sources = intel.sources || [];
  const points = intel.keyPoints?.length ? intel.keyPoints : intel.summary || [];
  const stats = intel.sourceStats || {};
  el.intelligenceInfo.innerHTML = `
    <div class="intelligence-card primary">
      <span>${escapeHtml(intel.status === "recent_verified" ? "24小时已验证" : intel.status === "structured_summary" ? "结构化情报提炼" : "搜索摘要补充")}</span>
      <strong>${escapeHtml(localizeText(intel.headline || "情报汇总", match))}</strong>
      <div class="intel-meta">
        <em>实时 ${Number(stats.recent || 0)}</em>
        <em>结构化 ${Number(stats.structured || intel.structuredCount || 0)}</em>
        <em>网页/缓存 ${Number(stats.fallback || 0)}</em>
      </div>
      <div class="intel-points">
        ${points.slice(0, 4).map((item) => `<p>${escapeHtml(localizeText(item, match))}</p>`).join("")}
      </div>
    </div>
    <div class="intelligence-card recommendation-call">
      <span>情报推荐 · 置信 ${escapeHtml(recommendation.confidence || "--")}</span>
      <strong>${escapeHtml(localizeText(recommendation.pick || "--", match))}</strong>
      <p>${escapeHtml(localizeText(recommendation.reason || "", match))}</p>
    </div>
    ${briefs
      .map(
        (brief) => `
          <div class="intelligence-card ${escapeHtml(brief.tone || "")}">
            <span>${escapeHtml(brief.title || "情报")} · ${escapeHtml(brief.confidence || "--")} · ${Number(brief.sourceCount || 0)} 条</span>
            <strong>${escapeHtml(localizeText(brief.verdict || "--", match))}</strong>
            <p>${escapeHtml(localizeText(brief.impact || "", match))}</p>
            ${(brief.sources || []).length ? `<div class="intel-source-strip">${brief.sources.slice(0, 3).map((item) => `<em>${escapeHtml(localizeText(item, match))}</em>`).join("")}</div>` : ""}
          </div>
        `
      )
      .join("")}
    <div class="intelligence-sources">
      <span>来源核对</span>
      ${sources.length
        ? sources
            .slice(0, 6)
            .map(
              (source) => `
                <a href="${escapeAttribute(source.url || "#")}" ${source.url ? 'target="_blank" rel="noreferrer"' : ""}>
                  <strong>${escapeHtml(localizeText(source.title || source.domain || "情报来源", match))}</strong>
                  <em>${escapeHtml(source.structured ? `结构化数据 · ${source.domain || source.category || ""}` : source.publishedAt ? `${formatDateTime(source.publishedAt)} · ${source.domain || ""}` : `${source.recent ? "近24小时" : "未标发布时间"} · ${source.domain || ""}`)}</em>
                </a>
              `
            )
            .join("")
        : `<p>暂无可展示来源，等待下一次刷新。</p>`}
    </div>
  `;
}

function renderSidebarDigestLoading(match) {
  el.sidebarDigest.innerHTML = `
    <div class="digest-item">
      <span>对阵</span>
      <strong>${escapeHtml(teamLabel(match.home))} vs ${escapeHtml(teamLabel(match.away))}</strong>
    </div>
    <div class="digest-item">
      <span>比赛时间</span>
      <strong>${escapeHtml(match.dateInfo.label)}</strong>
    </div>
    <div class="digest-item">
      <span>数据状态</span>
      <strong>抓取中</strong>
    </div>
  `;
}

function renderSidebarDigest(data) {
  const match = data.match;
  const weather = data.weather || {};
  const current = weather.current || {};
  const espnOdds = data.research?.structured?.espn?.odds || {};
  const fifa = data.research?.structured?.fifa;
  const marketLine = data.prediction?.totalLines?.market;
  const rows = [
    ["当前", `${teamLabel(match.home)} vs ${teamLabel(match.away)}`],
    ["盘口", espnOdds.available ? `${formatLine(marketLine?.line ?? espnOdds.overUnder)} 球 · ${espnOdds.details || "--"}` : "暂无"],
    ["排名", describeCompactRank(fifa, match)],
    ["天气", weather.available ? `${current.condition} · ${valueOrDash(current.temperature)} C` : "暂无"],
    ["质量", `${data.prediction?.quality?.label || "--"} · ${data.prediction?.quality?.score ?? "--"}`],
  ];
  el.sidebarDigest.innerHTML = rows
    .map(
      ([label, value]) => `
        <div class="digest-item">
          <span>${escapeHtml(label)}</span>
          <strong>${escapeHtml(localizeText(value, match))}</strong>
        </div>
      `
    )
    .join("");
}

function renderWeather(data) {
  const venue = data.venue || {};
  const weather = data.weather || {};
  const elevation = data.elevation || {};
  const geo = data.geo || {};
  const current = weather.current || {};
  const weatherText = weather.available
    ? `${current.condition}，${valueOrDash(current.temperature)} C，湿度 ${valueOrDash(current.humidity)}%，风 ${valueOrDash(current.windSpeed)} km/h`
    : weather.message || "天气暂不可用";
  const rows = [
    ["球场", `${venueName(venue) || "--"}，容量 ${venue.capacity ? venue.capacity.toLocaleString() : "--"}`],
    ["城市", `${cityName(venue.city) || "--"}，${countryName(venue.country) || "--"}`],
    ["定位", geo.label || "--"],
    ["天气", weatherText],
    ["降水", weather.available ? `概率 ${valueOrDash(current.precipitationProbability)}%，降水 ${valueOrDash(current.precipitation)} mm` : "--"],
    ["海拔", elevation.available ? `${Math.round(elevation.meters || 0)} 米` : "暂不可用"],
  ];
  el.weatherInfo.innerHTML = rows.map(metricHtml).join("");
}

function renderMarketInfo(data) {
  const match = data.match;
  const prediction = data.prediction || {};
  const structured = data.research?.structured || {};
  const espn = structured.espn || {};
  const espnOdds = espn.odds || {};
  const totalLine = prediction.totalLines?.market;
  const spreadLine = prediction.spreadLine;
  const moneyline = espnOdds.moneyline || {};
  const rows = [
    ["盘口来源", espnOdds.available ? `${espn.provider || espnOdds.provider || "ESPN/DraftKings"} · ${espn.mode || "实时/缓存"}` : data.odds?.message || "暂无结构化盘口"],
    [
      "胜平负",
      espnOdds.available
        ? `${teamLabel(match.home)} ${formatAmerican(moneyline.home)} / 平 ${formatAmerican(moneyline.draw)} / ${teamLabel(match.away)} ${formatAmerican(moneyline.away)}`
        : "暂无",
    ],
    [
      "大小球",
      totalLine?.available
        ? `${formatLine(totalLine.line)} 球：大 ${percent(totalLine.over)} / 小 ${percent(totalLine.under)}（赔率 ${formatAmerican(totalLine.overOdds)} / ${formatAmerican(totalLine.underOdds)}）`
        : "暂无实际盘口线，按 2.5 参考",
    ],
    [
      "让球",
      spreadLine?.available
        ? `${spreadLine.favoriteName} -${formatLine(spreadLine.line)}：穿盘 ${percent(spreadLine.favoriteCover)} / 受让 ${percent(spreadLine.underdogCover)}（赔率 ${formatAmerican(spreadLine.favoriteOdds)} / ${formatAmerican(spreadLine.underdogOdds)}）`
        : "暂无让球盘口",
    ],
    ["盘口摘要", localizeText(espnOdds.details || espn.warning || "暂无", match)],
  ];
  el.marketInfo.innerHTML = rows.map(metricHtml).join("");
}

function renderDerivativeMarkets(data) {
  if (!el.derivativeInfo) return;
  const match = data.match;
  const markets = data.prediction?.derivativeMarkets || {};
  const corners = markets.corners || {};
  const cards = markets.cards || {};
  const items = [
    derivativeTotalCard("角球大小", corners.total, corners, match),
    derivativeHandicapCard("角球让球", corners.handicap, corners, "corners", match),
    derivativeTotalCard("罚牌大小", cards.total, cards, match),
    derivativeHandicapCard("罚牌让球", cards.handicap, cards, "cards", match),
    derivativeSourceRadarCard(markets),
    derivativeCalibrationCard(corners, cards, match),
  ];
  el.derivativeInfo.innerHTML = items.join("");
}

function derivativeTotalCard(title, total, parent, match) {
  const recommendation = total?.recommendation || {};
  const expected = Number.isFinite(Number(parent?.expected)) ? parent.expected : "--";
  const cardClass = parent?.marketBacked ? "market-backed" : "model-fallback";
  const lineSource = total?.lineSource || (parent?.marketBacked ? "网页信号校准" : "模型基准线");
  const lineLabel = total?.lineSourceType === "model_fallback" ? "基准" : "线";
  const quality = derivativeQualityText(parent);
  return `
    <div class="derivative-card ${cardClass}">
      <span>${escapeHtml(title)} · 置信 ${escapeHtml(recommendation.confidence || "低")} · ${escapeHtml(lineSource)} · ${escapeHtml(quality)}</span>
      <strong>${escapeHtml(localizeText(recommendation.pick || "等待盘口线", match))}</strong>
      <div class="derivative-stats">
        <em>${escapeHtml(lineLabel)} ${escapeHtml(formatLine(total?.line))}</em>
        <em>大 ${percent(total?.over)}</em>
        <em>小 ${percent(total?.under)}</em>
      </div>
      <p>${escapeHtml(localizeText(recommendation.reason || `模型期望 ${expected}`, match))}</p>
      ${derivativeEvidenceHtml(parent, match)}
    </div>
  `;
}

function derivativeHandicapCard(title, handicap, parent, kind, match) {
  const recommendation = handicap?.recommendation || {};
  const line = formatLine(handicap?.line);
  const cardClass = parent?.marketBacked ? "market-backed" : "model-fallback";
  const lineSource = handicap?.lineSource || (parent?.marketBacked ? "网页信号校准" : "模型基准线");
  const lineLabel = handicap?.lineSourceType === "model_fallback" ? "基准" : "盘口线";
  const quality = derivativeQualityText(parent);
  const sideText = kind === "cards"
    ? `${handicap?.pressureName || "--"} +${line} / ${handicap?.oppositeName || "--"} 对照`
    : `${handicap?.favoriteName || "--"} -${line} / ${handicap?.underdogName || "--"} +${line}`;
  const mainProbability = kind === "cards"
    ? Math.max(Number(handicap?.pressureCover || 0), Number(handicap?.oppositeCover || 0))
    : Math.max(Number(handicap?.favoriteCover || 0), Number(handicap?.underdogCover || 0));
  return `
    <div class="derivative-card ${cardClass}">
      <span>${escapeHtml(title)} · 置信 ${escapeHtml(recommendation.confidence || "低")} · ${escapeHtml(lineSource)} · ${escapeHtml(lineLabel)} ${escapeHtml(line)} · ${escapeHtml(quality)}</span>
      <strong>${escapeHtml(localizeText(recommendation.pick || sideText, match))}</strong>
      <div class="derivative-stats">
        <em>${escapeHtml(localizeText(sideText, match))}</em>
        <em>推荐侧 ${percent(mainProbability)}</em>
      </div>
      <p>${escapeHtml(localizeText(recommendation.reason || "等待网页盘口信号", match))}</p>
      ${derivativeEvidenceHtml(parent, match)}
    </div>
  `;
}

function derivativeQualityText(parent) {
  const quality = parent?.sourceQuality || {};
  const score = Number(quality.score || 0);
  if (!score) return `来源 ${parent?.sourceCount ?? 0} 条 · 质量 无`;
  return `来源 ${parent?.sourceCount ?? 0} 条 · 质量 ${quality.label || "--"} ${score.toFixed(2)}`;
}

function derivativeEvidenceHtml(parent, match) {
  const items = (parent?.evidence || []).slice(0, 2);
  if (!items.length) {
    return `<div class="derivative-evidence"><span>来源状态</span><em>${escapeHtml(parent?.sourceSummary || "暂未抓到稳定网页盘口，当前以模型弱参考展示。")}</em></div>`;
  }
  return `
    <div class="derivative-evidence">
      <span>来源摘要</span>
      ${items
        .map((item) => `<em>${escapeHtml(item.domain || item.groupLabel || "网页来源")}：${escapeHtml(localizeText(item.text || "盘口线索", match))}</em>`)
        .join("")}
    </div>
  `;
}

function derivativeSourceRadarCard(markets) {
  const diagnostics = markets.sourceDiagnostics || {};
  const targets = (diagnostics.targetDomains || []).slice(0, 6);
  const groups = (diagnostics.topGroups || []).slice(0, 4);
  const status = diagnostics.sourceState || (markets.marketBacked ? "已命中附加盘信号" : "等待目标源");
  const quality = diagnostics.sourceQuality || {};
  const qualityText = quality.score ? `质量 ${quality.label || "--"} ${Number(quality.score).toFixed(2)}` : "质量 无";
  return `
    <div class="derivative-card source-radar">
      <span>来源雷达 · ${escapeHtml(status)} · ${escapeHtml(qualityText)}</span>
      <strong>${escapeHtml(markets.sourceSummary || "正在核对角球/罚牌目标源")}</strong>
      <div class="derivative-stats">
        <em>搜索组 ${escapeHtml(String(diagnostics.searchedGroups ?? "--"))}</em>
        <em>摘要 ${escapeHtml(String(diagnostics.filteredResults ?? "--"))}</em>
        <em>直连 ${escapeHtml(String(diagnostics.directResults ?? 0))}</em>
        <em>采纳 ${escapeHtml(String(diagnostics.sourceCount ?? 0))}</em>
        <em>质量分 ${escapeHtml(String(quality.score ?? "--"))}</em>
      </div>
      <div class="source-chip-grid">
        ${targets.length
          ? targets.map((item) => `<em class="${item.hits ? "hit" : ""}">${escapeHtml(item.label)} ${escapeHtml(String(item.hits || 0))}</em>`).join("")
          : "<em>等待目标源</em>"}
      </div>
      <p>${escapeHtml(diagnostics.note || "已尝试搜索开云/Kaiyun、主流博彩公司和角球/罚牌彩经关键词；未命中时仅显示模型基准。")}</p>
      ${groups.length
        ? `<div class="derivative-evidence"><span>命中分组</span>${groups.map((group) => `<em>${escapeHtml(group.label)}：筛选 ${escapeHtml(String(group.resultCount || 0))} / 原始 ${escapeHtml(String(group.rawCount || 0))}</em>`).join("")}</div>`
        : ""}
    </div>
  `;
}

function derivativeCalibrationCard(corners, cards, match) {
  const cornerTotal = corners.total || {};
  const cardTotal = cards.total || {};
  const cornerSide = cornerTotal.over >= cornerTotal.under ? "偏大" : "偏小";
  const cardSide = cardTotal.over >= cardTotal.under ? "偏大" : "偏小";
  return `
    <div class="derivative-card calibration-card">
      <span>模型校准 · 附加盘节奏</span>
      <strong>角球 ${escapeHtml(String(corners.expected ?? "--"))} / 罚牌 ${escapeHtml(String(cards.expected ?? "--"))}</strong>
      <div class="derivative-stats">
        <em>角球基准 ${escapeHtml(formatLine(cornerTotal.line))}</em>
        <em>${escapeHtml(cornerSide)} ${percent(Math.max(Number(cornerTotal.over || 0), Number(cornerTotal.under || 0)))}</em>
        <em>罚牌基准 ${escapeHtml(formatLine(cardTotal.line))}</em>
        <em>${escapeHtml(cardSide)} ${percent(Math.max(Number(cardTotal.over || 0), Number(cardTotal.under || 0)))}</em>
      </div>
      <p>${escapeHtml(localizeText("附加盘没有稳定网页源时，只用于节奏和裁判尺度参考；临场抓到盘口线后会自动切换为网页盘口线。", match))}</p>
      <div class="derivative-evidence">
        <span>使用建议</span>
        <em>角球看边路压制、落后方进攻回合和定位球；罚牌看裁判尺度、淘汰压力和受压防守方。</em>
      </div>
    </div>
  `;
}

function renderPlatform(data) {
  if (!el.platformInfo || !el.platformBadge) return;
  const platform = data.prediction?.bettingPlatform;
  const match = data.match;
  if (!platform?.available) {
    el.platformBadge.textContent = "待更新";
    el.platformInfo.innerHTML = `
      <div class="platform-card platform-wide">
        <span>平台总控</span>
        <strong>暂无平台化数据</strong>
        <p>完成一次深度分析后显示全球博彩源覆盖和盘口矩阵。</p>
      </div>
    `;
    return;
  }

  const health = platform.sourceHealth || {};
  const consistency = platform.consistency || {};
  const coverage = platform.sourceCoverage || [];
  const markets = platform.marketMatrix || [];
  const derivativeCoverage = health.derivativeCoverage || {};
  el.platformBadge.textContent = consistency.ok
    ? `已校验 · ${health.acceptedMarkets ?? 0} 项采纳`
    : `已降级 · ${health.conflictCount ?? 0} 项冲突`;

  const kpis = [
    ["数据源目录", `${health.totalSources ?? coverage.length} 个`],
    ["命中线索", `${health.sourceHits ?? 0} 条`],
    ["直连/API", `${health.directSources ?? 0} 个`],
    ["盘口采纳", `${health.acceptedMarkets ?? 0} 项`],
    ["推荐冲突", `${health.conflictCount ?? 0} 项`],
    ["数据质量", `${health.qualityLabel || "--"} · ${health.qualityScore ?? "--"}`],
  ];

  el.platformInfo.innerHTML = `
    <div class="platform-card platform-wide platform-command">
      <span>赛事分析平台</span>
      <strong>${escapeHtml(platform.headline || "多源数据已同步")}</strong>
      <p>${escapeHtml(platform.fetchPolicy?.warning || "平台会区分真实来源、网页摘要、本地缓存与模型兜底。")}</p>
      <div class="platform-kpis">
        ${kpis.map(([label, value]) => `<em><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></em>`).join("")}
      </div>
    </div>
    <div class="platform-card platform-wide market-matrix-card">
      <span>盘口矩阵 · 同一锚点推荐</span>
      <strong>比分、让球、大小、角球、罚牌、体彩统一核对</strong>
      <div class="market-matrix">
        ${markets.map((item) => platformMarketHtml(item, match)).join("")}
      </div>
    </div>
    <div class="platform-card">
      <span>衍生盘口缓存</span>
      <strong>${escapeHtml(derivativeCoverage.status || "idle")} · ${escapeHtml(String(derivativeCoverage.windowHours || 24))} 小时窗口</strong>
      <p>未来场次 ${escapeHtml(String(derivativeCoverage.totalMatches ?? 0))}，完整角球+罚牌 ${escapeHtml(String(derivativeCoverage.completeMatches ?? 0))}，直连盘口 ${escapeHtml(String(derivativeCoverage.directEntries ?? 0))} 条。</p>
      <div class="platform-tags">
        <em>角球 ${escapeHtml(String(derivativeCoverage.cornerMatches ?? 0))}</em>
        <em>罚牌 ${escapeHtml(String(derivativeCoverage.cardMatches ?? 0))}</em>
        <em>刷新 ${escapeHtml(derivativeCoverage.refreshedAt ? formatTime(derivativeCoverage.refreshedAt) : "--")}</em>
      </div>
    </div>
    <div class="platform-card">
      <span>一致性规则</span>
      <strong>${escapeHtml(consistency.ok ? "通过" : "已降级观望")}</strong>
      <p>${escapeHtml(consistency.rule || "所有推荐服从比分锚点和盘口概率锚点。")}</p>
      <div class="platform-tags">
        <em>锚点比分 ${escapeHtml(consistency.anchorScore || "--")}</em>
        <em>概率 ${formatNullablePercent(consistency.anchorProbability)}</em>
      </div>
      ${consistency.issues?.length ? `<div class="platform-issues">${consistency.issues.slice(0, 3).map((issue) => `<em>${escapeHtml(localizeText(issue, match))}</em>`).join("")}</div>` : ""}
    </div>
    <div class="platform-card platform-wide source-coverage-card">
      <span>全球博彩源覆盖</span>
      <strong>直连、API、聚合站、博彩公司、中文彩经、技术统计</strong>
      <div class="source-coverage-grid">
        ${coverage.slice(0, 14).map((source) => platformSourceHtml(source)).join("")}
      </div>
    </div>
  `;
}

function platformMarketHtml(item, match) {
  const probability = item.probability === null || item.probability === undefined ? "--" : percent(item.probability);
  const line = item.line === null || item.line === undefined ? "" : ` · 线 ${formatLine(item.line)}`;
  const odds = item.odds === null || item.odds === undefined ? "" : ` · 奖金 ${Number(item.odds).toFixed(2)}`;
  const statusClass = item.status === "采纳" ? "adopted" : item.status === "缺口" ? "missing" : "watch";
  return `
    <div class="market-matrix-row ${statusClass}">
      <span>${escapeHtml(item.market || "--")} · ${escapeHtml(item.status || "--")} · 置信 ${escapeHtml(item.confidence || "--")}</span>
      <strong>${escapeHtml(localizeText(item.pick || "--", match))}</strong>
      <p>${escapeHtml(localizeText(item.note || "", match))}</p>
      <div class="platform-tags">
        <em>概率 ${escapeHtml(probability)}</em>
        ${line ? `<em>${escapeHtml(line.replace(/^ · /, ""))}</em>` : ""}
        ${odds ? `<em>${escapeHtml(odds.replace(/^ · /, ""))}</em>` : ""}
        ${(item.sources || []).slice(0, 3).map((source) => `<em>${escapeHtml(source)}</em>`).join("")}
      </div>
    </div>
  `;
}

function platformSourceHtml(source) {
  const modeClass = source.mode === "direct" || source.mode === "api" ? "direct" : source.mode === "web" ? "web" : source.mode === "need_key" ? "need-key" : "missing";
  return `
    <div class="source-coverage ${modeClass}">
      <span>${escapeHtml(source.category || "来源")}</span>
      <strong>${escapeHtml(source.label || "--")}</strong>
      <p>${escapeHtml(source.status || "--")} · 命中 ${escapeHtml(String(source.hits ?? 0))} · ${escapeHtml(source.marketsLabel || "")}</p>
    </div>
  `;
}

function renderSporttery(data) {
  if (!el.sportteryInfo || !el.sportteryBadge) return;
  const sporttery = data.prediction?.sportteryRecommendation || data.sporttery || {};
  if (!sporttery.available) {
    el.sportteryBadge.textContent = "暂无官方数据";
    el.sportteryInfo.innerHTML = `
      <div class="sporttery-card sporttery-empty">
        <span>中国体彩网/竞彩网</span>
        <strong>暂未匹配到该场体彩官方受注数据</strong>
        <p>${escapeHtml(sporttery.message || "官方受注赛程未开放或队名/日期暂未对齐。")}</p>
      </div>
    `;
    return;
  }
  el.sportteryBadge.textContent = `${sporttery.matchNum || "官方"} · ${sporttery.updateTime ? "已更新" : "已匹配"}`;
  const items = sporttery.items || [];
  el.sportteryInfo.innerHTML = `
    <div class="sporttery-meta">
      <span>来源：中国体彩网/竞彩网</span>
      <strong>${escapeHtml(sporttery.officialMatch?.leagueName || "官方竞彩")} · ${escapeHtml(sporttery.matchNum || "--")}</strong>
      <p>${escapeHtml(sporttery.officialMatch?.home || "--")} vs ${escapeHtml(sporttery.officialMatch?.away || "--")}；更新时间 ${escapeHtml(sporttery.updateTime || "--")}</p>
    </div>
    ${items.map(sportteryCardHtml).join("")}
  `;
}

function sportteryCardHtml(item) {
  const probability = item.probability === null || item.probability === undefined ? "--" : percent(item.probability);
  const odds = item.odds === null || item.odds === undefined ? "--" : Number(item.odds).toFixed(2);
  const value = item.valueIndex === null || item.valueIndex === undefined ? "--" : Number(item.valueIndex).toFixed(2);
  return `
    <div class="sporttery-card ${item.side === "watch" ? "watch" : ""}">
      <span>${escapeHtml(item.market || "--")} · 置信 ${escapeHtml(item.confidence || "--")}</span>
      <strong>${escapeHtml(item.pick || "--")}</strong>
      <div class="sporttery-kpis">
        <em>模型 ${escapeHtml(probability)}</em>
        <em>奖金 ${escapeHtml(odds)}</em>
        <em>价值 ${escapeHtml(value)}</em>
      </div>
      <p>${escapeHtml(item.reason || "")}</p>
    </div>
  `;
}

function renderTeamCompare(data) {
  const structured = data.research?.structured || {};
  const formGuide = structured.formGuide || data.research?.signals?.form;
  const fifa = structured.fifa;
  const match = data.match;
  const rows = [
    ["FIFA 排名", describeFifaRankings(fifa, match)],
    ["近10场状态", describeForm(formGuide)],
    ["历史交锋", describeHeadToHead(formGuide?.headToHead, match)],
    ["主队攻击/防守", describeSideForm(formGuide?.home)],
    ["客队攻击/防守", describeSideForm(formGuide?.away)],
  ];
  el.teamCompare.innerHTML = rows.map(metricHtml).join("");
}

function renderInjuries(data) {
  const signals = data.research?.signals || {};
  const structured = data.research?.structured || {};
  const footballData = structured.footballData;
  const formGuide = structured.formGuide || signals.form;
  const fifa = structured.fifa;
  const match = data.match;
  const rows = [
    [teamLabel(match.home), `伤停信号 ${signals.homeInjuryScore ?? 0}，证据 ${signals.homeInjuryEvidence?.length || 0} 条`],
    [teamLabel(match.away), `伤停信号 ${signals.awayInjuryScore ?? 0}，证据 ${signals.awayInjuryEvidence?.length || 0} 条`],
    ["官方名单", footballData?.available ? `主队 ${footballData.teams?.home?.squadCount ?? "--"} 人 / 客队 ${footballData.teams?.away?.squadCount ?? "--"} 人` : "暂无 football-data 名单"],
    ["主教练", footballData?.available ? `${footballData.teams?.home?.coach || "--"} / ${footballData.teams?.away?.coach || "--"}` : "--"],
    ["阵容", `首发/大名单信号 ${signals.lineupScore ?? 0}`],
    ["网页伤停", `主队证据 ${signals.homeInjuryEvidence?.slice(0, 2).map((item) => item.title || item.domain).join("；") || "暂无"} / 客队证据 ${signals.awayInjuryEvidence?.slice(0, 2).map((item) => item.title || item.domain).join("；") || "暂无"}`],
  ];
  el.injuryInfo.innerHTML = rows.map(metricHtml).join("");
}

function renderMatchSimulation(data) {
  if (!el.simulationInfo || !el.simulationBadge) return;
  const match = data.match;
  const simulation = data.prediction?.simulation;
  if (!simulation?.available) {
    el.simulationBadge.textContent = "暂无推演";
    el.simulationInfo.innerHTML = `
      <div class="simulation-card">
        <span>比赛模拟</span>
        <strong>等待深度分析</strong>
        <p>当前缺少足够的阵容、战术或盘口信号。</p>
      </div>
    `;
    return;
  }

  const actualMode = simulation.mode === "actual";
  el.simulationBadge.textContent = actualMode
    ? `实际复盘 · ${simulation.confidence?.label || "赛果已确认"}`
    : `${data.mode === "quick" ? "快速" : "深度"} · 可信度 ${simulation.confidence?.label || "--"} ${simulation.confidence?.score ?? "--"}`;
  const score = simulation.scoreboard || {};
  const corners = simulation.setPieces?.corners || {};
  const cards = simulation.setPieces?.cards || {};
  const tactics = simulation.tactics || [];
  const events = simulation.events || [];
  const conclusion = simulation.conclusion || [];
  const report = simulation.layeredReport || {};
  const phases = simulation.phases || [];
  const keyDuels = simulation.keyDuels || [];
  const triggers = simulation.triggers || [];

  el.simulationInfo.innerHTML = `
    <div class="simulation-report">
      <div class="simulation-report-head">
        <span>${escapeHtml(report.mode || "分层推演")}</span>
        <strong>${escapeHtml(localizeText(report.headline || "按比赛时间轴模拟", match))}</strong>
        <p>${escapeHtml((report.meta || []).map((item) => localizeText(item, match)).join(" / ") || simulation.sourceSummary || "--")}</p>
      </div>
      <div class="simulation-layer-grid">
        ${(report.layers || []).map((layer) => simulationLayerHtml(layer, match)).join("")}
      </div>
    </div>
    ${
      phases.length
        ? `<div class="simulation-phases">
            <div class="simulation-section-title">时间轴阶段推演</div>
            ${phases.map((phase) => simulationPhaseHtml(phase, match)).join("")}
          </div>`
        : ""
    }
    <div class="simulation-card simulation-score">
      <span>${actualMode ? "实际终局" : "模拟终局"}</span>
      <strong>${escapeHtml(teamLabel(match.home))} ${escapeHtml(score.score || "--")} ${escapeHtml(teamLabel(match.away))}</strong>
      <p>${escapeHtml(localizeText(score.reason || simulation.sourceSummary || "--", match))}</p>
    </div>
    <div class="simulation-card">
      <span>${actualMode ? "角球复盘" : "角球模拟"}</span>
      <strong>${escapeHtml(teamLabel(match.home))} ${escapeHtml(String(corners.home ?? "--"))} - ${escapeHtml(String(corners.away ?? "--"))} ${escapeHtml(teamLabel(match.away))}</strong>
      <p>总角球约 ${escapeHtml(String(corners.total ?? "--"))} 个；${escapeHtml(localizeText(corners.recommendation || "角球大小观望", match))}。</p>
    </div>
    <div class="simulation-card">
      <span>${actualMode ? "罚牌复盘" : "罚牌模拟"}</span>
      <strong>${escapeHtml(teamLabel(match.home))} ${escapeHtml(String(cards.home ?? "--"))} - ${escapeHtml(String(cards.away ?? "--"))} ${escapeHtml(teamLabel(match.away))}</strong>
      <p>总罚牌约 ${escapeHtml(String(cards.total ?? "--"))} 张；${escapeHtml(localizeText(cards.recommendation || "罚牌大小观望", match))}。</p>
    </div>
    <div class="simulation-card simulation-rhythm">
      <span>比赛节奏</span>
      <strong>${escapeHtml(simulation.rhythm?.tempo || "--")}</strong>
      <p>${escapeHtml(localizeText([simulation.rhythm?.control, simulation.rhythm?.pressure, simulation.rhythm?.weather].filter(Boolean).join("；"), match))}</p>
    </div>
    <div class="simulation-tactics">
      ${tactics.map((tactic) => simulationTacticHtml(tactic, match)).join("")}
    </div>
    ${
      keyDuels.length || triggers.length
        ? `<div class="simulation-insights">
            <div class="simulation-section-title">关键对位与临场触发</div>
            ${keyDuels.map((duel) => simulationDuelHtml(duel, match)).join("")}
            ${triggers.map((trigger) => simulationTriggerHtml(trigger, match)).join("")}
          </div>`
        : ""
    }
    <div class="simulation-timeline">
      <div class="simulation-section-title">${actualMode ? "实际比赛记录" : "事件流推演"}</div>
      ${events.map((event) => simulationEventHtml(event, match)).join("")}
    </div>
    <div class="simulation-conclusion">
      <div class="simulation-section-title">${actualMode ? "复盘结论" : "推演结论"}</div>
      ${conclusion.map((item) => `<p>${escapeHtml(localizeText(item, match))}</p>`).join("")}
    </div>
  `;
}

function simulationLayerHtml(layer, match) {
  return `
    <div class="simulation-layer ${escapeHtml(layer.tone || "")}">
      <span>${escapeHtml(layer.title || "推演层")}</span>
      ${(layer.points || []).map((point) => `<p>${escapeHtml(localizeText(point, match))}</p>`).join("")}
    </div>
  `;
}

function simulationPhaseHtml(phase, match) {
  return `
    <div class="simulation-phase">
      <div>
        <span>${escapeHtml(phase.range || "--")}</span>
        <strong>${escapeHtml(localizeText(phase.title || "--", match))}</strong>
      </div>
      <p>${escapeHtml(localizeText(phase.text || "--", match))}</p>
      <div class="simulation-phase-meta">
        <em>控场：${escapeHtml(localizeText(phase.dominant || "--", match))}</em>
        <em>xG：${escapeHtml(localizeText(phase.xg || "--", match))}</em>
        <em>角球：${escapeHtml(localizeText(phase.cornerRisk || "--", match))}</em>
        <em>牌面：${escapeHtml(localizeText(phase.cardRisk || "--", match))}</em>
      </div>
    </div>
  `;
}

function simulationDuelHtml(duel, match) {
  return `
    <div class="simulation-duel">
      <span>对位 · ${escapeHtml(localizeText(duel.edge || "--", match))}</span>
      <strong>${escapeHtml(localizeText(duel.title || "--", match))}</strong>
      <p>${escapeHtml(localizeText(duel.detail || "--", match))}</p>
    </div>
  `;
}

function simulationTriggerHtml(trigger, match) {
  return `
    <div class="simulation-trigger">
      <span>触发 · ${escapeHtml(localizeText(trigger.level || "--", match))}</span>
      <strong>${escapeHtml(localizeText(trigger.label || "--", match))}</strong>
      <p>${escapeHtml(localizeText(trigger.text || "--", match))}</p>
    </div>
  `;
}

function simulationTacticHtml(tactic, match) {
  return `
    <div class="simulation-tactic">
      <div>
        <span>${escapeHtml(tactic.side === "home" ? "主队战术" : "客队战术")}</span>
        <strong>${escapeHtml(localizeText(tactic.team || "--", match))} · ${escapeHtml(tactic.formation || "--")}</strong>
      </div>
      <p>${escapeHtml(localizeText(tactic.approach || "--", match))}</p>
      <em>${escapeHtml(localizeText(tactic.attackLane || "--", match))}</em>
      <em>${escapeHtml(localizeText(tactic.defensivePlan || "--", match))}</em>
      <em>${escapeHtml(localizeText(tactic.risk || "--", match))}</em>
    </div>
  `;
}

function simulationEventHtml(event, match) {
  const sideLabel = event.side === "home"
    ? teamLabel(match.home)
    : event.side === "away"
    ? teamLabel(match.away)
    : "比赛";
  return `
    <div class="simulation-event ${event.side === "home" ? "home" : event.side === "away" ? "away" : ""}">
      <span>${escapeHtml(event.minute || "--")}</span>
      <strong>${escapeHtml(event.type || "--")} · ${escapeHtml(sideLabel)}</strong>
      <p>${escapeHtml(localizeText(event.text || "--", match))}</p>
    </div>
  `;
}

function renderLineups(data) {
  if (!el.lineupInfo || !el.lineupBadge) return;
  const match = data.match;
  const projection = data.research?.structured?.lineupProjection || {};
  const confidence = projection.confidence || {};
  el.lineupBadge.textContent = `${data.mode === "quick" ? "快速" : "深度"} · 可信度 ${confidence.label || "--"} ${confidence.score ?? "--"}`;

  const cards = ["home", "away"].map((side) => lineupCardHtml(projection[side], match?.[side], match));
  const comparison = projection.comparison || {};
  el.lineupInfo.innerHTML = `
    ${cards.join("")}
    <div class="lineup-compare">
      <div><span>阵容信号</span><strong>${escapeHtml(String(comparison.lineupSignal ?? 0))}</strong></div>
      <div><span>伤停差值</span><strong>${escapeHtml(formatSignedNumber(comparison.injuryEdge ?? 0))}</strong></div>
      <div><span>证据条数</span><strong>${escapeHtml(String(comparison.evidenceCount ?? 0))}</strong></div>
      <div><span>来源</span><strong>${escapeHtml(localizeText(projection.source || "等待深度分析", match))}</strong></div>
    </div>
  `;
}

function lineupCardHtml(lineup, team, match) {
  const label = lineup?.team || teamLabel(team);
  const xi = (lineup?.predictedXI || []).slice(0, 11);
  const evidence = (lineup?.evidence || []).slice(0, 2);
  const bench = (lineup?.benchCandidates || []).slice(0, 4);
  return `
    <div class="lineup-card">
      <div class="lineup-team">
        <strong>${escapeHtml(localizeText(label, match))}</strong>
        <span>${escapeHtml(localizeText(lineup?.formation || "待确认", match))} · 伤停风险 ${escapeHtml(localizeText(lineup?.injuryRisk || "--", match))}</span>
      </div>
      <div class="lineup-meta">
        <span>主教练：${escapeHtml(localizeText(lineup?.coach || "--", match))}</span>
        <span>名单：${escapeHtml(String(lineup?.squadCount ?? "--"))} 人</span>
      </div>
      <div class="lineup-xi">
        ${xi.length ? xi.map((player) => lineupPlayerHtml(player, match)).join("") : `<span class="lineup-empty">首发待确认</span>`}
      </div>
      <div class="lineup-note">${escapeHtml(localizeText(lineup?.formationReason || lineup?.source || "官方首发未公布，当前为候选预测。", match))}</div>
      ${
        bench.length
          ? `<div class="lineup-bench"><span>替补候选</span><strong>${escapeHtml(bench.map((player) => `${officialPersonName(player.name)}（${playerPositionZh(player)}）`).join("、"))}</strong></div>`
          : ""
      }
      ${
        evidence.length
          ? `<div class="lineup-evidence">${evidence.map((item) => `<span>${escapeHtml(localizeText(item.text || item.domain || "阵容线索", match))}</span>`).join("")}</div>`
          : ""
      }
    </div>
  `;
}

function lineupPlayerHtml(player, match) {
  const isPending = player.name === "待确认";
  return `
    <span class="${isPending ? "pending" : ""}">
      <b>${escapeHtml(officialPersonName(player.name || "待确认"))}</b>
      <em>${escapeHtml(playerPositionZh(player, match))}</em>
    </span>
  `;
}

function officialPersonName(value) {
  return String(value || "待确认");
}

function playerPositionZh(player, match) {
  return localizeText(player?.positionZh || player?.slot || player?.position || "候选", match);
}

function renderFactors(factors) {
  const match = state.lastAnalysis?.match || selectedMatch();
  el.factors.innerHTML = factors
    .map(
      (factor) => `
        <div class="factor">
          <strong><span>${escapeHtml(localizeText(factor.name, match))}</span><em>${escapeHtml(localizeText(factor.impact, match))}</em></strong>
          <p>${escapeHtml(localizeText(factor.detail, match))}</p>
        </div>
      `
    )
    .join("");
}

function renderScoreChips(scores) {
  el.scoreChips.innerHTML = scores
    .map(
      (score) => `
        <div class="score-chip ${score.primary ? "primary" : ""}">
          <strong>${escapeHtml(score.score)}</strong>
          <span>${score.primary ? "主推 · " : ""}${percent(score.probability)}</span>
        </div>
      `
    )
    .join("");
}

function renderActualScoreCompact(context, prediction) {
  const prematch = context.prematch || {};
  const actual = context.actual || {};
  const liveModel = context.liveModel || {};
  const sportteryScore = prematch.sportteryScore || {};
  const items = [
    {
      label: "实际比分",
      score: actual.score || "--",
      meta: actual.source || "赛果已确认",
      active: true,
    },
    {
      label: "赛前推荐",
      score: prematch.recommendedScore || "--",
      meta: prematch.recommendedProbability !== null && prematch.recommendedProbability !== undefined
        ? percent(prematch.recommendedProbability)
        : prematch.generatedAt
        ? formatTime(prematch.generatedAt)
        : "--",
    },
    {
      label: "体彩锚点",
      score: sportteryScore.score || sportteryScore.pick || "--",
      meta: sportteryScore.logicVersion ? "已按新逻辑" : "--",
    },
    {
      label: "当前复盘",
      score: liveModel.score || prediction.primaryScore?.score || "--",
      meta: liveModel.probability !== null && liveModel.probability !== undefined
        ? percent(liveModel.probability)
        : "仅作复盘",
    },
  ];
  el.scoreCompact.innerHTML = `
    <div class="score-mini-title">赛后对账</div>
    <div class="score-mini-list score-mini-review">
      ${items
        .map(
          (item) => `
            <span class="${item.active ? "active actual" : ""}">
              <small>${escapeHtml(item.label)}</small>
              <strong>${escapeHtml(item.score)}</strong>
              <em>${escapeHtml(item.meta)}</em>
            </span>
          `
        )
        .join("")}
    </div>
  `;
}

function renderScoreCompact(scores) {
  const top = (scores || []).slice(0, 4);
  el.scoreCompact.innerHTML = `
    <div class="score-mini-title">候选比分</div>
    <div class="score-mini-list">
      ${
        top.length
          ? top
              .map(
                (score) => `
                  <span class="${score.primary ? "active" : ""}">
                    <strong>${escapeHtml(score.score)}</strong>
                    <em>${percent(score.probability)}</em>
                  </span>
                `
              )
              .join("")
          : "<span>--</span><span>--</span><span>--</span>"
      }
    </div>
  `;
}

function renderSources() {
  const data = state.lastAnalysis;
  if (!data?.research) {
    el.sources.innerHTML = `<div class="source-item"><p>完成一次分析后显示网页来源。</p></div>`;
    return;
  }

  const tab = state.selectedTab;
  const groups = data.research.searchGroups || [];
  const crawled = data.research.crawled || [];
  const structured = data.research.structured || {};
  const items = [];

  if (tab === "intel" || tab === "all") {
    for (const check of data.dataChecks || []) {
      items.push({
        title: `数据核对：${check.label}`,
        text: check.detail,
        url: "",
        domain: check.level || "",
        label: check.ok ? "已核对" : "需复查",
        type: "数据校验",
      });
    }
    const intel = data.prediction?.intelligence24h;
    if (intel?.available) {
      items.push({
        title: intel.headline,
        text: `${(intel.summary || []).join(" ")} 推荐：${intel.recommendation?.pick || "--"}。${intel.recommendation?.reason || ""}`,
        url: "",
        domain: intel.status === "recent_verified" ? "近24小时新闻" : "搜索摘要补充",
        label: `来源 ${intel.sourceCount || 0} 条`,
        type: "24小时情报",
      });
      for (const source of intel.sources || []) {
        items.push({
          title: source.title,
          text: source.snippet,
          url: source.url,
          domain: source.domain,
          label: source.recent ? "近24小时" : "未标发布时间",
          type: "情报来源",
        });
      }
    }
  }

  if (tab === "odds" || tab === "all") {
    if (structured.footballData?.available) {
      items.push({
        title: "football-data 比赛状态/赔率包状态",
        text: `${structured.footballData.match?.status || "--"}；${structured.footballData.match?.oddsMessage || "当前套餐未返回赔率字段。"}`,
        url: structured.footballData.source,
        domain: "api.football-data.org",
        label: "结构化比赛数据",
        type: "football-data API",
      });
    }
    const espnOdds = structured.espn?.odds;
    if (espnOdds?.available) {
      items.push({
        title: `ESPN / ${espnOdds.provider || "Odds provider"} 盘口摘要`,
        text: `盘口：${espnOdds.details || "--"}；大小球：${espnOdds.overUnder ?? "--"}；让球：${formatSpreadSummary(espnOdds.spread)}`,
        url: structured.espn?.scoreboardUrl,
        domain: "site.api.espn.com",
        label: "结构化盘口",
        type: "ESPN API",
      });
    }
    const derivativeMarkets = data.prediction?.derivativeMarkets;
    if (derivativeMarkets?.available) {
      items.push({
        title: "角球/罚牌盘口信号",
        text: `${derivativeMarkets.sourceSummary || "网页盘口信号"}；${[
          derivativeMarkets.corners?.total?.recommendation?.pick,
          derivativeMarkets.corners?.handicap?.recommendation?.pick,
          derivativeMarkets.cards?.total?.recommendation?.pick,
          derivativeMarkets.cards?.handicap?.recommendation?.pick,
        ].filter(Boolean).join("；")}`,
        url: "",
        domain: "网页抓取 + 模型推导",
        label: "衍生盘口",
        type: "角球/罚牌",
      });
    }
    const platform = data.prediction?.bettingPlatform;
    if (platform?.available) {
      items.push({
        title: "赛事分析平台总控台",
        text: `${platform.headline || "--"}；数据源 ${platform.sourceHealth?.totalSources ?? 0} 个，命中 ${platform.sourceHealth?.sourceHits ?? 0} 条，采纳盘口 ${platform.sourceHealth?.acceptedMarkets ?? 0} 项，冲突 ${platform.sourceHealth?.conflictCount ?? 0} 项。`,
        url: "",
        domain: "平台总控",
        label: platform.consistency?.ok ? "一致性通过" : "已降级",
        type: "博彩数据平台",
      });
      for (const item of (platform.marketMatrix || []).slice(0, 10)) {
        items.push({
          title: `盘口矩阵：${item.market}`,
          text: `${item.pick}；状态 ${item.status}；置信 ${item.confidence}；来源 ${(item.sources || []).join("、") || "模型/缓存"}；${item.note || ""}`,
          url: "",
          domain: "多源盘口矩阵",
          label: item.status || "观望",
          type: "玩法推荐",
        });
      }
    }
  }

  if (tab === "lineups" || tab === "all") {
    const lineupProjection = structured.lineupProjection;
    if (lineupProjection?.available) {
      const simulation = data.prediction?.simulation;
      const tacticText = simulation?.tactics?.length
        ? simulation.tactics.map((tactic) => `${tactic.team} ${tactic.formation}：${tactic.approach}`).join("；")
        : `${lineupProjection.home?.team || teamLabel(data.match.home)} ${lineupProjection.home?.formation || "--"}；${lineupProjection.away?.team || teamLabel(data.match.away)} ${lineupProjection.away?.formation || "--"}`;
      items.push({
        title: "阵容战术模拟输入",
        text: `${tacticText}。可信度 ${lineupProjection.confidence?.label || "--"} ${lineupProjection.confidence?.score ?? "--"}；不展示英文球员名单，仅作为战术推演输入。`,
        url: structured.footballData?.source || structured.espn?.summaryUrl || "",
        domain: lineupProjection.source || "阵容战术推演",
        label: "战术输入",
        type: "模拟推演",
      });
    }

    if (structured.fifa?.available) {
      items.push({
        title: "FIFA 官方男子国家队排名",
        text: describeFifaRankings(structured.fifa, data.match),
        url: structured.fifa.source,
        domain: "api.fifa.com",
        label: "国际排名",
        type: "FIFA API",
      });
    }

    if (structured.formGuide?.available) {
      items.push({
        title: "近期战绩与历史交锋聚合",
        text: `${describeDetailedForm(structured.formGuide)} ${describeHeadToHead(structured.formGuide.headToHead, data.match)}`,
        url: structured.espn?.summaryUrl || structured.footballData?.source || "",
        domain: "ESPN / football-data / TheSportsDB",
        label: "近10场与交锋",
        type: "结构化战绩",
      });
    }

    if (structured.footballData?.available) {
      for (const [side, team] of Object.entries(structured.footballData.teams || {})) {
        if (!team) continue;
        items.push({
          title: `football-data 官方名单：${team.name}`,
          text: `${team.coach ? `主教练 ${team.coach}。` : ""}名单 ${team.squadCount || 0} 人：${(team.squad || [])
            .slice(0, 18)
            .map((player) => `${player.name}${player.position ? `（${positionTextZh(player.position)}）` : ""}`)
            .join("，")}`,
          url: structured.footballData.source,
          domain: "api.football-data.org",
          label: side === "home" ? "主队名单" : "客队名单",
          type: "football-data API",
        });
      }
    }

    if (structured.espn?.available) {
      items.push({
        title: "ESPN 近期状态",
        text: describeDetailedForm(structured.espn.form),
        url: structured.espn.summaryUrl,
        domain: "site.api.espn.com",
        label: "状态/赛前信息",
        type: "ESPN API",
      });
      for (const video of structured.espn.videos || []) {
        items.push({
          title: video.title,
          text: video.description,
          url: video.url,
          domain: "espn.com",
          label: "赛前视频/分析",
          type: "ESPN",
        });
      }
    }

    for (const [side, team] of Object.entries(structured.sportsDb?.teams || {})) {
      if (!team) continue;
      items.push({
        title: `TheSportsDB 球队资料：${team.name}`,
        text: team.description || `${team.name} · ${team.league || ""} · ${team.stadium || ""}`,
        url: team.website ? `https://${team.website.replace(/^https?:\/\//, "")}` : "",
        domain: "thesportsdb.com",
        label: side === "home" ? "主队资料" : "客队资料",
        type: "TheSportsDB",
      });
    }
  }

  if (tab === "venue" || tab === "all") {
    if (structured.sportsDb?.event) {
      items.push({
        title: `TheSportsDB 赛事：${structured.sportsDb.event.name}`,
        text: `${structured.sportsDb.event.league || ""} · ${structured.sportsDb.event.date || ""} ${structured.sportsDb.event.time || ""} · ${structured.sportsDb.event.venue || ""} ${structured.sportsDb.event.city || ""}`,
        url: structured.sportsDb.eventUrl,
        domain: "thesportsdb.com",
        label: "赛事元数据",
        type: "TheSportsDB",
      });
    }
    if (structured.espn?.available) {
      items.push({
        title: `ESPN 赛事：${structured.espn.name}`,
        text: `${structured.espn.date || ""} · ${structured.espn.venue || ""} · ${structured.espn.status || ""}`,
        url: structured.espn.links?.[0]?.href || structured.espn.scoreboardUrl,
        domain: "espn.com",
        label: "赛事/球场",
        type: "ESPN",
      });
    }
  }

  for (const group of groups) {
    const include =
      tab === "all" ||
      (tab === "intel" && group.side === "intel") ||
      (tab === "odds" && group.side === "odds") ||
      (tab === "lineups" && ["home", "away", "match"].includes(group.side)) ||
      (tab === "venue" && group.side === "venue");
    if (!include) continue;
    for (const result of group.results || []) {
      items.push({
        title: result.title || group.label,
        text: result.snippet,
        url: result.url,
        domain: result.domain,
        label: group.label,
        type: "搜索摘要",
      });
    }
  }

  for (const page of crawled) {
    const include =
      tab === "all" ||
      (tab === "intel" && page.side === "intel") ||
      (tab === "odds" && page.side === "odds") ||
      (tab === "lineups" && ["home", "away", "match"].includes(page.side)) ||
      (tab === "venue" && page.side === "venue");
    if (!include) continue;
    items.unshift({
      title: page.title || page.h1 || page.domain,
      text: page.text,
      url: page.url,
      domain: page.domain,
      label: page.groupLabel,
      type: "网页正文",
    });
  }

  const odds = data.odds;
  if (tab === "odds" || tab === "all") {
    if (odds?.available) {
      items.unshift({
        title: "The Odds API 实时赔率均值",
        text: describeOddsMarkets(odds.markets || []),
        url: odds.source,
        domain: "the-odds-api.com",
        label: "赔率 API",
        type: "结构化赔率",
      });
    } else if (odds?.message && !structured.espn?.odds?.available && !structured.footballData?.available) {
      items.push({
        title: "实时赔率 API 状态",
        text: odds.message,
        url: "",
        domain: "本地后端",
        label: "赔率 API",
        type: "状态",
      });
    }
  }

  el.sources.innerHTML = items.length
    ? items.slice(0, 32).map(sourceHtml).join("")
    : `<div class="source-item"><p>当前分类没有抓取到可展示来源。</p></div>`;
}

function describeForm(form) {
  const home = form?.home;
  const away = form?.away;
  if (!home?.matches || !away?.matches) return "暂无足够近期状态样本";
  return `主近 ${home.matches} 场 ${home.wins ?? 0}胜${home.draws ?? 0}平${home.losses ?? 0}负，PPG ${home.pointsPerGame ?? "--"} / 净胜 ${home.goalDiffPerGame ?? "--"}；客近 ${away.matches} 场 ${away.wins ?? 0}胜${away.draws ?? 0}平${away.losses ?? 0}负，PPG ${away.pointsPerGame ?? "--"} / 净胜 ${away.goalDiffPerGame ?? "--"}`;
}

function describeSideForm(side) {
  if (!side?.matches) return "暂无样本";
  return `场均进球 ${side.goalsForPerGame ?? "--"}，场均失球 ${side.goalsAgainstPerGame ?? "--"}，净胜 ${side.goalDiffPerGame ?? "--"}`;
}

function describeDetailedForm(form) {
  const home = form?.home;
  const away = form?.away;
  if (!home || !away) return "暂无近期状态数据。";
  return [
    `主队：近 ${home.matches || 0} 场 ${home.wins ?? 0}胜${home.draws ?? 0}平${home.losses ?? 0}负，PPG ${home.pointsPerGame ?? "--"}，场均进球 ${home.goalsForPerGame ?? "--"}，场均失球 ${home.goalsAgainstPerGame ?? "--"}。`,
    `客队：近 ${away.matches || 0} 场 ${away.wins ?? 0}胜${away.draws ?? 0}平${away.losses ?? 0}负，PPG ${away.pointsPerGame ?? "--"}，场均进球 ${away.goalsForPerGame ?? "--"}，场均失球 ${away.goalsAgainstPerGame ?? "--"}。`,
  ].join(" ");
}

function describeFifaRankings(fifa, match) {
  const home = fifa?.teams?.home;
  const away = fifa?.teams?.away;
  if (!home?.rank || !away?.rank) return "暂无完整 FIFA 排名";
  const rankGap = Math.abs(home.rank - away.rank);
  const pointGap = Math.abs((home.points ?? 0) - (away.points ?? 0));
  return `${teamLabel(match.home)} 第 ${home.rank}（${home.points ?? "--"}分） / ${teamLabel(match.away)} 第 ${away.rank}（${away.points ?? "--"}分），差 ${rankGap} 位、${pointGap.toFixed(1)} 分`;
}

function describeCompactRank(fifa, match) {
  const home = fifa?.teams?.home;
  const away = fifa?.teams?.away;
  if (!home?.rank || !away?.rank) return "暂无";
  return `${teamLabel(match.home)} #${home.rank} / ${teamLabel(match.away)} #${away.rank}`;
}

function describeHeadToHead(headToHead, match) {
  if (!headToHead?.matches) return "未找到可验证正式交锋，样本不足";
  return `近样本 ${headToHead.matches} 场：${teamLabel(match.home)} ${headToHead.wins ?? 0}胜${headToHead.draws ?? 0}平${headToHead.losses ?? 0}负`;
}

function metricHtml([label, value]) {
  const match = state.lastAnalysis?.match || selectedMatch();
  return `
    <div class="metric">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(localizeText(value, match))}</strong>
    </div>
  `;
}

function sourceHtml(item) {
  const match = state.lastAnalysis?.match || selectedMatch();
  const titleText = localizeText(item.title || item.domain || "来源", match);
  const title = item.url
    ? `<a href="${escapeAttribute(item.url)}" target="_blank" rel="noreferrer">${escapeHtml(titleText)}</a>`
    : `<strong>${escapeHtml(titleText)}</strong>`;
  return `
    <div class="source-item">
      ${title}
      <div class="source-meta">
        <span>${escapeHtml(localizeText(item.type || "", match))}</span>
        <span>${escapeHtml(localizeText(item.label || "", match))}</span>
        <span>${escapeHtml(item.domain || "")}</span>
      </div>
      <p>${escapeHtml(localizeText(item.text || "无摘要", match)).slice(0, 520)}</p>
    </div>
  `;
}

function describeOddsMarkets(markets) {
  return markets
    .map((market) => {
      if (market.key === "h2h") {
        return `胜平负均值：主 ${market.homeAvg || "--"}，平 ${market.drawAvg || "--"}，客 ${market.awayAvg || "--"}。`;
      }
      return `${market.label}：${(market.lines || [])
        .slice(0, 4)
        .map((line) => `${line.name} ${line.point ?? ""} @${line.price}`)
        .join("；")}`;
    })
    .join(" ");
}

function selectedMatch() {
  const id = el.matchSelect.value;
  return state.matches.find((match) => match.id === id) || state.filtered[0] || state.matches[0];
}

function setFlag(node, teamOrUrl) {
  const team = typeof teamOrUrl === "string" ? null : teamOrUrl;
  const rawUrl = typeof teamOrUrl === "string" ? teamOrUrl : teamOrUrl?.flag || "";
  const flagUrl = teamFlagUrl(team) || rawUrl;
  node.onerror = () => {
    if (rawUrl && node.src !== rawUrl) {
      node.src = rawUrl;
      return;
    }
    node.style.visibility = "hidden";
  };
  node.src = flagUrl || "";
  node.style.visibility = flagUrl ? "visible" : "hidden";
}

function teamFlagUrl(team) {
  const code = String(team?.code || "").toUpperCase();
  const iso = FLAG_ISO_BY_CODE[code];
  return iso ? `https://flagcdn.com/w80/${iso}.png` : "";
}

function setStatus(value) {
  el.appStatus.textContent = value;
}

function setLoading(active) {
  el.loadingOverlay.classList.toggle("hidden", !active);
}

function showError(message) {
  el.recommendations.innerHTML = `
    <div class="recommendation">
      <strong>分析失败</strong>
      <span>${escapeHtml(message)}</span>
    </div>
  `;
  el.sources.innerHTML = `
    <div class="source-item">
      <strong>发生错误</strong>
      <p>${escapeHtml(message)}</p>
    </div>
  `;
}

function friendlyFetchError(error) {
  const message = String(error?.message || error || "");
  if (/failed to fetch|networkerror|load failed|无法连接|远程服务器/i.test(message)) {
    return "后端服务暂时未连接，请用桌面快捷方式重新打开工具；如果正在深度抓取，请等待几秒后点刷新。";
  }
  if (/abort/i.test(message)) return "本次分析已被新的场次选择中断。";
  return message || "接口请求失败，请刷新后重试。";
}

function refreshIcons() {
  if (window.lucide) window.lucide.createIcons();
}

function percent(value) {
  const number = Number(value) || 0;
  return `${(number * 100).toFixed(1)}%`;
}

function formatDateTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value || "--");
  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function formatNullablePercent(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "--";
  return percent(value);
}

function formatLine(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "--";
  return Number.isInteger(number) ? String(number) : number.toFixed(1);
}

function formatAmerican(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "--";
  return number > 0 ? `+${number}` : String(number);
}

function formatSpreadSummary(spread) {
  if (!spread) return "--";
  if (typeof spread === "string" || typeof spread === "number") return String(spread);
  const line = spread.line ?? spread.point ?? spread.value;
  const homeOdds = formatAmerican(spread.homeOdds);
  const awayOdds = formatAmerican(spread.awayOdds);
  return `${line ?? "--"}${homeOdds !== "--" || awayOdds !== "--" ? `（主 ${homeOdds} / 客 ${awayOdds}）` : ""}`;
}

function formatSignedNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "--";
  return `${number >= 0 ? "+" : ""}${number.toFixed(1)}`;
}

function valueOrDash(value) {
  return value === null || value === undefined || Number.isNaN(Number(value)) ? "--" : value;
}

function labelStage(match) {
  if (match.type === "group") return `小组 ${match.group}`;
  const table = {
    r32: "三十二强",
    r16: "十六强",
    qf: "四分之一决赛",
    sf: "半决赛",
    final: "决赛",
    third: "三四名决赛",
  };
  return table[String(match.type || "").toLowerCase()] || match.group || "赛程";
}

function teamLabel(team) {
  if (!team) return "待定";
  return team.displayName || TEAM_ZH[team.code] || NAME_ZH[team.name] || NAME_ZH[normalizeDisplayKey(team.name)] || team.name || "待定";
}

function venueName(venue) {
  const raw = venue?.name || venue?.fifaName || "";
  return VENUE_ZH[raw] || raw;
}

function cityName(value) {
  return CITY_ZH[value] || value || "";
}

function countryName(value) {
  return COUNTRY_ZH[value] || NAME_ZH[value] || NAME_ZH[normalizeDisplayKey(value)] || value || "";
}

function localizeText(value, match) {
  let text = applyTextReplacements(String(value ?? ""));
  for (const team of [match?.home, match?.away]) {
    if (!team?.name) continue;
    text = text.replaceAll(team.name, teamLabel(team));
    if (team.code) text = text.replaceAll(team.code, teamLabel(team));
  }
  for (const [name, zh] of Object.entries(NAME_ZH).sort((a, b) => b[0].length - a[0].length)) {
    text = text.replaceAll(name, zh);
  }
  for (const [code, zh] of Object.entries(TEAM_ZH)) {
    text = text.replace(new RegExp(`(^|[^A-Z])${escapeRegExp(code)}(?=$|[^A-Z])`, "g"), `$1${zh}`);
  }
  return applyTextReplacements(text);
}

function applyTextReplacements(value) {
  let text = String(value ?? "").replace(/\uFFFD+/g, "");
  for (const [from, to] of TEXT_REPLACEMENTS) {
    const escaped = escapeRegExp(from);
    const asciiWord = /^[A-Za-z0-9 .:+-]+$/.test(from);
    const lowerFrom = from.toLowerCase();
    const pattern = lowerFrom === "over" || lowerFrom === "under"
      ? new RegExp(`(^|[^A-Za-z])${escaped}(?=\\s*\\d)`, "gi")
      : asciiWord
      ? new RegExp(`(^|[^A-Za-z])${escaped}(?=$|[^A-Za-z])`, "gi")
      : new RegExp(escaped, "g");
    text = text.replace(pattern, asciiWord ? `$1${to}` : to);
  }
  return text;
}

function positionTextZh(value) {
  const text = String(value || "");
  const lower = text.toLowerCase();
  if (/goalkeeper|keeper|gk|goal/.test(lower)) return "门将";
  if (/left[-\s]?back|lb/.test(lower)) return "左后卫";
  if (/right[-\s]?back|rb/.test(lower)) return "右后卫";
  if (/centre[-\s]?back|center[-\s]?back|central defender|cb/.test(lower)) return "中后卫";
  if (/full[-\s]?back|wing[-\s]?back/.test(lower)) return "边后卫";
  if (/defender|defence|defense|back/.test(lower)) return "后卫";
  if (/defensive midfield|holding midfield|dm/.test(lower)) return "防守型中场";
  if (/attacking midfield|am/.test(lower)) return "攻击型中场";
  if (/central midfield|centre midfield|center midfield|cm/.test(lower)) return "中前卫";
  if (/midfielder|midfield/.test(lower)) return "中场";
  if (/left winger|left wing|lw/.test(lower)) return "左边锋";
  if (/right winger|right wing|rw/.test(lower)) return "右边锋";
  if (/winger|wing/.test(lower)) return "边锋";
  if (/centre[-\s]?forward|center[-\s]?forward|striker|forward|attack|fw|st/.test(lower)) return "前锋";
  if (/substitute|bench|替补/.test(lower)) return "替补候选";
  return localizeText(text || "候选");
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function normalizeDisplayKey(value) {
  return String(value || "").trim();
}

function formatTime(value) {
  if (!value) return "--";
  try {
    return new Intl.DateTimeFormat("zh-CN", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }).format(new Date(value));
  } catch {
    return value;
  }
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}
