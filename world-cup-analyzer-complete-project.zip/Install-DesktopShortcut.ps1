$ErrorActionPreference = "Stop"

$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = Join-Path $AppDir "Open-WorldCupAnalyzer.cmd"
$Desktop = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $Desktop "World Cup Analyzer.lnk"

if (-not (Test-Path $Target)) {
  throw "Launcher script was not found: $Target"
}

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($ShortcutPath)
$shortcut.TargetPath = $Target
$shortcut.WorkingDirectory = $AppDir
$shortcut.Description = "Start World Cup Analyzer"
$shortcut.Save()

Write-Host "Desktop shortcut created: $ShortcutPath"
