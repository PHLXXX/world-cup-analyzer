# 长期在线部署说明

这个项目是 Node.js + Express 常驻服务，不能只放到静态网页托管；需要 Render、Railway、Fly.io、Koyeb 等能运行 Node 服务的平台。生产版本建议使用 Node 22 LTS，本项目已在 `package.json` 固定为 `22.x`。

## 当前已准备好的内容

- `render.yaml`：Render Blueprint 配置。
- `railway.json`：Railway Nixpacks 配置。
- `Dockerfile`：通用容器部署。
- `Procfile`：支持 Procfile 的 Node Web 平台。
- `world-cup-analyzer-longterm-deploy.zip`：可上传的最新部署包。
- `/api/health`：云平台健康检查接口。

## 推荐方案：Render

1. 把本项目上传到 GitHub/GitLab/Bitbucket 仓库，或把 `world-cup-analyzer-longterm-deploy.zip` 解压后上传。
2. 在 Render 创建 Blueprint，选择仓库根目录的 `render.yaml`。
3. Render 会按配置执行：
   - Build Command: `npm ci`
   - Start Command: `npm start`
   - Health Check: `/api/health`
4. 环境变量建议填写：
   - `NODE_ENV=production`
   - `HOST=0.0.0.0`
   - `FOOTBALL_DATA_API_KEY=你的 football-data key`
   - `ODDS_API_KEY=你的 The Odds API key，可选`
   - `PINNACLE_GUEST_API_KEY=你的盘口源 key，可选`
5. 部署成功后，Render 会给出一个长期 HTTPS 地址，例如 `https://world-cup-analyzer.onrender.com`。

## 备用方案：Railway

1. Railway 新建 Project，选择从 GitHub 仓库部署。
2. Railway 会读取 `railway.json`：
   - Build: `npm ci`
   - Start: `npm start`
   - Health Check: `/api/health`
3. 在 Variables 里补齐同样的环境变量。
4. 生成公开域名后即可分享给任何人使用。

## 持久化提醒

历史推荐统计保存在 `data/prediction-history.json`，角球/罚牌缓存保存在 `data/derivative-market-cache.json`。如果云平台重启后文件系统会清空，需要开启平台的持久磁盘，或后续接数据库；不配置持久化也能访问网站，只是历史统计可能随重启丢失。

## 当前机器的限制

当前电脑没有检测到 `git`、`gh`、`railway`、`render` CLI，也没有 Render/Railway/GitHub 部署 token。我已经把项目整理成可部署包，但无法在没有账号授权的情况下替你完成最后的云端发布。

要让我继续完成最终发布，需要满足其中一个条件：

1. 你登录 Render/Railway 并让我接管浏览器操作。
2. 你提供对应平台的部署 token。
3. 你先把这个目录上传到 GitHub 仓库，我继续帮你连接云平台。
