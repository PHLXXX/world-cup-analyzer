param(
  [Parameter(Mandatory = $true)][string]$OutLog,
  [Parameter(Mandatory = $true)][string]$PublicInfo,
  [Parameter(Mandatory = $true)][string]$RunLog,
  [int]$TimeoutSeconds = 90
)

$ErrorActionPreference = "Stop"

function Write-RunLog {
  param([string]$Message)
  Add-Content -LiteralPath $RunLog -Value "$(Get-Date -Format o) $Message" -Encoding UTF8
}

function Read-TunnelUrl {
  if (-not (Test-Path $OutLog)) { return "" }
  try {
    $text = Get-Content -LiteralPath $OutLog -Raw -ErrorAction Stop
  } catch {
    return ""
  }
  $match = [regex]::Match($text, "https://[a-z0-9-]+\.loca\.lt")
  if ($match.Success) { return $match.Value }
  return ""
}

Write-RunLog "waiter started for $OutLog"

$deadline = (Get-Date).AddSeconds($TimeoutSeconds)
$url = ""
while ((Get-Date) -lt $deadline) {
  $url = Read-TunnelUrl
  if ($url) { break }
  Start-Sleep -Milliseconds 800
}

if (-not $url) {
  Write-RunLog "waiter timed out"
  exit 1
}

$password = ""
try {
  $password = (Invoke-WebRequest -UseBasicParsing -Uri "https://loca.lt/mytunnelpassword" -TimeoutSec 20).Content.Trim()
} catch {
  $password = "If localtunnel asks for a password, open https://loca.lt/mytunnelpassword on this computer."
}

$content = @"
World Cup Analyzer public URL

URL:
$url

LocalTunnel password, if prompted:
$password

Notes:
- Keep this computer on.
- Keep the World Cup Analyzer and this tunnel process running.
- This is a temporary public link. For a permanent product link, deploy the app to Render, Railway, Fly.io, or Cloudflare.
"@

Set-Content -LiteralPath $PublicInfo -Value $content -Encoding UTF8
Write-RunLog "waiter wrote public info for $url"
