import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const HISTORY_FILE = path.join(ROOT, "data", "prediction-history.json");
const REPORT_FILE = path.join(ROOT, "data", "sporttery-anchor-v2-migration-report.json");
const LOGIC_VERSION = "sporttery-anchor-v2";

function main() {
  const history = JSON.parse(fs.readFileSync(HISTORY_FILE, "utf8"));
  const predictions = history.predictions || {};
  const beforeRecords = JSON.parse(JSON.stringify(predictions));
  const changes = [];

  for (const [matchId, record] of Object.entries(predictions)) {
    const sporttery = record.sporttery;
    if (!sporttery?.available || !sporttery.items) continue;
    const migrated = migrateSportteryRecord(record);
    if (!migrated) continue;
    const before = summarizeRecordSporttery(record);
    record.sporttery = migrated;
    const after = summarizeRecordSporttery(record);
    if (JSON.stringify(before) !== JSON.stringify(after)) {
      changes.push({
        matchId,
        match: `${record.home || "--"} vs ${record.away || "--"}`,
        matchNum: sporttery.matchNum || "",
        generatedAt: record.generatedAt || "",
        anchorScore: migrated.alignment?.anchorScore || "",
        switchedFromPrimary: Boolean(migrated.alignment?.switchedFromPrimary),
        before,
        after,
      });
    }
  }

  const now = new Date().toISOString();
  const backupFile = path.join(
    ROOT,
    "data",
    `prediction-history.backup-${LOGIC_VERSION}-${now.replace(/[:.]/g, "-")}.json`
  );
  fs.copyFileSync(HISTORY_FILE, backupFile);
  history.updatedAt = now;
  history.migrations = [
    ...(Array.isArray(history.migrations) ? history.migrations : []),
    {
      version: LOGIC_VERSION,
      migratedAt: now,
      changedRecords: changes.length,
      backupFile: path.relative(ROOT, backupFile).replaceAll("\\", "/"),
    },
  ];
  fs.writeFileSync(HISTORY_FILE, `${JSON.stringify(history, null, 2)}\n`, "utf8");

  const report = {
    version: LOGIC_VERSION,
    migratedAt: now,
    totalSportteryRecords: Object.values(beforeRecords).filter((record) => record.sporttery?.available).length,
    changedRecords: changes.length,
    backupFile: path.relative(ROOT, backupFile).replaceAll("\\", "/"),
    changes,
  };
  fs.writeFileSync(REPORT_FILE, `${JSON.stringify(report, null, 2)}\n`, "utf8");
  console.log(JSON.stringify(report, null, 2));
}

function migrateSportteryRecord(record) {
  const old = record.sporttery;
  const oldItems = old.items || {};
  const matrix = scoreMatrix(Number(record.expectedGoals?.home), Number(record.expectedGoals?.away), 8);
  const probabilities = summarizeMatrix(matrix);
  const anchor = buildAnchor({ record, probabilities, oldItems });
  const items = {};

  if (oldItems.result) {
    items.result = buildResultItem({ record, oldItem: oldItems.result, probabilities, anchor });
  }
  if (oldItems.handicap) {
    items.handicap = buildHandicapItem({ record, oldItem: oldItems.handicap, matrix, anchor });
  }
  if (oldItems.totalGoals) {
    items.totalGoals = buildTotalGoalsItem({ oldItem: oldItems.totalGoals, matrix, anchor });
  }
  if (oldItems.score) {
    items.score = buildScoreItem({ oldItem: oldItems.score, anchor, scorePortfolio: record.topScores || [] });
  }

  const alignment = validateAlignment(items, anchor);
  return {
    ...old,
    logicVersion: LOGIC_VERSION,
    migratedAt: new Date().toISOString(),
    items,
    alignment,
  };
}

function buildAnchor({ record, probabilities, oldItems }) {
  const candidates = buildAnchorCandidates(record);
  const fallback = candidates[0] || makeCandidate({ score: "0-0", probability: 0 });
  const strongest = strongestResult(probabilities);
  const primarySideProbability = resultProbability(probabilities, fallback.resultSide);
  const shouldFollowAggregate =
    strongest.side !== fallback.resultSide &&
    strongest.probability >= 0.36 &&
    strongest.probability - primarySideProbability >= 0.045;
  const preferredSide = shouldFollowAggregate ? strongest.side : fallback.resultSide;
  const preferred = chooseAnchorCandidate(candidates, preferredSide) || fallback;
  const line = Number(oldItems.handicap?.line);
  const homeGoals = Number(preferred.homeGoals);
  const awayGoals = Number(preferred.awayGoals);
  return {
    ...preferred,
    homeGoals,
    awayGoals,
    score: preferred.score || `${homeGoals}-${awayGoals}`,
    scoreKey: sportteryScoreKey(homeGoals, awayGoals),
    resultSide: scoreDirection({ home: homeGoals, away: awayGoals }),
    totalGoals: sportteryTotalGoalsBucket(homeGoals + awayGoals),
    totalGoalCount: homeGoals + awayGoals,
    handicapLine: Number.isFinite(line) ? line : null,
    handicapSide: Number.isFinite(line) ? sportteryHandicapSide(homeGoals, awayGoals, line) : null,
    aggregateSide: strongest.side,
    aggregateProbability: strongest.probability,
    switchedFromPrimary: Boolean(fallback.score && preferred.score && fallback.score !== preferred.score),
    primaryScore: fallback.score || "",
  };
}

function buildAnchorCandidates(record) {
  const seen = new Set();
  const raw = [...arrayFrom(record.topScores), { score: record.recommendedScore, probability: record.recommendedProbability }];
  return raw
    .filter((item) => item?.score)
    .map((item) => makeCandidate(item))
    .filter((item) => item && !seen.has(item.score) && seen.add(item.score));
}

function makeCandidate(item = {}) {
  const parsed = parseScoreText(item.score);
  const homeGoals = Number.isFinite(Number(item.homeGoals)) ? Number(item.homeGoals) : parsed.home;
  const awayGoals = Number.isFinite(Number(item.awayGoals)) ? Number(item.awayGoals) : parsed.away;
  if (!Number.isFinite(homeGoals) || !Number.isFinite(awayGoals)) return null;
  const score = item.score || `${homeGoals}-${awayGoals}`;
  return {
    score,
    homeGoals,
    awayGoals,
    scoreKey: sportteryScoreKey(homeGoals, awayGoals),
    resultSide: scoreDirection({ home: homeGoals, away: awayGoals }),
    probability: Number(item.probability || 0),
  };
}

function chooseAnchorCandidate(candidates, preferredSide) {
  const sameSide = arrayFrom(candidates).filter((item) => item.resultSide === preferredSide);
  return sameSide[0] || candidates[0];
}

function buildResultItem({ record, oldItem, probabilities, anchor }) {
  const options = [
    { side: "home", probability: probabilities.homeWin },
    { side: "draw", probability: probabilities.draw },
    { side: "away", probability: probabilities.awayWin },
  ];
  const pick = options.find((item) => item.side === anchor.resultSide) || options[0];
  return pickItem({
    ...oldItem,
    marketKey: "result",
    market: "胜平负",
    pick: sportteryResultLabel(pick.side, record),
    side: pick.side,
    probability: pick.probability,
    odds: oldItem.side === pick.side ? oldItem.odds : null,
    confidence: confidenceLabel(probabilityEdge(pick, options)),
  });
}

function buildHandicapItem({ record, oldItem, matrix, anchor }) {
  const line = Number(oldItem.line);
  const distribution = sportteryHandicapDistribution(matrix, line);
  const options = [
    { side: "home", probability: distribution.home },
    { side: "draw", probability: distribution.draw },
    { side: "away", probability: distribution.away },
  ];
  const pick = options.find((item) => item.side === anchor.handicapSide) || options[0];
  return pickItem({
    ...oldItem,
    marketKey: "handicap",
    market: "让球胜平负",
    pick: sportteryHandicapResultLabel(pick.side, line, record),
    side: pick.side,
    line,
    probability: pick.probability,
    odds: oldItem.side === pick.side ? oldItem.odds : null,
    confidence: confidenceLabel(probabilityEdge(pick, options)),
  });
}

function buildTotalGoalsItem({ oldItem, matrix, anchor }) {
  const distribution = sportteryTotalGoalsDistribution(matrix);
  const options = Object.entries(distribution).map(([bucket, probability]) => ({ side: bucket, probability }));
  const pick = options.find((item) => item.side === anchor.totalGoals) || options[0];
  return pickItem({
    ...oldItem,
    marketKey: "totalGoals",
    market: "总进球数",
    pick: `${sportteryTotalGoalsLabel(pick.side)}球`,
    side: pick.side,
    totalGoals: pick.side,
    probability: pick.probability,
    odds: String(oldItem.side) === String(pick.side) ? oldItem.odds : null,
    confidence: confidenceLabel(probabilityEdge(pick, options)),
  });
}

function buildScoreItem({ oldItem, anchor, scorePortfolio }) {
  const otherBest = arrayFrom(scorePortfolio)
    .filter((item) => item?.score !== anchor.score)
    .reduce((max, item) => Math.max(max, Number(item.probability || 0)), 0);
  return pickItem({
    ...oldItem,
    marketKey: "score",
    market: "比分",
    pick: sportteryScoreLabel(anchor.scoreKey, anchor.score),
    side: anchor.scoreKey,
    scoreKey: anchor.scoreKey,
    score: anchor.score,
    probability: anchor.probability,
    odds: oldItem.scoreKey === anchor.scoreKey ? oldItem.odds : null,
    confidence: confidenceLabel(Number(anchor.probability || 0) - otherBest),
  });
}

function validateAlignment(items, anchor) {
  const issues = [];
  if (items.result && items.result.side !== anchor.resultSide) issues.push("胜平负与比分锚点不一致");
  if (items.handicap && anchor.handicapSide && items.handicap.side !== anchor.handicapSide) issues.push("让球胜平负与比分锚点不一致");
  if (items.totalGoals && String(items.totalGoals.totalGoals) !== String(anchor.totalGoals)) issues.push("总进球数与比分锚点不一致");
  if (items.score && items.score.scoreKey !== anchor.scoreKey) issues.push("比分与锚点不一致");
  return {
    ok: issues.length === 0,
    issues,
    anchorScore: anchor.score,
    resultSide: anchor.resultSide,
    handicapSide: anchor.handicapSide,
    handicapLine: anchor.handicapLine,
    totalGoals: anchor.totalGoals,
    switchedFromPrimary: anchor.switchedFromPrimary,
    primaryScore: anchor.primaryScore,
  };
}

function summarizeRecordSporttery(record) {
  const items = record.sporttery?.items || {};
  return {
    result: items.result?.pick || "",
    handicap: items.handicap?.pick || "",
    totalGoals: items.totalGoals?.pick || "",
    score: items.score?.pick || "",
  };
}

function pickItem(item) {
  const probability = numberOrNull(item.probability);
  const odds = oddsOrNull(item.odds);
  const valueIndex = Number.isFinite(probability) && Number.isFinite(odds)
    ? Number((probability * odds).toFixed(2))
    : null;
  return {
    ...item,
    probability,
    odds,
    valueIndex,
  };
}

function scoreMatrix(homeXg, awayXg, maxGoals) {
  const homeLambda = Number.isFinite(homeXg) && homeXg > 0 ? homeXg : 1.25;
  const awayLambda = Number.isFinite(awayXg) && awayXg > 0 ? awayXg : 1.05;
  const matrix = [];
  for (let home = 0; home <= maxGoals; home += 1) {
    const row = [];
    for (let away = 0; away <= maxGoals; away += 1) {
      row.push(poisson(home, homeLambda) * poisson(away, awayLambda));
    }
    matrix.push(row);
  }
  return matrix;
}

function summarizeMatrix(matrix) {
  let homeWin = 0;
  let draw = 0;
  let awayWin = 0;
  let totalMass = 0;
  for (let home = 0; home < matrix.length; home += 1) {
    for (let away = 0; away < matrix[home].length; away += 1) {
      const p = matrix[home][away] || 0;
      totalMass += p;
      if (home > away) homeWin += p;
      else if (home === away) draw += p;
      else awayWin += p;
    }
  }
  return {
    homeWin: homeWin / (totalMass || 1),
    draw: draw / (totalMass || 1),
    awayWin: awayWin / (totalMass || 1),
  };
}

function sportteryHandicapDistribution(matrix, line) {
  const out = { home: 0, draw: 0, away: 0 };
  for (let home = 0; home < matrix.length; home += 1) {
    for (let away = 0; away < matrix[home].length; away += 1) {
      const side = sportteryHandicapSide(home, away, line);
      out[side] += matrix[home][away] || 0;
    }
  }
  return normalizeDistribution(out);
}

function sportteryTotalGoalsDistribution(matrix) {
  const out = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0 };
  for (let home = 0; home < matrix.length; home += 1) {
    for (let away = 0; away < matrix[home].length; away += 1) {
      out[sportteryTotalGoalsBucket(home + away)] += matrix[home][away] || 0;
    }
  }
  return normalizeDistribution(out);
}

function normalizeDistribution(distribution) {
  const total = Object.values(distribution).reduce((sum, value) => sum + Number(value || 0), 0) || 1;
  return Object.fromEntries(Object.entries(distribution).map(([key, value]) => [key, Number(value || 0) / total]));
}

function strongestResult(probabilities = {}) {
  return [
    { side: "home", probability: resultProbability(probabilities, "home") },
    { side: "draw", probability: resultProbability(probabilities, "draw") },
    { side: "away", probability: resultProbability(probabilities, "away") },
  ].sort((a, b) => b.probability - a.probability)[0];
}

function resultProbability(probabilities = {}, side) {
  if (side === "home") return Number(probabilities.homeWin || 0);
  if (side === "away") return Number(probabilities.awayWin || 0);
  return Number(probabilities.draw || 0);
}

function sportteryHandicapSide(homeGoals, awayGoals, line) {
  const adjustedHome = Number(homeGoals) + Number(line || 0);
  if (adjustedHome > Number(awayGoals)) return "home";
  if (adjustedHome < Number(awayGoals)) return "away";
  return "draw";
}

function sportteryScoreKey(homeGoals, awayGoals) {
  const h = Number(homeGoals);
  const a = Number(awayGoals);
  if (!Number.isFinite(h) || !Number.isFinite(a)) return "";
  if (h === a) return h <= 3 ? `s${String(h).padStart(2, "0")}s${String(a).padStart(2, "0")}` : "s1sd";
  if (h > a) {
    const exact = h >= 1 && h <= 5 && a >= 0 && a <= 2;
    return exact ? `s${String(h).padStart(2, "0")}s${String(a).padStart(2, "0")}` : "s1sh";
  }
  const exact = a >= 1 && a <= 5 && h >= 0 && h <= 2;
  return exact ? `s${String(h).padStart(2, "0")}s${String(a).padStart(2, "0")}` : "s1sa";
}

function sportteryScoreLabel(key, fallback = "") {
  if (key === "s1sh") return "胜其他";
  if (key === "s1sd") return "平其他";
  if (key === "s1sa") return "负其他";
  const match = String(key || "").match(/^s(\d{2})s(\d{2})$/);
  if (!match) return fallback || "--";
  return `${Number(match[1])}-${Number(match[2])}`;
}

function sportteryTotalGoalsBucket(total) {
  const goals = Number(total);
  if (!Number.isFinite(goals)) return "0";
  return String(Math.min(7, Math.max(0, Math.round(goals))));
}

function sportteryTotalGoalsLabel(bucket) {
  return String(bucket) === "7" ? "7+" : String(bucket);
}

function sportteryResultLabel(side, record) {
  if (side === "home") return `${record.home || "主队"} 胜`;
  if (side === "away") return `${record.away || "客队"} 胜`;
  return "平局";
}

function sportteryHandicapResultLabel(side, line, record) {
  const direction = side === "home" ? "让胜" : side === "away" ? "让负" : "让平";
  return `${direction}（${record.home || "主队"} ${formatSignedLine(line)}）`;
}

function scoreDirection(score) {
  if (score.home > score.away) return "home";
  if (score.home < score.away) return "away";
  return "draw";
}

function parseScoreText(score) {
  const match = String(score || "").match(/(\d+)\s*[-:]\s*(\d+)/);
  return {
    home: match ? Number(match[1]) : 0,
    away: match ? Number(match[2]) : 0,
  };
}

function probabilityEdge(pick, options) {
  const others = arrayFrom(options).filter((item) => item.side !== pick.side);
  const next = others.reduce((max, item) => Math.max(max, Number(item.probability || 0)), 0);
  return Number(pick.probability || 0) - next;
}

function confidenceLabel(edge) {
  if (edge >= 0.32) return "高";
  if (edge >= 0.18) return "中高";
  if (edge >= 0.1) return "中";
  return "中低";
}

function formatSignedLine(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "--";
  return number > 0 ? `+${trimNumber(number)}` : trimNumber(number);
}

function trimNumber(value) {
  return Number(value).toFixed(2).replace(/\.00$/, "").replace(/(\.\d)0$/, "$1");
}

function poisson(k, lambda) {
  return (Math.exp(-lambda) * Math.pow(lambda, k)) / factorial(k);
}

const factorialMemo = [1];
function factorial(n) {
  if (factorialMemo[n]) return factorialMemo[n];
  let value = factorialMemo[factorialMemo.length - 1];
  for (let i = factorialMemo.length; i <= n; i += 1) {
    value *= i;
    factorialMemo[i] = value;
  }
  return factorialMemo[n];
}

function numberOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function oddsOrNull(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : null;
}

function arrayFrom(value) {
  return Array.isArray(value) ? value : [];
}

main();
