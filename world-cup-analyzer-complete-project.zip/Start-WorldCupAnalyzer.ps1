param(
  [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"

$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Port = 5177
$HealthUrl = "http://127.0.0.1:$Port/api/health"
$AppUrl = "http://127.0.0.1:$Port/"
$OutLog = Join-Path $AppDir "server.out.log"
$ErrLog = Join-Path $AppDir "server.err.log"

function Test-AnalyzerHealth {
  try {
    $response = Invoke-WebRequest -Uri $HealthUrl -UseBasicParsing -TimeoutSec 2
    return $response.StatusCode -eq 200
  } catch {
    return $false
  }
}

function Get-NodeCommand {
  $cmd = Get-Command node -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  throw "Node.js was not found. Install Node.js and try again."
}

if (-not (Test-Path (Join-Path $AppDir "server.js"))) {
  throw "server.js was not found in $AppDir"
}

if (-not (Test-Path (Join-Path $AppDir "node_modules"))) {
  Push-Location $AppDir
  try {
    npm install
  } finally {
    Pop-Location
  }
}

if (-not (Test-AnalyzerHealth)) {
  $node = Get-NodeCommand
  $portOwner = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($portOwner) {
    throw "Port $Port is occupied by process $($portOwner.OwningProcess), but the health check failed."
  }

  Start-Process `
    -FilePath $node `
    -ArgumentList "server.js" `
    -WorkingDirectory $AppDir `
    -RedirectStandardOutput $OutLog `
    -RedirectStandardError $ErrLog `
    -WindowStyle Hidden
}

$deadline = (Get-Date).AddSeconds(35)
while ((Get-Date) -lt $deadline) {
  if (Test-AnalyzerHealth) {
    if (-not $NoBrowser) {
      Start-Process $AppUrl
    }
    exit 0
  }
  Start-Sleep -Milliseconds 600
}

$errorTail = ""
if (Test-Path $ErrLog) {
  $errorTail = (Get-Content $ErrLog -Tail 40 -ErrorAction SilentlyContinue) -join "`n"
}

throw "World Cup Analyzer startup timed out. Error log:`n$errorTail"
