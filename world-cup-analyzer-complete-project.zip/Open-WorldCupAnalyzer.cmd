@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-WorldCupAnalyzer.ps1"
if errorlevel 1 (
  echo.
  echo Startup failed. Please send the error above to Codex.
  pause
)
