import express from "express";
import * as cheerio from "cheerio";
import { execFile } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import http from "node:http";
import https from "node:https";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { brotliDecompressSync, gunzipSync, inflateSync } from "node:zlib";

loadLocalEnv();

const app = express();
const PORT = Number(process.env.PORT || 5177);
const HOST = process.env.HOST || "0.0.0.0";
const ANALYZE_RATE_LIMIT = Number(process.env.ANALYZE_RATE_LIMIT || 120);
const RATE_LIMIT_WINDOW_MS = Number(process.env.RATE_LIMIT_WINDOW_MS || 15 * 60 * 1000);
const execFileAsync = promisify(execFile);
const PUBLIC_DIR = fileURLToPath(new URL("public/", import.meta.url));
const INDEX_HTML = fileURLToPath(new URL("public/index.html", import.meta.url));

const WORLD_CUP_API = "https://worldcup26.ir/get";
const BING_SEARCH = "https://www.bing.com/search";
const BING_NEWS_RSS = "https://www.bing.com/news/search";
const DDG_HTML = "https://html.duckduckgo.com/html/";
const FOOTBALL_DATA_API = "https://api.football-data.org/v4";
const FIFA_RANKINGS_API = "https://api.fifa.com/api/v3/rankings/";
const OPEN_METEO_FORECAST = "https://api.open-meteo.com/v1/forecast";
const OPEN_METEO_ELEVATION = "https://api.open-meteo.com/v1/elevation";
const OPEN_METEO_GEOCODING = "https://geocoding-api.open-meteo.com/v1/search";
const NOMINATIM_SEARCH = "https://nominatim.openstreetmap.org/search";
const ODDS_SPORT_KEY = "soccer_fifa_world_cup";
const ESPN_SCOREBOARD = "https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/scoreboard";
const ESPN_SUMMARY = "https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/summary";
const SPORTS_DB = "https://www.thesportsdb.com/api/v1/json/3";
const PINNACLE_GUEST_API = "https://guest.api.arcadia.pinnacle.com/0.1";
const PINNACLE_API_KEY = process.env.PINNACLE_GUEST_API_KEY || "CmX2KcMrXuFmNg6YFbmTxE0y9CIrOi0R";
const PINNACLE_WORLD_CUP_LEAGUE_ID = 2686;
const SPORTTERY_API = "https://webapi.sporttery.cn/gateway/uniform/football/getMatchCalculatorV1.qry";
const SPORTTERY_PAGE = "https://www.sporttery.cn/jc/jsq/zqspf/";
const SPORTTERY_POOL_CODE = "had,hhad,crs,ttg";
const ODDS_API_CORE_MARKETS = "h2h,spreads,totals";
const ODDS_API_EXTENDED_MARKETS = process.env.ODDS_API_MARKETS || [
  "h2h",
  "spreads",
  "totals",
  "btts",
  "draw_no_bet",
  "alternate_spreads",
  "alternate_totals",
  "team_totals",
].join(",");
const GLOBAL_BETTING_SOURCE_CATALOG = [
  {
    id: "sporttery",
    label: "中国体彩网/竞彩网",
    category: "官方竞彩",
    domains: ["sporttery.cn", "webapi.sporttery.cn", "竞彩网", "中国体彩网"],
    markets: ["胜平负", "让球胜平负", "总进球数", "比分"],
    direct: true,
  },
  {
    id: "pinnacle",
    label: "Pinnacle",
    category: "博彩公司直连",
    domains: ["guest.api.arcadia.pinnacle.com", "pinnacle.com"],
    markets: ["胜平负", "让球", "大小球", "角球", "罚牌"],
    direct: true,
  },
  {
    id: "odds-api",
    label: "The Odds API",
    category: "可选赔率 API",
    domains: ["the-odds-api.com"],
    markets: ["胜平负", "让球", "大小球", "扩展特殊盘"],
    requiresKey: true,
  },
  {
    id: "espn-draftkings",
    label: "ESPN / DraftKings",
    category: "结构化摘要",
    domains: ["espn.com", "site.api.espn.com", "draftkings.com"],
    markets: ["胜平负", "让球", "大小球"],
    direct: true,
  },
  {
    id: "oddspedia",
    label: "Oddspedia",
    category: "全球赔率聚合",
    domains: ["oddspedia.com"],
    markets: ["胜平负", "让球", "大小球", "角球/牌摘要"],
  },
  {
    id: "oddsportal",
    label: "OddsPortal",
    category: "全球赔率聚合",
    domains: ["oddsportal.com"],
    markets: ["胜平负", "让球", "大小球", "盘口历史"],
  },
  {
    id: "oddschecker",
    label: "OddsChecker",
    category: "赔率比较",
    domains: ["oddschecker.com"],
    markets: ["胜平负", "大小球", "让球", "特殊盘"],
  },
  {
    id: "betexplorer",
    label: "BetExplorer",
    category: "赔率比较",
    domains: ["betexplorer.com"],
    markets: ["胜平负", "让球", "大小球"],
  },
  {
    id: "leisu-kaiyun",
    label: "雷速 / 开云",
    category: "中文盘口",
    domains: ["leisu.com", "kaiyun.com", "雷速", "开云"],
    markets: ["角球", "罚牌", "让球", "大小球"],
  },
  {
    id: "bet365-betfair",
    label: "bet365 / Betfair",
    category: "博彩公司网页",
    domains: ["bet365", "betfair.com"],
    markets: ["胜平负", "让球", "大小球", "特殊盘"],
  },
  {
    id: "uk-books",
    label: "Betway / Unibet / William Hill",
    category: "欧洲博彩公司",
    domains: ["betway", "unibet", "williamhill", "bwin", "ladbrokes", "coral"],
    markets: ["胜平负", "让球", "大小球", "角球/牌摘要"],
  },
  {
    id: "us-books",
    label: "FanDuel / BetMGM",
    category: "北美博彩公司",
    domains: ["fanduel", "betmgm", "caesars", "pointsbet"],
    markets: ["胜平负", "让球", "大小球", "特殊盘"],
  },
  {
    id: "tips-global",
    label: "全球预测站",
    category: "比分/投注技巧",
    domains: ["sportsmole", "forebet", "predictz", "windrawwin", "betclan", "bettingexpert", "freesupertips", "mightytips"],
    markets: ["比分", "赛果", "大小球", "让球"],
  },
  {
    id: "stats-props",
    label: "技术统计站",
    category: "角球/牌趋势",
    domains: ["footystats", "statbunker", "sofascore", "fotmob", "whoscored", "flashscore"],
    markets: ["角球趋势", "罚牌趋势", "近期状态"],
  },
];
const SPORTTERY_TEAM_CODE_ALIASES = {
  AUA: "AUS",
  BOS: "BIH",
  BRZ: "BRA",
  CAA: "CAN",
  CUR: "CUW",
  HAT: "HAI",
  MCO: "MAR",
  NET: "NED",
  PGY: "PAR",
  SWI: "SUI",
  URY: "URU",
};
const DERIVATIVE_COVERAGE_WINDOW_MS = 24 * 60 * 60 * 1000;
const DERIVATIVE_COVERAGE_REFRESH_MS = 5 * 60 * 1000;
const PREDICTION_HISTORY_FILE = new URL("data/prediction-history.json", import.meta.url);
const MATCH_ID_ALIAS_FILE = new URL("data/match-id-aliases.json", import.meta.url);
const DERIVATIVE_MARKET_CACHE_FILE = new URL("data/derivative-market-cache.json", import.meta.url);
const DERIVATIVE_MARKET_CACHE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const DEFAULT_RESEARCH_QUERY_LIMIT = Number(process.env.RESEARCH_QUERY_LIMIT || 24);
const DEFAULT_RESEARCH_CRAWL_LIMIT = Number(process.env.RESEARCH_CRAWL_LIMIT || 16);
const QUICK_SPORTTERY_TIMEOUT_MS = Number(process.env.QUICK_SPORTTERY_TIMEOUT_MS || 3500);
const FULL_SPORTTERY_TIMEOUT_MS = Number(process.env.FULL_SPORTTERY_TIMEOUT_MS || 5500);
const SEARCH_CACHE_TTL_MS = Number(process.env.SEARCH_CACHE_TTL_MS || 15 * 60 * 1000);
const CRAWL_CACHE_TTL_MS = Number(process.env.CRAWL_CACHE_TTL_MS || 30 * 60 * 1000);
const SEARCH_SOURCE_TIMEOUT_MS = Number(process.env.SEARCH_SOURCE_TIMEOUT_MS || 4000);
const CRAWL_PAGE_TIMEOUT_MS = Number(process.env.CRAWL_PAGE_TIMEOUT_MS || 5000);

process.on("unhandledRejection", (reason) => {
  console.error("[unhandledRejection]", reason?.stack || reason);
});

process.on("uncaughtException", (error) => {
  console.error("[uncaughtException]", error?.stack || error);
});

const HOST_CITY_GEO = {
  "Mexico City": { lat: 19.3029, lon: -99.1505, label: "Mexico City, Mexico" },
  "Los Angeles": { lat: 33.9535, lon: -118.3392, label: "Inglewood, United States" },
  "San Francisco Bay Area": { lat: 37.403, lon: -121.97, label: "Santa Clara, United States" },
  "New York/New Jersey": { lat: 40.8135, lon: -74.0745, label: "East Rutherford, United States" },
  Boston: { lat: 42.0909, lon: -71.2643, label: "Foxborough, United States" },
  Vancouver: { lat: 49.2768, lon: -123.1119, label: "Vancouver, Canada" },
  Houston: { lat: 29.6847, lon: -95.4107, label: "Houston, United States" },
  Dallas: { lat: 32.7473, lon: -97.0945, label: "Arlington, United States" },
  Philadelphia: { lat: 39.9008, lon: -75.1675, label: "Philadelphia, United States" },
  Monterrey: { lat: 25.6686, lon: -100.2448, label: "Guadalupe, Mexico" },
  Seattle: { lat: 47.5952, lon: -122.3316, label: "Seattle, United States" },
  Miami: { lat: 25.958, lon: -80.2389, label: "Miami Gardens, United States" },
  "Kansas City": { lat: 39.0489, lon: -94.4839, label: "Kansas City, United States" },
  Toronto: { lat: 43.6332, lon: -79.4186, label: "Toronto, Canada" },
  Guadalajara: { lat: 20.6819, lon: -103.4628, label: "Zapopan, Mexico" },
  Atlanta: { lat: 33.7554, lon: -84.4008, label: "Atlanta, United States" },
};

const HOST_CITY_TIMEZONE = {
  "Mexico City": "America/Mexico_City",
  "Los Angeles": "America/Los_Angeles",
  "San Francisco Bay Area": "America/Los_Angeles",
  "New York/New Jersey": "America/New_York",
  Boston: "America/New_York",
  Vancouver: "America/Vancouver",
  Houston: "America/Chicago",
  Dallas: "America/Chicago",
  Philadelphia: "America/New_York",
  Monterrey: "America/Monterrey",
  Seattle: "America/Los_Angeles",
  Miami: "America/New_York",
  "Kansas City": "America/Chicago",
  Toronto: "America/Toronto",
  Guadalajara: "America/Mexico_City",
  Atlanta: "America/New_York",
};

const HOST_CITY_CLIMATE = {
  "Mexico City": { temperature: 23, humidity: 50, precipitationProbability: 45, windSpeed: 12, condition: "高原温和，午后有阵雨概率" },
  "Los Angeles": { temperature: 22, humidity: 63, precipitationProbability: 8, windSpeed: 14, condition: "沿海温和，降雨概率低" },
  "San Francisco Bay Area": { temperature: 19, humidity: 70, precipitationProbability: 10, windSpeed: 17, condition: "湾区偏凉，风速略有影响" },
  "New York/New Jersey": { temperature: 25, humidity: 66, precipitationProbability: 30, windSpeed: 13, condition: "夏季偏暖，存在雷阵雨窗口" },
  Boston: { temperature: 24, humidity: 68, precipitationProbability: 30, windSpeed: 13, condition: "新英格兰夏季温和，湿度中等" },
  Vancouver: { temperature: 18, humidity: 72, precipitationProbability: 35, windSpeed: 11, condition: "温哥华偏凉，降雨概率中等" },
  Houston: { temperature: 31, humidity: 74, precipitationProbability: 38, windSpeed: 15, condition: "休斯敦高温高湿，体能消耗偏高" },
  Dallas: { temperature: 32, humidity: 55, precipitationProbability: 25, windSpeed: 17, condition: "德州炎热，风速可能影响长传" },
  Philadelphia: { temperature: 27, humidity: 65, precipitationProbability: 32, windSpeed: 12, condition: "费城夏季偏暖，湿度中等" },
  Monterrey: { temperature: 31, humidity: 58, precipitationProbability: 24, windSpeed: 13, condition: "蒙特雷炎热，比赛节奏可能下调" },
  Seattle: { temperature: 20, humidity: 69, precipitationProbability: 25, windSpeed: 10, condition: "西雅图温和，降雨概率中低" },
  Miami: { temperature: 30, humidity: 76, precipitationProbability: 45, windSpeed: 16, condition: "迈阿密湿热，雷阵雨概率偏高" },
  "Kansas City": { temperature: 29, humidity: 64, precipitationProbability: 35, windSpeed: 16, condition: "堪萨斯城偏热，天气波动中等" },
  Toronto: { temperature: 23, humidity: 63, precipitationProbability: 28, windSpeed: 12, condition: "多伦多温和，湿度中等" },
  Guadalajara: { temperature: 27, humidity: 55, precipitationProbability: 42, windSpeed: 12, condition: "瓜达拉哈拉高原偏暖，午后降雨概率中等" },
  Atlanta: { temperature: 29, humidity: 70, precipitationProbability: 38, windSpeed: 11, condition: "亚特兰大湿热，室内球场影响较小" },
};

const REQUEST_HEADERS = {
  "User-Agent":
    "WorldCupAnalyzer/1.0 (+local desktop tool; contact: local-user) Mozilla/5.0",
  "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
};

const TEAM_NAME_ZH = {
  ALG: "阿尔及利亚",
  ARG: "阿根廷",
  AUS: "澳大利亚",
  AUT: "奥地利",
  BOL: "玻利维亚",
  BEL: "比利时",
  BIH: "波黑",
  BRA: "巴西",
  CAN: "加拿大",
  CHI: "智利",
  CPV: "佛得角",
  COL: "哥伦比亚",
  COD: "刚果（金）",
  CRO: "克罗地亚",
  CUW: "库拉索",
  CZE: "捷克",
  DEN: "丹麦",
  ECU: "厄瓜多尔",
  EGY: "埃及",
  ENG: "英格兰",
  FIN: "芬兰",
  FRA: "法国",
  GER: "德国",
  GHA: "加纳",
  GRE: "希腊",
  HAI: "海地",
  HON: "洪都拉斯",
  HUN: "匈牙利",
  IRN: "伊朗",
  IRQ: "伊拉克",
  IRL: "爱尔兰",
  ISR: "以色列",
  ITA: "意大利",
  CIV: "科特迪瓦",
  JPN: "日本",
  JOR: "约旦",
  KSA: "沙特阿拉伯",
  KOR: "韩国",
  MLI: "马里",
  MAR: "摩洛哥",
  MEX: "墨西哥",
  NED: "荷兰",
  NGA: "尼日利亚",
  NIR: "北爱尔兰",
  NOR: "挪威",
  NZL: "新西兰",
  PER: "秘鲁",
  PAN: "巴拿马",
  PAR: "巴拉圭",
  POL: "波兰",
  POR: "葡萄牙",
  QAT: "卡塔尔",
  ROU: "罗马尼亚",
  RSA: "南非",
  SRB: "塞尔维亚",
  SCO: "苏格兰",
  SEN: "塞内加尔",
  SVK: "斯洛伐克",
  ESP: "西班牙",
  SUI: "瑞士",
  SWE: "瑞典",
  TUN: "突尼斯",
  TUR: "土耳其",
  USA: "美国",
  URU: "乌拉圭",
  URY: "乌拉圭",
  UZB: "乌兹别克斯坦",
  VEN: "委内瑞拉",
  WAL: "威尔士",
  UAE: "阿联酋",
  CRC: "哥斯达黎加",
  JAM: "牙买加",
};

Object.assign(TEAM_NAME_ZH, {
  Algeria: "阿尔及利亚",
  Argentina: "阿根廷",
  Australia: "澳大利亚",
  Austria: "奥地利",
  Belgium: "比利时",
  "Bosnia-Herzegovina": "波黑",
  "Bosnia and Herzegovina": "波黑",
  Brazil: "巴西",
  Canada: "加拿大",
  Chile: "智利",
  Colombia: "哥伦比亚",
  "Congo DR": "刚果（金）",
  "DR Congo": "刚果（金）",
  "Cape Verde Islands": "佛得角",
  "Cape Verde": "佛得角",
  Croatia: "克罗地亚",
  "Curaçao": "库拉索",
  Curacao: "库拉索",
  Czechia: "捷克",
  "Czech Republic": "捷克",
  Denmark: "丹麦",
  Ecuador: "厄瓜多尔",
  Egypt: "埃及",
  England: "英格兰",
  Finland: "芬兰",
  France: "法国",
  Germany: "德国",
  Ghana: "加纳",
  Greece: "希腊",
  Haiti: "海地",
  Honduras: "洪都拉斯",
  Hungary: "匈牙利",
  Iran: "伊朗",
  Iraq: "伊拉克",
  Ireland: "爱尔兰",
  Israel: "以色列",
  Italy: "意大利",
  "Ivory Coast": "科特迪瓦",
  "Côte d'Ivoire": "科特迪瓦",
  Japan: "日本",
  Jordan: "约旦",
  "Saudi Arabia": "沙特阿拉伯",
  "South Korea": "韩国",
  "Korea Republic": "韩国",
  Mali: "马里",
  Morocco: "摩洛哥",
  Mexico: "墨西哥",
  Netherlands: "荷兰",
  Nigeria: "尼日利亚",
  "Northern Ireland": "北爱尔兰",
  Norway: "挪威",
  "New Zealand": "新西兰",
  Panama: "巴拿马",
  Paraguay: "巴拉圭",
  Peru: "秘鲁",
  Poland: "波兰",
  Portugal: "葡萄牙",
  Qatar: "卡塔尔",
  Romania: "罗马尼亚",
  Serbia: "塞尔维亚",
  Scotland: "苏格兰",
  Senegal: "塞内加尔",
  Slovakia: "斯洛伐克",
  Spain: "西班牙",
  Switzerland: "瑞士",
  Sweden: "瑞典",
  Tunisia: "突尼斯",
  Turkey: "土耳其",
  Turkiye: "土耳其",
  Türkiye: "土耳其",
  "United States": "美国",
  "United States of America": "美国",
  USA: "美国",
  Uruguay: "乌拉圭",
  Uzbekistan: "乌兹别克斯坦",
  Venezuela: "委内瑞拉",
  Wales: "威尔士",
  "United Arab Emirates": "阿联酋",
  "Costa Rica": "哥斯达黎加",
  Jamaica: "牙买加",
  TBD: "待定",
});

const SIMULATION_VENUE_ZH = {
  "Estadio Azteca": "阿兹特克体育场",
  "Mexico City Stadium": "墨西哥城体育场",
  "New York/New Jersey Stadium": "纽约/新泽西体育场",
  "MetLife Stadium": "大都会人寿体育场",
  "SoFi Stadium": "SoFi 体育场",
  "Levi's Stadium": "李维斯体育场",
  "Gillette Stadium": "吉列体育场",
  "BC Place": "卑诗体育馆",
  "NRG Stadium": "NRG 体育场",
  "AT&T Stadium": "AT&T 体育场",
  "Lincoln Financial Field": "林肯金融球场",
  "Estadio BBVA": "BBVA 体育场",
  "Lumen Field": "流明球场",
  "Hard Rock Stadium": "硬石体育场",
  "GEHA Field at Arrowhead Stadium": "箭头体育场",
  "BMO Field": "BMO 球场",
  "Estadio Akron": "阿克伦体育场",
  "Mercedes-Benz Stadium": "梅赛德斯-奔驰体育场",
};

const SIMULATION_CITY_ZH = {
  "Mexico City": "墨西哥城",
  "Los Angeles (Inglewood)": "洛杉矶（英格尔伍德）",
  "San Francisco Bay Area (Santa Clara)": "旧金山湾区（圣克拉拉）",
  "New York/New Jersey (East Rutherford)": "纽约/新泽西（东卢瑟福）",
  "Boston (Foxborough)": "波士顿（福克斯伯勒）",
  Vancouver: "温哥华",
  Houston: "休斯敦",
  "Dallas (Arlington, Texas)": "达拉斯（阿灵顿）",
  Philadelphia: "费城",
  "Monterrey (Guadalupe)": "蒙特雷（瓜达卢佩）",
  Seattle: "西雅图",
  "Miami (Miami Gardens)": "迈阿密（迈阿密花园）",
  "Kansas City": "堪萨斯城",
  Toronto: "多伦多",
  "Guadalajara (Zapopan)": "瓜达拉哈拉（萨波潘）",
  Atlanta: "亚特兰大",
};

const cache = new Map();
const pendingCache = new Map();
const rateLimitBuckets = new Map();
const derivativeCoverageState = {
  status: "idle",
  refreshedAt: "",
  windowHours: 24,
  totalMatches: 0,
  coveredMatches: 0,
  cornerMatches: 0,
  cardMatches: 0,
  completeMatches: 0,
  directEntries: 0,
  errors: [],
};
const scoreCalibrationState = {
  status: "idle",
  refreshedAt: "",
  sample: 0,
  exactAccuracy: null,
  top3Accuracy: null,
  profile: null,
  errors: [],
};

function loadLocalEnv() {
  const envPath = new URL(".env", import.meta.url);
  if (!existsSync(envPath)) return;
  const content = readFileSync(envPath, "utf8");
  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eq = trimmed.indexOf("=");
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim().replace(/^['"]|['"]$/g, "");
    if (key && process.env[key] === undefined) {
      process.env[key] = value;
    }
  }
}

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(appSecurityHeaders);
app.use(express.json({ limit: "1mb" }));
app.use(rateLimitAnalyzeApi);
app.use(
  express.static(PUBLIC_DIR, {
    extensions: ["html"],
    index: "index.html",
    etag: false,
    lastModified: false,
    setHeaders(res, filePath) {
      if (/\.(?:html|js|css|svg)$/i.test(filePath)) {
        res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
        res.setHeader("Pragma", "no-cache");
        res.setHeader("Expires", "0");
      }
    },
  })
);

app.get("/", (_req, res) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.sendFile(INDEX_HTML);
});

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    time: new Date().toISOString(),
    sources: [
      "worldcup26.ir",
      "football-data.org",
      "FIFA rankings API",
      "Open-Meteo",
      "OpenStreetMap Nominatim",
      "Bing News RSS",
      "Bing Search",
      "DuckDuckGo HTML Search",
      "ESPN Soccer API",
      "中国体彩网/竞彩网 Sporttery 官方竞彩接口",
      "Pinnacle World Cup direct",
      "TheSportsDB",
      "The Odds API (optional key)",
      ...GLOBAL_BETTING_SOURCE_CATALOG.map((source) => source.label),
    ],
    bettingSourceCount: GLOBAL_BETTING_SOURCE_CATALOG.length,
    derivativeCoverage: derivativeCoverageState,
    scoreCalibration: publicScoreCalibrationState(),
  });
});

app.get("/api/matches", async (req, res) => {
  try {
    const fast = req.query.fast === "1";
    const data = await getWorldCupData({ preferLocal: fast });
    setTimeout(() => warmPinnacleDerivativeCoverage(data.matches || []).catch(() => {}), 8000);
    setTimeout(() => refreshScoreCalibrationProfile(data.matches || []).catch(() => {}), 12000);
    res.json({
      ...data,
      mode: fast ? "fast" : "live",
      derivativeCoverage: derivativeCoverageState,
      scoreCalibration: publicScoreCalibrationState(),
    });
  } catch (error) {
    res.status(502).json(errorPayload(error, "无法获取世界杯赛程数据"));
  }
});

app.get("/api/history", async (_req, res) => {
  try {
    const stats = await cached("prediction-history-stats", 3 * 60 * 1000, async () => {
      const data = await getWorldCupData().catch((error) =>
        getWorldCupData({ preferLocal: true }).then((fallback) => ({
          ...fallback,
          historySourceWarning: `实时赛程失败，已使用本地快照：${error.message}`,
        }))
      );
      refreshScoreCalibrationProfile(data.matches || [], { force: true }).catch(() => {});
      return buildPredictionHistoryStats(data.matches || []);
    });
    res.json({
      refreshedAt: new Date().toISOString(),
      ...stats,
    });
  } catch (error) {
    res.status(502).json(errorPayload(error, "历史推荐统计失败"));
  }
});

app.get("/api/history-fast", async (_req, res) => {
  try {
    const stats = await cached("prediction-history-stats-fast", 3 * 60 * 1000, async () => {
      const data = await getWorldCupData().catch(() => getWorldCupData({ preferLocal: true }));
      return buildPredictionHistoryStats(data.matches || [], { fast: true });
    });
    res.json({
      refreshedAt: new Date().toISOString(),
      mode: "fast",
      ...stats,
    });
  } catch (error) {
    res.status(502).json(errorPayload(error, "历史推荐统计失败"));
  }
});

app.get("/api/analyze", async (req, res) => {
  try {
    const matchId = String(req.query.matchId || "");
    const oddsKey = String(req.query.oddsKey || process.env.ODDS_API_KEY || "").trim();
    const quick = req.query.quick === "1";
    const prefetch = req.query.prefetch === "1";
    const depth = String(req.query.depth || "balanced").toLowerCase();
    let data = matchId
      ? await getWorldCupData({ preferLocal: false }).catch(() => getWorldCupData({ preferLocal: true }))
      : await getWorldCupData({ preferLocal: true });
    let match = matchId ? findMatchByAnyId(data.matches, matchId) : data.matches[0];
    if (!match && matchId) {
      const localData = await getWorldCupData({ preferLocal: true });
      match = findMatchByAnyId(localData.matches, matchId) ||
        findMatchByHistoryAlias(localData.matches, matchId) ||
        await findMatchByFootballDataAlias(localData.matches, matchId);
      if (match) data = localData;
    }
    if (!match && matchId) {
      res.status(404).json({
        message: "没有找到该场比赛",
        detail: `当前赛程源暂未返回 matchId=${matchId}。请刷新赛程后重试，系统不会再错误退回到第一场比赛。`,
      });
      return;
    }
    match = match || data.matches[0];

    if (!match) {
      res.status(404).json({ message: "没有找到可分析的比赛" });
      return;
    }

    const analysisModeKey = quick ? "quick" : `full:${depth}`;
    const calibrationCacheKey = scoreCalibrationState.profile?.available
      ? `cal:${scoreCalibrationState.sample}:${scoreCalibrationState.refreshedAt}`
      : "cal:none";
    const analysisCacheKey = `analysis:${analysisModeKey}:${match.id}:${oddsKey ? "odds" : "no-odds"}:${calibrationCacheKey}`;
    const payload = await cached(analysisCacheKey, quick ? 8 * 60 * 1000 : 5 * 60 * 1000, async () => {
      const venue = resolveMatchVenue(match);
      match = { ...match, stadium: venue };
      const geo = quick
        ? venueGeoFallback(venue) || fallbackGeo(venue, { message: "快速模式使用场馆兜底定位" })
        : await geocodeVenue(venue).catch((error) => fallbackGeo(venue, error));
      const weatherDateInfo = match.venueDateInfo || match.dateInfo;
      const [weather, elevation, research, sporttery, odds] = quick
        ? await Promise.all([
            Promise.resolve(buildClimateWeatherFallback(geo, match.dateInfo, venue, "快速模式先使用场馆城市气候兜底，深度分析会刷新实时天气")),
            Promise.resolve({ available: false, meters: null, message: "快速模式跳过海拔抓取，后台深度分析会补充" }),
            buildResearch(match, venue, { quick: true }).catch((error) => fallbackResearch(match, error)),
            Promise.resolve(unavailableSporttery("快速模式跳过体彩慢接口，深度分析会继续补齐")),
            Promise.resolve({ enabled: false, available: false, message: "快速模式跳过外部赔率 API", markets: [] }),
          ])
        : await Promise.all([
            getWeather(geo, match.dateInfo, venue).catch((error) =>
              buildClimateWeatherFallback(geo, match.dateInfo, venue, `天气抓取失败：${error.message}`)
            ),
            getElevation(geo).catch((error) => ({ available: false, meters: null, message: `海拔抓取失败：${error.message}` })),
            buildResearch(match, venue, { depth }).catch((error) => fallbackResearch(match, error)),
            withTimeout(
              getSportteryContext(match),
              FULL_SPORTTERY_TIMEOUT_MS,
              unavailableSporttery("体彩官方接口响应超时，保留其他推荐并在缓存刷新时补齐")
            ).catch((error) => unavailableSporttery(`体彩官方接口抓取失败：${error.message}`)),
            fetchOdds(match, oddsKey).catch((error) => ({ enabled: Boolean(oddsKey), available: false, message: `赔率抓取失败：${error.message}`, markets: [] })),
          ]);

      const prediction = buildPrediction({ match, venue, geo, weather, elevation, research, odds, sporttery, scoreCalibration: scoreCalibrationState.profile });
      const dataChecks = buildDataChecks({ match, venue, geo, weather, elevation, research, odds, prediction });

      return {
        refreshedAt: new Date().toISOString(),
        mode: quick ? "quick" : "full",
        match,
        venue,
        geo,
        weather,
        elevation,
        research,
        odds,
        sporttery,
        prediction,
        dataChecks,
        scoreCalibration: publicScoreCalibrationState(),
        dataSources: [
        {
          name: "football-data.org",
          url: "https://api.football-data.org/v4/competitions/WC/matches",
          note: "主赛程、球队、名单、教练、比赛状态",
        },
        {
          name: "FIFA rankings API",
          url: `${FIFA_RANKINGS_API}?gender=1&count=211`,
          note: "官方男子国家队排名、积分、排名发布日期",
        },
        {
          name: "World Cup venue fallback API",
          url: `${WORLD_CUP_API}/games`,
          note: "球场和本地开球时间补充",
        },
        {
          name: "Open-Meteo",
          url: "https://open-meteo.com/",
          note: "逐小时天气预报、海拔接口",
        },
        {
          name: "OpenStreetMap Nominatim",
          url: "https://nominatim.openstreetmap.org/",
          note: "球场/城市地理编码",
        },
        {
          name: "Bing News RSS / Search",
          url: "https://www.bing.com/news/search",
          note: "阵容、伤停、预测、盘口网页新闻与摘要抓取",
        },
        {
          name: "ESPN Soccer API",
          url: "https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/scoreboard",
          note: "赛事确认、近期状态、DraftKings 盘口摘要、官方比赛链接",
        },
        {
          name: "中国体彩网/竞彩网 Sporttery",
          url: SPORTTERY_PAGE,
          note: sporttery?.available ? "胜平负、让球胜平负、比分、总进球数官方固定奖金" : sporttery?.message || "暂无体彩官方数据",
        },
        {
          name: "Pinnacle World Cup 直连接口",
          url: `${PINNACLE_GUEST_API}/leagues/${PINNACLE_WORLD_CUP_LEAGUE_ID}/matchups`,
          note: "世界杯比赛、角球特殊盘、Bookings/罚牌特殊盘、全场 total/spread 盘口线",
        },
        {
          name: "TheSportsDB",
          url: "https://www.thesportsdb.com/api.php",
          note: "球队资料、赛事海报、比赛元数据",
        },
        {
          name: "The Odds API",
          url: "https://the-odds-api.com/",
          note: odds.enabled
            ? `已用 API Key 拉取赔率；请求市场 ${odds.marketsRequested || ODDS_API_CORE_MARKETS}${odds.warning ? `；${odds.warning}` : ""}`
            : "未配置 API Key，仅展示网页抓取参考",
        },
        ...GLOBAL_BETTING_SOURCE_CATALOG.map((source) => {
          const primaryDomain = source.domains.find((domain) => /^[a-z0-9.-]+\.[a-z]{2,}/i.test(domain));
          return {
            name: source.label,
            url: primaryDomain ? `https://${primaryDomain}` : "",
            note: `${source.category}；覆盖 ${source.markets.join("、")}`,
          };
        }),
      ],
      };
    });

    if (!prefetch) {
      recordPrediction(payload.match, payload.prediction, {
        source: quick ? "赛前快照（快速）" : "赛前分析",
        quick,
      });
    }

    res.json(payload);
  } catch (error) {
    res.status(502).json(errorPayload(error, "分析失败"));
  }
});

app.listen(PORT, HOST, () => {
  console.log(`World Cup Analyzer running on ${HOST}:${PORT}`);
});

function appSecurityHeaders(_req, res, next) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader(
    "Content-Security-Policy",
    [
      "default-src 'self'",
      "script-src 'self' https://unpkg.com",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: https:",
      "connect-src 'self'",
      "font-src 'self' data:",
      "object-src 'none'",
      "base-uri 'self'",
      "frame-ancestors 'self'",
    ].join("; ")
  );
  next();
}

function rateLimitAnalyzeApi(req, res, next) {
  if (req.path !== "/api/analyze") {
    next();
    return;
  }
  const now = Date.now();
  const ip = req.ip || req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown";
  const key = String(ip).split(",")[0].trim() || "unknown";
  const bucket = rateLimitBuckets.get(key);
  if (!bucket || now > bucket.resetAt) {
    rateLimitBuckets.set(key, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    cleanupRateLimitBuckets(now);
    next();
    return;
  }
  bucket.count += 1;
  if (bucket.count > ANALYZE_RATE_LIMIT) {
    const retryAfter = Math.max(1, Math.ceil((bucket.resetAt - now) / 1000));
    res.setHeader("Retry-After", String(retryAfter));
    res.status(429).json({
      message: "请求过于频繁，请稍后再试",
      retryAfter,
    });
    return;
  }
  next();
}

function cleanupRateLimitBuckets(now) {
  if (rateLimitBuckets.size < 1000) return;
  for (const [key, bucket] of rateLimitBuckets) {
    if (now > bucket.resetAt) rateLimitBuckets.delete(key);
  }
}

async function getWorldCupData(options = {}) {
  if (options.preferLocal) {
    return cached("world-cup-data-local", 60 * 60 * 1000, () => buildWorldCupData({ preferLocal: true }));
  }
  return cached("world-cup-data", 10 * 60 * 1000, () => buildWorldCupData());
}

async function buildWorldCupData(options = {}) {
  const [gamesJson, stadiumsJson, teamsJson, footballData] = options.preferLocal
    ? [
        readLocalJson("games.json"),
        readLocalJson("stadiums.json"),
        readLocalJson("teams.json"),
        {
          available: false,
          matches: [],
          teams: [],
          source: `${WORLD_CUP_API}/games`,
          message: "快速模式使用本地赛程快照",
        },
      ]
    : await Promise.all([
        fetchJsonWithLocalFallback(`${WORLD_CUP_API}/games`, "games.json"),
        fetchJsonWithLocalFallback(`${WORLD_CUP_API}/stadiums`, "stadiums.json"),
        fetchJsonWithLocalFallback(`${WORLD_CUP_API}/teams`, "teams.json"),
        getFootballDataWorldCup(),
      ]);

  const stadiums = arrayFrom(stadiumsJson.stadiums);
  const teams = arrayFrom(teamsJson.teams);
  const stadiumMap = new Map(stadiums.map((stadium) => [String(stadium.id), stadium]));
  const teamMap = new Map(teams.map((team) => [String(team.id), team]));

  const fallbackMatches = arrayFrom(gamesJson.games)
    .map((game) => normalizeMatch(game, stadiumMap, teamMap))
    .sort((a, b) => a.sortKey.localeCompare(b.sortKey));
  const matches = footballData.available && footballData.matches.length
    ? footballData.matches
        .map((match) => normalizeFootballDataMatch(match, fallbackMatches, footballData.teams))
        .sort((a, b) => a.sortKey.localeCompare(b.sortKey))
    : fallbackMatches;
  if (footballData.available && footballData.matches.length) {
    persistMatchIdAliases(matches);
  }

  return {
    refreshedAt: new Date().toISOString(),
    matches,
    stadiums,
    teams,
    footballData: {
      available: footballData.available,
      source: footballData.source,
      matchCount: footballData.matches.length,
      teamCount: footballData.teams.length,
      message: footballData.message || "",
    },
    source: footballData.available ? footballData.source : `${WORLD_CUP_API}/games`,
  };
}

function readLocalJson(filename) {
  const localPath = new URL(`data/${filename}`, import.meta.url);
  return JSON.parse(readFileSync(localPath, "utf8"));
}

function findMatchByAnyId(matches, matchId) {
  const target = String(matchId || "");
  if (!target) return null;
  const direct = arrayFrom(matches).find((match) =>
    String(match.id || "") === target ||
    String(match.sourceIds?.footballData || "") === target ||
    String(match.sourceIds?.worldcup26 || "") === target ||
    String(match.footballData?.id || "") === target
  );
  return direct || findMatchByPersistedAlias(matches, target);
}

function findMatchByHistoryAlias(matches, matchId) {
  const record = readPredictionHistory().predictions?.[String(matchId)];
  if (!record) return null;
  const recordDate = String(record.date || "").slice(0, 10);
  const homeKey = historyTeamCompareKey(record.home);
  const awayKey = historyTeamCompareKey(record.away);
  if (!recordDate || !homeKey || !awayKey) return null;
  return arrayFrom(matches).find((match) =>
    historyRecordDateMatchesMatch(recordDate, match) &&
    historyTeamCompareKey(teamLabel(match.home)) === homeKey &&
    historyTeamCompareKey(teamLabel(match.away)) === awayKey
  ) || null;
}

function resolveMatchVenue(match) {
  const current = match?.stadium || {};
  if (hasVenueIdentity(current)) return normalizeResolvedVenue(current, "schedule");

  const date = String(match?.dateInfo?.date || "").replaceAll("-", "");
  const cachedEvent = findCachedEspnEvent(match, date);
  const espnVenue = cachedEvent?.event ? venueFromEspnEvent(cachedEvent.event) : null;
  if (espnVenue) return normalizeResolvedVenue(espnVenue, "ESPN schedule cache");

  const localVenue = findLocalVenueForMatch(match);
  if (localVenue) return normalizeResolvedVenue(localVenue, "worldcup26 local schedule");

  return normalizeResolvedVenue(current, "missing venue");
}

function hasVenueIdentity(venue = {}) {
  return Boolean(venue.name || venue.fifaName || venue.city);
}

function normalizeResolvedVenue(venue = {}, source = "") {
  return {
    id: String(venue.id || ""),
    name: venue.name || venue.name_en || venue.displayName || venue.fullName || "",
    fifaName: venue.fifaName || venue.fifa_name || venue.displayName || venue.fullName || "",
    city: venue.city || venue.city_en || venue.address?.city || "",
    country: venue.country || venue.country_en || venue.address?.country || "",
    capacity: Number(venue.capacity || 0),
    region: venue.region || "",
    source,
  };
}

function venueFromEspnEvent(event) {
  const competition = event?.competitions?.[0] || {};
  const rawVenue = event?.venue || competition.venue || {};
  const name = rawVenue.fullName || rawVenue.displayName || rawVenue.name || "";
  if (!name && !rawVenue.address?.city) return null;
  const local = findLocalVenueByName(name);
  return {
    ...(local || {}),
    displayName: name,
    city: rawVenue.address?.city || local?.city_en || local?.city || "",
    country: rawVenue.address?.country || local?.country_en || local?.country || "",
  };
}

function findLocalVenueForMatch(match) {
  try {
    const games = arrayFrom(readLocalJson("games.json").games);
    const stadiums = arrayFrom(readLocalJson("stadiums.json").stadiums);
    const teams = arrayFrom(readLocalJson("teams.json").teams);
    const localTeams = new Map(teams.map((team) => [String(team.id), team]));
    const homeKeys = teamLookupKeys(match?.home?.name);
    const awayKeys = teamLookupKeys(match?.away?.name);
    const date = match?.dateInfo?.date || "";
    const game = games.find((item) => {
      const home = localTeams.get(String(item.home_team_id));
      const away = localTeams.get(String(item.away_team_id));
      const localDate = parseLocalDate(item.local_date).date;
      const homeMatch = teamLookupKeys(item.home_team_name_en || home?.name_en).some((key) => homeKeys.includes(key));
      const awayMatch = teamLookupKeys(item.away_team_name_en || away?.name_en).some((key) => awayKeys.includes(key));
      return homeMatch && awayMatch && (!date || localDate === date);
    });
    const stadium = stadiums.find((item) => String(item.id) === String(game?.stadium_id));
    return stadium || null;
  } catch {
    return null;
  }
}

function findLocalVenueByName(name) {
  const target = normalizeVenueName(name);
  if (!target) return null;
  try {
    const stadiums = arrayFrom(readLocalJson("stadiums.json").stadiums);
    return stadiums.find((stadium) => {
      return [stadium.name_en, stadium.fifa_name, stadium.name, stadium.displayName]
        .some((candidate) => normalizeVenueName(candidate) === target);
    }) || null;
  } catch {
    return null;
  }
}

function normalizeVenueName(value) {
  return normalizeWhitespace(String(value || "").toLowerCase().replace(/[^a-z0-9 ]/g, " "));
}

async function fetchJsonWithLocalFallback(url, filename) {
  try {
    return await fetchJson(url);
  } catch (error) {
    const localPath = new URL(`data/${filename}`, import.meta.url);
    if (!existsSync(localPath)) throw error;
    return JSON.parse(readFileSync(localPath, "utf8"));
  }
}

function readPredictionHistory() {
  if (!existsSync(PREDICTION_HISTORY_FILE)) {
    return { version: 1, updatedAt: "", predictions: {} };
  }
  try {
    const parsed = JSON.parse(readFileSync(PREDICTION_HISTORY_FILE, "utf8"));
    return {
      version: 1,
      updatedAt: parsed.updatedAt || "",
      predictions: parsed.predictions || {},
      migrations: Array.isArray(parsed.migrations) ? parsed.migrations : [],
    };
  } catch {
    return { version: 1, updatedAt: "", predictions: {} };
  }
}

function writePredictionHistory(history) {
  writeFileSync(
    PREDICTION_HISTORY_FILE,
    `${JSON.stringify({ ...history, updatedAt: new Date().toISOString() }, null, 2)}\n`,
    "utf8"
  );
}

function readMatchIdAliases() {
  if (!existsSync(MATCH_ID_ALIAS_FILE)) {
    return { version: 1, updatedAt: "", aliases: {} };
  }
  try {
    const parsed = JSON.parse(readFileSync(MATCH_ID_ALIAS_FILE, "utf8"));
    return {
      version: 1,
      updatedAt: parsed.updatedAt || "",
      aliases: parsed.aliases || {},
    };
  } catch {
    return { version: 1, updatedAt: "", aliases: {} };
  }
}

function writeMatchIdAliases(data) {
  writeFileSync(
    MATCH_ID_ALIAS_FILE,
    `${JSON.stringify({ version: 1, aliases: data.aliases || {}, updatedAt: new Date().toISOString() }, null, 2)}\n`,
    "utf8"
  );
}

function persistMatchIdAliases(matches) {
  const data = readMatchIdAliases();
  let changed = false;
  for (const match of arrayFrom(matches)) {
    const footballDataId = String(match?.sourceIds?.footballData || match?.footballData?.id || "");
    const worldcup26Id = String(match?.sourceIds?.worldcup26 || "");
    if (!footballDataId || !worldcup26Id) continue;
    const next = {
      footballData: footballDataId,
      worldcup26: worldcup26Id,
      date: match?.dateInfo?.date || "",
      kickoffUtc: match?.kickoffUtc || match?.footballData?.utcDate || "",
    };
    if (JSON.stringify(data.aliases[footballDataId]) !== JSON.stringify(next)) {
      data.aliases[footballDataId] = next;
      changed = true;
    }
  }
  if (changed) writeMatchIdAliases(data);
}

function rememberMatchIdAlias(footballDataId, match) {
  const fdId = String(footballDataId || "");
  if (!fdId || !match?.id) return;
  const data = readMatchIdAliases();
  const next = {
    footballData: fdId,
    worldcup26: String(match.id),
    date: match?.dateInfo?.date || "",
    kickoffUtc: match?.kickoffUtc || "",
  };
  if (JSON.stringify(data.aliases[fdId]) !== JSON.stringify(next)) {
    data.aliases[fdId] = next;
    writeMatchIdAliases(data);
  }
}

function findMatchByPersistedAlias(matches, matchId) {
  const alias = readMatchIdAliases().aliases?.[String(matchId || "")];
  const localId = String(alias?.worldcup26 || "");
  if (!localId) return null;
  return arrayFrom(matches).find((match) =>
    String(match.id || "") === localId ||
    String(match.sourceIds?.worldcup26 || "") === localId
  ) || null;
}

function readDerivativeMarketCache() {
  if (!existsSync(DERIVATIVE_MARKET_CACHE_FILE)) {
    return { version: 1, updatedAt: "", markets: {} };
  }
  try {
    const parsed = JSON.parse(readFileSync(DERIVATIVE_MARKET_CACHE_FILE, "utf8"));
    return {
      version: 1,
      updatedAt: parsed.updatedAt || "",
      markets: parsed.markets || {},
    };
  } catch {
    return { version: 1, updatedAt: "", markets: {} };
  }
}

function writeDerivativeMarketCache(cacheData) {
  const sanitized = sanitizeDerivativeMarketCache(cacheData);
  writeFileSync(
    DERIVATIVE_MARKET_CACHE_FILE,
    `${JSON.stringify({ ...sanitized, updatedAt: new Date().toISOString() }, null, 2)}\n`,
    "utf8"
  );
}

function sanitizeDerivativeMarketCache(cacheData) {
  const markets = {};
  for (const [key, record] of Object.entries(cacheData?.markets || {})) {
    const entries = mergeDerivativeEntries(record?.entries || []);
    if (!entries.length) continue;
    markets[key] = {
      ...record,
      key: record?.key || key,
      sources: [...new Set(entries.map((entry) => entry.groupLabel || entry.domain || "盘口源"))].slice(0, 12),
      entries,
    };
  }
  return {
    version: 1,
    updatedAt: cacheData?.updatedAt || "",
    markets,
  };
}

function derivativeMarketCacheKey(match) {
  const home = teamLookupKeys(match?.home?.name || match?.home?.displayName).sort().join("|") || normalizeTeamName(match?.home?.name);
  const away = teamLookupKeys(match?.away?.name || match?.away?.displayName).sort().join("|") || normalizeTeamName(match?.away?.name);
  return `${home}:${away}:${match?.dateInfo?.date || ""}`;
}

function readCachedDerivativeMarketContext(match, maxAgeMs = DERIVATIVE_MARKET_CACHE_MAX_AGE_MS) {
  const cacheData = readDerivativeMarketCache();
  const key = derivativeMarketCacheKey(match);
  const record = cacheData.markets?.[key];
  if (!record?.entries?.length) {
    return {
      available: false,
      source: "本地盘口缓存",
      label: "本地盘口缓存",
      domain: "local-cache",
      entries: [],
      message: "本地暂无该场角球/罚牌盘口快照",
    };
  }
  const updatedMs = Date.parse(record.updatedAt || "");
  const ageMs = Number.isFinite(updatedMs) ? Date.now() - updatedMs : Infinity;
  if (ageMs > maxAgeMs) {
    return {
      available: false,
      source: "本地盘口缓存",
      label: "本地盘口缓存",
      domain: "local-cache",
      entries: [],
      message: "本地盘口快照已过期，等待重新抓取",
    };
  }
  const ageHours = Number.isFinite(ageMs) ? Math.max(0, ageMs / 3600000) : null;
  return {
    available: true,
    source: "本地盘口缓存",
    label: "本地盘口缓存",
    domain: "local-cache",
    url: "",
    fromCache: true,
    updatedAt: record.updatedAt || "",
    entries: arrayFrom(record.entries).map((entry) => ({
      ...entry,
      sourceType: "local-cache",
      groupLabel: entry.groupLabel || "本地盘口缓存",
      domain: entry.domain || "local-cache",
      text: entry.text || "",
    })),
    message: `已复用本地角球/罚牌盘口快照${ageHours === null ? "" : `，约 ${ageHours.toFixed(1)} 小时前更新`}`,
  };
}

function saveDerivativeMarketSnapshot(match, context, options = {}) {
  const entries = normalizeDerivativeCacheEntries(context?.entries || [], options.source || context?.label || context?.source || "盘口源");
  if (!entries.length) return false;
  const cacheData = readDerivativeMarketCache();
  const key = derivativeMarketCacheKey(match);
  const existing = cacheData.markets?.[key] || {};
  const mergedEntries = mergeDerivativeEntries([...entries, ...arrayFrom(existing.entries)]).slice(0, 48);
  cacheData.markets = cacheData.markets || {};
  cacheData.markets[key] = {
    key,
    matchId: historyKey(match),
    date: match?.dateInfo?.date || "",
    label: `${teamLabel(match?.home)} vs ${teamLabel(match?.away)}`,
    home: teamLabel(match?.home),
    away: teamLabel(match?.away),
    updatedAt: new Date().toISOString(),
    sources: [...new Set(mergedEntries.map((entry) => entry.groupLabel || entry.domain || "盘口源"))].slice(0, 12),
    entries: mergedEntries,
  };
  writeDerivativeMarketCache(cacheData);
  return true;
}

function normalizeDerivativeCacheEntries(entries, sourceLabel = "盘口源") {
  return arrayFrom(entries)
    .map((entry) => {
      const kind = normalizeDerivativeKind(entry.kind, entry.text);
      if (!kind) return null;
      const text = String(entry.text || "").trim();
      if (!text) return null;
      return {
        kind,
        side: entry.side || "odds",
        domain: entry.domain || "",
        url: entry.url || "",
        groupLabel: entry.groupLabel || sourceLabel,
        sourceType: entry.sourceType || "scraped",
        text,
        matchupId: entry.matchupId || "",
        totalLine: numberOrNull(entry.totalLine),
        handicapLine: numberOrNull(entry.handicapLine),
        capturedAt: entry.capturedAt || new Date().toISOString(),
      };
    })
    .filter(Boolean);
}

function normalizeDerivativeKind(kind, text = "") {
  if (kind === "corners" || kind === "cards") return kind;
  const lower = String(text || "").toLowerCase();
  if (/corners?|corner kicks?|角球/.test(lower)) return "corners";
  if (/cards?|bookings?|yellow cards?|red cards?|罚牌|黄牌|红牌/.test(lower)) return "cards";
  return "";
}

function mergeDerivativeEntries(entries) {
  const map = new Map();
  for (const entry of normalizeDerivativeCacheEntries(entries)) {
    const key = derivativeEntryDedupeKey(entry);
    if (!map.has(key)) map.set(key, entry);
  }
  return pruneRedundantDerivativeAggregateEntries([...map.values()]);
}

function derivativeEntryDedupeKey(entry) {
  const lineKey = [entry.totalLine ?? "", entry.handicapLine ?? ""].join(":");
  if (entry.matchupId) return [entry.kind, entry.domain, entry.matchupId].join("|");
  if (entry.sourceType === "web-signal") return [entry.kind, entry.domain, entry.url || "aggregate"].join("|");
  if (entry.url && lineKey !== ":") return [entry.kind, entry.domain, entry.url].join("|");
  return [
    entry.kind,
    entry.domain,
    entry.url,
    lineKey,
    entry.text.replace(/\s+/g, " ").trim().slice(0, 180),
  ].join("|");
}

function pruneRedundantDerivativeAggregateEntries(entries) {
  const withoutInvalidAggregates = entries.filter((entry) =>
    !(entry.domain === "multi-source-cache" && !derivativeEntryHasUsableLine(entry))
  );
  const primaryKinds = new Set();
  for (const entry of withoutInvalidAggregates) {
    if (entry.domain === "multi-source-cache") continue;
    if (!derivativeEntryHasUsableLine(entry)) continue;
    primaryKinds.add(entry.kind);
  }
  if (!primaryKinds.size) return withoutInvalidAggregates;
  return withoutInvalidAggregates.filter((entry) => {
    return !(entry.domain === "multi-source-cache" && primaryKinds.has(entry.kind));
  });
}

function derivativeEntryHasUsableLine(entry) {
  const totalLine = Number(entry.totalLine);
  const handicapLine = Number(entry.handicapLine);
  return (Number.isFinite(totalLine) && totalLine > 0) || (Number.isFinite(handicapLine) && handicapLine > 0);
}

function mergeDerivativeSourceContexts(match, contexts = []) {
  const valid = arrayFrom(contexts).filter((context) => context && typeof context === "object");
  const entries = mergeDerivativeEntries(valid.flatMap((context) => arrayFrom(context.entries)));
  const availableContexts = valid.filter((context) => context.available || arrayFrom(context.entries).length);
  if (!entries.length) {
    return valid[0] || {
      available: false,
      source: "附加盘口聚合",
      label: "附加盘口聚合",
      domain: "",
      entries: [],
      message: "未抓到角球/罚牌盘口",
    };
  }
  const labels = [...new Set(availableContexts.map((context) => context.label || context.source || context.domain).filter(Boolean))];
  const errors = valid.flatMap((context) => arrayFrom(context.errors));
  return {
    available: true,
    source: labels.join(" + ") || "附加盘口聚合",
    label: labels.join(" + ") || "附加盘口聚合",
    domain: labels.includes("本地盘口缓存") ? "mixed-with-local-cache" : availableContexts[0]?.domain || "",
    url: availableContexts.find((context) => context.url)?.url || "",
    entries,
    errors: errors.slice(0, 6),
    message: `已汇总 ${entries.length} 条角球/罚牌盘口快照：${labels.join("、") || "多源聚合"}`,
  };
}

function recordPrediction(match, prediction, options = {}) {
  if (!match || !prediction?.primaryScore) return;
  if (match.finished || hasMatchStarted(match)) return;
  const history = readPredictionHistory();
  const key = historyKey(match);
  const existing = history.predictions[key];
  const incomingQuick = Boolean(options.quick);
  const existingIsQuick = /快速|快照/i.test(String(existing?.source || ""));
  if (existing && incomingQuick && !existingIsQuick) return;
  history.predictions[key] = predictionRecordFrom(match, prediction, {
    source: options.source || "赛前分析",
    generatedAt: new Date().toISOString(),
  });
  writePredictionHistory(history);
}

function predictionRecordFrom(match, prediction, options = {}) {
  return {
    matchId: historyKey(match),
    generatedAt: options.generatedAt || new Date().toISOString(),
    source: options.source || "赛前分析",
    model: prediction.model || "",
    date: match.dateInfo?.label || "",
    stage: match.type || match.group || "",
    home: teamLabel(match.home),
    away: teamLabel(match.away),
    recommendedScore: prediction.primaryScore?.score || "",
    recommendedProbability: prediction.primaryScore?.probability ?? null,
    expectedGoals: prediction.expectedGoals || null,
    topScores: (prediction.scorePortfolio || prediction.topScores || [])
      .slice(0, 5)
      .map((score) => ({
        score: score.score,
        probability: score.probability,
      })),
    sporttery: sportteryHistoryRecordFrom(prediction),
    derivatives: derivativePredictionRecordFrom(prediction),
  };
}

function findPredictionHistoryRecord(match) {
  const records = readPredictionHistory().predictions || {};
  const exact = records[historyKey(match)];
  if (exact) return exact;
  const matchDate = match?.dateInfo?.date || "";
  const homeKey = historyTeamCompareKey(teamLabel(match?.home));
  const awayKey = historyTeamCompareKey(teamLabel(match?.away));
  return Object.values(records)
    .filter((record) => {
      if (!record) return false;
      const recordDate = String(record.date || "").slice(0, 10);
      return (
        historyRecordDateMatchesMatch(recordDate, match) &&
        historyTeamCompareKey(record.home) === homeKey &&
        historyTeamCompareKey(record.away) === awayKey
      );
    })
    .sort((a, b) => Date.parse(b.generatedAt || "") - Date.parse(a.generatedAt || ""))[0] || null;
}

function findHistoryMatchForRecord(matches, record) {
  const list = arrayFrom(matches);
  const recordId = String(record?.matchId || "");
  const exact = findMatchByAnyId(list, recordId);
  if (exact) return exact;
  const alias = findMatchByHistoryAlias(list, recordId);
  if (alias) return alias;
  const recordDate = normalizeHistoryRecordDate(record?.date);
  const homeKey = historyTeamCompareKey(record?.home);
  const awayKey = historyTeamCompareKey(record?.away);
  if (!homeKey || !awayKey) return null;
  const sameDate = list.find((match) =>
    historyRecordDateMatchesMatch(recordDate, match) &&
    historyTeamCompareKey(teamLabel(match?.home)) === homeKey &&
    historyTeamCompareKey(teamLabel(match?.away)) === awayKey
  );
  if (sameDate) return sameDate;
  return list.find((match) =>
    historyTeamCompareKey(teamLabel(match?.home)) === homeKey &&
    historyTeamCompareKey(teamLabel(match?.away)) === awayKey
  ) || null;
}

function dedupeHistoryRecordPairs(matches, records) {
  const grouped = new Map();
  for (const record of arrayFrom(records)) {
    const match = findHistoryMatchForRecord(matches, record);
    const key = historyResolvedMatchKey(match, record);
    const current = grouped.get(key);
    if (!current || Date.parse(record.generatedAt || "") > Date.parse(current.record.generatedAt || "")) {
      grouped.set(key, { record, match });
    }
  }
  return [...grouped.values()]
    .sort((a, b) => {
      const dateA = a.match?.dateInfo?.label || a.record?.date || "";
      const dateB = b.match?.dateInfo?.label || b.record?.date || "";
      return String(dateB).localeCompare(String(dateA)) ||
        Date.parse(b.record?.generatedAt || "") - Date.parse(a.record?.generatedAt || "");
    });
}

function historyResolvedMatchKey(match, record) {
  if (match) {
    return [
      match?.dateInfo?.date || normalizeHistoryRecordDate(record?.date),
      historyTeamCompareKey(teamLabel(match?.home)),
      historyTeamCompareKey(teamLabel(match?.away)),
    ].join("|");
  }
  return [
    normalizeHistoryRecordDate(record?.date),
    historyTeamCompareKey(record?.home),
    historyTeamCompareKey(record?.away),
    String(record?.matchId || ""),
  ].join("|");
}

function historyRecordDateMatchesMatch(recordDate, match) {
  const date = normalizeHistoryRecordDate(recordDate);
  if (!date) return true;
  if (String(match?.dateInfo?.date || "") === date) return true;
  if (String(match?.venueDateInfo?.date || "") === date) return true;
  const start = matchStartMs(match);
  if (Number.isFinite(start)) {
    const beijingDate = zonedDateInfoFromUtcMs(start, "Asia/Shanghai").date;
    if (beijingDate === date) return true;
  }
  return false;
}

function normalizeHistoryRecordDate(value) {
  const match = String(value || "").match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (!match) return "";
  return `${match[1]}-${match[2].padStart(2, "0")}-${match[3].padStart(2, "0")}`;
}

function historyTeamCompareKey(value) {
  return normalizeWhitespace(value)
    .toLowerCase()
    .replace(/[()（）·.'’\-\s]/g, "")
    .replace(/刚果金|刚果民主共和国|民主刚果/g, "刚果（金）")
    .replace(/美国队/g, "美国");
}

function buildResultContext({ match, research, primaryScore, scorePortfolio, historyRecord }) {
  const actual = actualScoreFromMatch(match, research);
  const sportteryScore = historyRecord?.sporttery?.items?.score || null;
  const prematch = historyRecord
    ? {
        matchId: historyRecord.matchId || "",
        generatedAt: historyRecord.generatedAt || "",
        source: historyRecord.source || "",
        recommendedScore: historyRecord.recommendedScore || "",
        recommendedProbability: numberOrNull(historyRecord.recommendedProbability),
        topScores: arrayFrom(historyRecord.topScores).slice(0, 5),
        sportteryScore: sportteryScore
          ? {
              score: sportteryScore.score || sportteryScore.pick || "",
              pick: sportteryScore.pick || sportteryScore.score || "",
              probability: numberOrNull(sportteryScore.probability),
              logicVersion: historyRecord.sporttery?.logicVersion || "",
              anchorScore: historyRecord.sporttery?.alignment?.anchorScore || "",
            }
          : null,
      }
    : null;
  return {
    completed: Boolean(actual.completed),
    displayMode: actual.completed ? "actual" : "prediction",
    actual: actual.completed
      ? {
          score: `${actual.home}-${actual.away}`,
          homeGoals: actual.home,
          awayGoals: actual.away,
          source: actual.source || "",
        }
      : null,
    prematch,
    liveModel: {
      score: primaryScore?.score || "",
      probability: numberOrNull(primaryScore?.probability),
      topScores: arrayFrom(scorePortfolio).slice(0, 5),
    },
  };
}

function derivativePredictionRecordFrom(prediction) {
  const markets = prediction.derivativeMarkets || {};
  const setPieces = prediction.simulation?.setPieces || {};
  return {
    corners: derivativeMarketHistoryRecord("corners", markets.corners, setPieces.corners),
    cards: derivativeMarketHistoryRecord("cards", markets.cards, setPieces.cards),
  };
}

function publicScoreCalibrationState() {
  return {
    status: scoreCalibrationState.status,
    refreshedAt: scoreCalibrationState.refreshedAt,
    sample: scoreCalibrationState.sample,
    exactAccuracy: scoreCalibrationState.exactAccuracy,
    top3Accuracy: scoreCalibrationState.top3Accuracy,
    available: Boolean(scoreCalibrationState.profile?.available),
  };
}

async function refreshScoreCalibrationProfile(matches = [], options = {}) {
  if (scoreCalibrationState.status === "running") return scoreCalibrationState.profile;
  const last = Date.parse(scoreCalibrationState.refreshedAt || "");
  if (!options.force && scoreCalibrationState.profile && Number.isFinite(last) && Date.now() - last < 10 * 60 * 1000) {
    return scoreCalibrationState.profile;
  }
  scoreCalibrationState.status = "running";
  try {
    const profile = await buildScoreCalibrationProfile(matches);
    scoreCalibrationState.profile = profile;
    scoreCalibrationState.status = profile.available ? "ready" : "warming";
    scoreCalibrationState.refreshedAt = new Date().toISOString();
    scoreCalibrationState.sample = profile.sample || 0;
    scoreCalibrationState.exactAccuracy = profile.exactAccuracy ?? null;
    scoreCalibrationState.top3Accuracy = profile.top3Accuracy ?? null;
    scoreCalibrationState.errors = [];
    return profile;
  } catch (error) {
    scoreCalibrationState.status = "error";
    scoreCalibrationState.refreshedAt = new Date().toISOString();
    scoreCalibrationState.errors = [error.message];
    return null;
  }
}

async function buildScoreCalibrationProfile(matches = []) {
  const history = readPredictionHistory();
  const records = history.predictions || {};
  const candidates = arrayFrom(matches)
    .filter((match) => records[historyKey(match)]?.recommendedScore && isHistoryResultCandidate(match, records))
    .slice(0, 80);
  const rows = (
    await mapLimit(candidates, 4, async (match) => {
      const record = records[historyKey(match)];
      const result = await getCompletedMatchResult(match).catch(() => null);
      if (!record?.recommendedScore || !result?.completed) return null;
      return buildScoreCalibrationRow(record, result);
    })
  ).filter(Boolean);

  const actualCounts = {};
  const predictedStats = {};
  let exactHits = 0;
  let top3Hits = 0;
  for (const row of rows) {
    actualCounts[row.actualScore] = (actualCounts[row.actualScore] || 0) + 1;
    const stats = predictedStats[row.predictedScore] || {
      sample: 0,
      exactHits: 0,
      top3Hits: 0,
      distance: 0,
    };
    stats.sample += 1;
    if (row.exactHit) {
      stats.exactHits += 1;
      exactHits += 1;
    }
    if (row.top3Hit) {
      stats.top3Hits += 1;
      top3Hits += 1;
    }
    stats.distance += row.distance;
    predictedStats[row.predictedScore] = stats;
  }

  const scoreMultipliers = {};
  for (const [score, stats] of Object.entries(predictedStats)) {
    const exactRate = stats.exactHits / stats.sample;
    const top3Rate = stats.top3Hits / stats.sample;
    const avgDistance = stats.distance / stats.sample;
    scoreMultipliers[score] = {
      sample: stats.sample,
      exactRate: Number(exactRate.toFixed(4)),
      top3Rate: Number(top3Rate.toFixed(4)),
      avgDistance: Number(avgDistance.toFixed(3)),
      multiplier: Number(clamp(0.9 + exactRate * 0.42 + top3Rate * 0.16 - avgDistance * 0.055, 0.78, 1.16).toFixed(3)),
    };
  }

  const actualTotal = rows.length || 1;
  const actualPriors = {};
  for (const [score, count] of Object.entries(actualCounts)) {
    actualPriors[score] = Number((count / actualTotal).toFixed(4));
  }

  return {
    available: rows.length >= 3,
    sample: rows.length,
    exactAccuracy: rows.length ? ratio(exactHits, rows.length) : null,
    top3Accuracy: rows.length ? ratio(top3Hits, rows.length) : null,
    actualPriors,
    scoreMultipliers,
  };
}

function buildScoreCalibrationRow(record, result) {
  const predicted = parseScoreText(record.recommendedScore);
  const actual = result.score || parseScoreText(result.resultScore);
  const actualScore = `${actual.home}-${actual.away}`;
  const topScores = arrayFrom(record.topScores).slice(0, 3).map((score) => score.score);
  return {
    predictedScore: `${predicted.home}-${predicted.away}`,
    actualScore,
    exactHit: predicted.home === actual.home && predicted.away === actual.away,
    top3Hit: topScores.includes(actualScore),
    distance: Math.abs(predicted.home - actual.home) + Math.abs(predicted.away - actual.away),
  };
}

function derivativeMarketHistoryRecord(kind, market = {}, simulated = {}) {
  const total = market.total || {};
  const handicap = market.handicap || {};
  return {
    kind,
    label: kind === "cards" ? "罚牌" : "角球",
    sourceCount: Number(market.sourceCount || 0),
    sourceQuality: normalizeDerivativeSourceQuality(market.sourceQuality, market.sourceCount),
    expected: Number(market.expected ?? simulated.expected ?? 0) || null,
    simulated: {
      home: numberOrNull(simulated.home),
      away: numberOrNull(simulated.away),
      total: numberOrNull(simulated.total),
    },
    total: {
      line: numberOrNull(total.line),
      side: total.side || derivativeTotalSide(total),
      pick: total.recommendation?.pick || simulated.recommendation || "",
      confidence: total.recommendation?.confidence || "",
      over: numberOrNull(total.over),
      under: numberOrNull(total.under),
      lineSource: total.lineSource || "",
    },
    handicap: {
      line: numberOrNull(handicap.line),
      pick: handicap.recommendation?.pick || simulated.handicap || "",
      confidence: handicap.recommendation?.confidence || "",
      favoriteSide: handicap.favoriteSide || "",
      favoriteName: handicap.favoriteName || "",
      favoriteCover: numberOrNull(handicap.favoriteCover),
      underdogName: handicap.underdogName || "",
      underdogCover: numberOrNull(handicap.underdogCover),
      pressureSide: handicap.pressureSide || "",
      pressureName: handicap.pressureName || "",
      pressureCover: numberOrNull(handicap.pressureCover),
      oppositeName: handicap.oppositeName || "",
      oppositeCover: numberOrNull(handicap.oppositeCover),
      recommendedSide: derivativeHandicapRecommendedSide(kind, handicap),
    },
  };
}

function derivativeHandicapRecommendedSide(kind, handicap = {}) {
  const pick = String(handicap.recommendation?.pick || "");
  if (!pick || /观望|暂无|谨慎/.test(pick)) return "watch";
  if (kind === "cards") {
    const pressure = Number(handicap.pressureCover);
    const opposite = Number(handicap.oppositeCover);
    if (!Number.isFinite(pressure) || !Number.isFinite(opposite)) return "watch";
    return pressure >= opposite ? "pressure" : "opposite";
  }
  const favorite = Number(handicap.favoriteCover);
  const underdog = Number(handicap.underdogCover);
  if (!Number.isFinite(favorite) || !Number.isFinite(underdog)) return "watch";
  return favorite >= underdog ? "favorite" : "underdog";
}

function sportteryHistoryRecordFrom(prediction) {
  const sporttery = prediction.sportteryRecommendation || {};
  if (!sporttery.available) return null;
  const itemMap = {};
  for (const item of arrayFrom(sporttery.items)) {
    if (!item?.marketKey || item.side === "watch") continue;
    itemMap[item.marketKey] = {
      marketKey: item.marketKey,
      market: item.market,
      pick: item.pick,
      side: item.side,
      line: numberOrNull(item.line),
      probability: numberOrNull(item.probability),
      odds: numberOrNull(item.odds),
      score: item.score || "",
      scoreKey: item.scoreKey || "",
      totalGoals: item.totalGoals ?? null,
      confidence: item.confidence || "",
    };
  }
  if (!Object.keys(itemMap).length) return null;
  return {
    available: true,
    source: sporttery.source || "中国体彩网/竞彩网",
    officialMatchId: sporttery.officialMatchId || "",
    matchNum: sporttery.matchNum || "",
    updateTime: sporttery.updateTime || "",
    logicVersion: sporttery.logicVersion || "sporttery-anchor-v2",
    alignment: sporttery.alignment || null,
    items: itemMap,
  };
}

async function buildPredictionHistoryStats(matches, options = {}) {
  const history = readPredictionHistory();
  const records = history.predictions || {};
  const rows = [];
  const skippedRows = [];
  const rawRecordList = Object.values(records)
    .filter((record) => record?.recommendedScore)
    .sort((a, b) => Date.parse(b.generatedAt || "") - Date.parse(a.generatedAt || ""));
  const recordPairs = dedupeHistoryRecordPairs(matches, rawRecordList);

  const processedRows = await mapLimit(recordPairs, options.fast ? 6 : 4, async ({ record, match }) => {
    if (!match) {
      skippedRows.push({
        matchId: String(record.matchId || ""),
        match: `${record.home || "--"} vs ${record.away || "--"}`,
        reason: "未匹配到当前赛程",
      });
      return pendingHistoryRow(null, record, "未匹配到当前赛程");
    }
    try {
      const result = await getCompletedMatchResult(match, { includeTechnical: !options.fast }).catch(() => null);
      if (!result?.completed) return pendingHistoryRow(match, record, "赛果待核验");
      let settledRecord = record;
      if (!options.fast && !settledRecord.derivatives?.corners && !settledRecord.derivatives?.cards) {
        const derivativeRecord = await buildBacktestPredictionRecord(match).catch(() => null);
        if (derivativeRecord?.derivatives) {
          settledRecord = { ...settledRecord, derivatives: derivativeRecord.derivatives };
        }
      }
      return historyRow(match, settledRecord, result);
    } catch (error) {
      skippedRows.push({
        matchId: historyKey(match),
        match: `${teamLabel(match.home)} vs ${teamLabel(match.away)}`,
        reason: error?.message || String(error),
      });
      return pendingHistoryRow(match, record, "赛果抓取失败");
    }
  });
  rows.push(...processedRows.filter(Boolean));

  rows.sort((a, b) =>
    String(b.matchDate).localeCompare(String(a.matchDate)) ||
    Date.parse(b.generatedAt || "") - Date.parse(a.generatedAt || "")
  );

  const settledRows = rows.filter((row) => row.settled !== false);
  const evaluated = settledRows.length;
  const exactHits = settledRows.filter((row) => row.exactScoreHit).length;
  const directionHits = settledRows.filter((row) => row.resultDirectionHit).length;
  const top3Hits = settledRows.filter((row) => row.top3ScoreHit).length;
  const totalGoalHits = settledRows.filter((row) => row.totalGoalsHit).length;
  const averageScoreDistance = evaluated
    ? settledRows.reduce((sum, row) => sum + row.scoreDistance, 0) / evaluated
    : null;
  const derivativeRows = settledRows.flatMap((row) => row.derivatives || []);
  const derivativeSummary = summarizeDerivativeHistory(derivativeRows);
  const sportteryRows = settledRows.flatMap((row) => row.sporttery || []);
  const sportterySummary = summarizeSportteryHistory(sportteryRows);

  const pendingRows = rows.filter((row) => row.settled === false);
  const pendingRecords = pendingRows.length;
  const unrecordedCompletedRows = buildUnrecordedCompletedHistoryRows(matches, recordPairs);
  const displayRows = [...settledRows, ...unrecordedCompletedRows].sort((a, b) =>
    String(b.matchDate).localeCompare(String(a.matchDate)) ||
    Date.parse(b.generatedAt || "") - Date.parse(a.generatedAt || "")
  );

  return {
    summary: {
      savedRecords: rawRecordList.length,
      uniqueMatches: recordPairs.length,
      duplicateRecords: Math.max(0, rawRecordList.length - recordPairs.length),
      finishedMatches: settledRows.length,
      evaluatedMatches: evaluated,
      unrecordedFinishedMatches: unrecordedCompletedRows.length,
      pendingRecords,
      exactScoreHits: exactHits,
      exactScoreAccuracy: ratio(exactHits, evaluated),
      resultDirectionHits: directionHits,
      resultDirectionAccuracy: ratio(directionHits, evaluated),
      top3ScoreHits: top3Hits,
      top3ScoreAccuracy: ratio(top3Hits, evaluated),
      totalGoalsHits: totalGoalHits,
      totalGoalsAccuracy: ratio(totalGoalHits, evaluated),
      averageScoreDistance: averageScoreDistance === null ? null : Number(averageScoreDistance.toFixed(2)),
      skippedRows: skippedRows.length,
    },
    derivativeSummary,
    derivativeRows,
    sportterySummary,
    sportteryRows,
    skippedRows,
    pendingRows,
    rows: displayRows,
  };
}

function isHistoryResultCandidate(match, records) {
  if (match.finished) return true;
  if (records[historyKey(match)] && !isMatchDateAfterToday(match)) return true;
  return !isMatchDateAfterToday(match);
}

async function getCompletedMatchResult(match, options = {}) {
  const local = localCompletedResult(match);
  if (local) {
    if (options.includeTechnical === false) {
      return {
        ...local,
        technicalStats: {
          available: false,
          source: "fast history",
          message: "快速历史统计已跳过逐场技术统计补抓",
        },
      };
    }
    const technicalStats = await getCompletedTechnicalStats(match).catch((error) => ({
      available: false,
      source: "ESPN summary",
      message: `技术统计抓取失败：${error.message}`,
    }));
    return { ...local, technicalStats };
  }
  if (isMatchDateAfterToday(match)) return null;
  let espn = await getEspnContext(match);
  if (!espn?.completed || !Number.isFinite(espn.score?.home) || !Number.isFinite(espn.score?.away)) {
    const refreshed = await refreshEspnSummaryResult(match, espn).catch(() => null);
    if (refreshed?.completed && Number.isFinite(refreshed.score?.home) && Number.isFinite(refreshed.score?.away)) {
      espn = refreshed;
    } else {
      return null;
    }
  }
  return {
    completed: true,
    source: espn.mode || "ESPN",
    score: {
      home: espn.score.home,
      away: espn.score.away,
    },
    resultScore: `${espn.score.home}-${espn.score.away}`,
    status: espn.status || "完场",
    technicalStats: espn.technicalStats || null,
  };
}

async function refreshEspnSummaryResult(match, espnContext = {}) {
  if (!espnContext?.eventId && !espnContext?.summaryUrl) return null;
  const summaryUrl = espnContext.summaryUrl || `${ESPN_SUMMARY}?event=${espnContext.eventId}`;
  const summary = await fetchJson(summaryUrl, { timeout: 15000 });
  const competition = summary?.header?.competitions?.[0];
  if (!competition) return null;
  const event = {
    id: espnContext.eventId || summary?.header?.id || "",
    name: summary?.header?.name || espnContext.name || "",
    shortName: summary?.header?.shortName || "",
    date: competition.date || espnContext.date || "",
    status: competition.status || summary?.header?.status || {},
    venue: competition.venue || {},
    competitions: [competition],
    competitors: competition.competitors || [],
    provider: espnContext.provider || {},
  };
  return buildEspnContextFromEvent({
    event,
    provider: espnContext.provider || {},
    match,
    summary,
    scoreboardUrl: espnContext.scoreboardUrl || "",
    summaryUrl,
    mode: "实时 ESPN summary",
    warning: espnContext.warning || "",
    cacheFetchedAt: espnContext.cacheFetchedAt || "",
  });
}

async function getCompletedTechnicalStats(match) {
  if (isMatchDateAfterToday(match)) {
    return { available: false, source: "ESPN summary", message: "比赛未完场，暂不抓取技术统计" };
  }
  const espn = await getEspnContext(match);
  return espn?.technicalStats || {
    available: false,
    source: "ESPN summary",
    message: "ESPN 未返回技术统计",
  };
}

function localCompletedResult(match) {
  if (!match?.finished) return null;
  const home = numberOrNull(match.score?.home);
  const away = numberOrNull(match.score?.away);
  if (!Number.isFinite(home) || !Number.isFinite(away)) return null;
  return {
    completed: true,
    source: "赛程接口",
    score: { home, away },
    resultScore: `${home}-${away}`,
    status: "完场",
  };
}

async function buildBacktestPredictionRecord(match) {
  const venue = match.stadium || {};
  const research = await buildResearch(match, venue, { quick: true, quickDerivative: true }).catch((error) => fallbackResearch(match, error));
  const prediction = buildPrediction({
    match,
    venue,
    geo: { available: false, label: "" },
    weather: unavailable("历史统计回测跳过天气抓取"),
    elevation: { available: false, meters: null, message: "历史统计回测跳过海拔抓取" },
    research,
    odds: { enabled: false, available: false, message: "历史统计回测未使用外部赔率 API", markets: [] },
  });
  return predictionRecordFrom(match, prediction, {
    source: "当前模型回测",
    generatedAt: new Date().toISOString(),
  });
}

function historyRow(match, record, result) {
  const predicted = parseScoreText(record.recommendedScore);
  const actual = result.score || parseScoreText(result.resultScore);
  const exactScoreHit = predicted.home === actual.home && predicted.away === actual.away;
  const resultDirectionHit = scoreDirection(predicted) === scoreDirection(actual);
  const totalGoalsHit = predicted.home + predicted.away === actual.home + actual.away;
  const goalDiffHit = predicted.home - predicted.away === actual.home - actual.away;
  const top3 = (record.topScores || []).slice(0, 3).map((score) => score.score);
  const top3ScoreHit = top3.includes(`${actual.home}-${actual.away}`);
  const scoreDistance = Math.abs(predicted.home - actual.home) + Math.abs(predicted.away - actual.away);
  return {
    settled: true,
    matchId: historyKey(match),
    historyMatchId: String(record.matchId || ""),
    matchDate: match.dateInfo?.label || record.date || "",
    match: `${teamLabel(match.home)} vs ${teamLabel(match.away)}`,
    home: teamLabel(match.home),
    away: teamLabel(match.away),
    recommendedScore: record.recommendedScore,
    recommendedProbability: record.recommendedProbability,
    resultScore: `${actual.home}-${actual.away}`,
    exactScoreHit,
    resultDirectionHit,
    top3ScoreHit,
    totalGoalsHit,
    goalDiffHit,
    scoreDistance,
    predictionSource: record.source || "",
    resultSource: result.source || "",
    generatedAt: record.generatedAt || "",
    status: result.status || "",
    sporttery: buildSportteryHistoryRows(match, record, result),
    derivatives: buildDerivativeHistoryRows(match, record, result),
  };
}

function pendingHistoryRow(match, record, reason = "赛果待核验") {
  const home = match ? teamLabel(match.home) : record?.home || "--";
  const away = match ? teamLabel(match.away) : record?.away || "--";
  return {
    settled: false,
    matchId: match ? historyKey(match) : String(record?.matchId || ""),
    historyMatchId: String(record?.matchId || ""),
    matchDate: match?.dateInfo?.label || record?.date || "",
    match: `${home} vs ${away}`,
    home,
    away,
    recommendedScore: record?.recommendedScore || "",
    recommendedProbability: record?.recommendedProbability ?? null,
    resultScore: "待核验",
    exactScoreHit: false,
    resultDirectionHit: false,
    top3ScoreHit: false,
    totalGoalsHit: false,
    goalDiffHit: false,
    scoreDistance: null,
    predictionSource: record?.source || "",
    resultSource: reason,
    generatedAt: record?.generatedAt || "",
    status: reason,
    sporttery: [],
    derivatives: [],
  };
}

function buildUnrecordedCompletedHistoryRows(matches, recordPairs) {
  const recorded = new Set(recordPairs.map(({ match, record }) => historyMatchIdentity(match, record)));
  return arrayFrom(matches)
    .filter((match) => match?.finished)
    .filter((match) => {
      const identity = historyMatchIdentity(match, null);
      return identity && !recorded.has(identity);
    })
    .map((match) => noPrematchHistoryRow(match));
}

function noPrematchHistoryRow(match) {
  const home = teamLabel(match.home);
  const away = teamLabel(match.away);
  const homeScore = numberOrZero(match.score?.home);
  const awayScore = numberOrZero(match.score?.away);
  return {
    settled: false,
    noPrematch: true,
    uncounted: true,
    matchId: historyKey(match),
    historyMatchId: "",
    matchDate: match?.dateInfo?.label || "",
    match: `${home} vs ${away}`,
    home,
    away,
    recommendedScore: "未保存赛前推荐",
    recommendedProbability: null,
    resultScore: `${homeScore}-${awayScore}`,
    exactScoreHit: false,
    resultDirectionHit: false,
    top3ScoreHit: false,
    totalGoalsHit: false,
    goalDiffHit: false,
    scoreDistance: null,
    predictionSource: "未保存赛前推荐",
    resultSource: "赛程接口",
    generatedAt: "",
    status: "未保存，不计准确率",
    sporttery: [],
    derivatives: [],
  };
}

function historyMatchIdentity(match, record) {
  const start = matchStartMs(match);
  const date = Number.isFinite(start)
    ? zonedDateInfoFromUtcMs(start, "Asia/Shanghai").date
    : match?.dateInfo?.date || normalizeHistoryRecordDate(record?.date);
  const home = historyTeamCompareKey(match ? teamLabel(match.home) : record?.home);
  const away = historyTeamCompareKey(match ? teamLabel(match.away) : record?.away);
  return date && home && away ? `${date}|${home}|${away}` : "";
}

function buildSportteryHistoryRows(match, record, result) {
  const sporttery = record.sporttery;
  if (!sporttery?.available || !sporttery.items) return [];
  const actual = result.score || parseScoreText(result.resultScore);
  const actualTotal = actual.home + actual.away;
  const actualResultSide = scoreDirection(actual);
  const actualTotalBucket = sportteryTotalGoalsBucket(actualTotal);
  const actualScoreKey = sportteryScoreKey(actual.home, actual.away);
  const rows = [];
  const base = {
    matchId: historyKey(match),
    matchDate: match.dateInfo?.label || record.date || "",
    match: `${teamLabel(match.home)} vs ${teamLabel(match.away)}`,
    home: teamLabel(match.home),
    away: teamLabel(match.away),
    source: sporttery.source || "中国体彩网/竞彩网",
    officialMatchId: sporttery.officialMatchId || "",
    matchNum: sporttery.matchNum || "",
    updateTime: sporttery.updateTime || "",
    predictionSource: record.source || "",
    generatedAt: record.generatedAt || "",
  };

  const resultPick = sporttery.items.result;
  if (resultPick) {
    rows.push({
      ...base,
      marketKey: "result",
      market: "胜平负",
      recommended: resultPick.pick || sportteryResultLabel(resultPick.side, match),
      resultText: sportteryResultLabel(actualResultSide, match),
      odds: resultPick.odds,
      probability: resultPick.probability,
      hit: resultPick.side === actualResultSide,
      settled: true,
    });
  }

  const handicapPick = sporttery.items.handicap;
  if (handicapPick && Number.isFinite(Number(handicapPick.line))) {
    const actualHandicapSide = sportteryHandicapSide(actual.home, actual.away, Number(handicapPick.line));
    rows.push({
      ...base,
      marketKey: "handicap",
      market: "让球胜平负",
      recommended: handicapPick.pick || sportteryHandicapResultLabel(handicapPick.side, handicapPick.line, match),
      resultText: sportteryHandicapResultLabel(actualHandicapSide, handicapPick.line, match),
      line: numberOrNull(handicapPick.line),
      odds: handicapPick.odds,
      probability: handicapPick.probability,
      hit: handicapPick.side === actualHandicapSide,
      settled: true,
    });
  }

  const totalPick = sporttery.items.totalGoals;
  if (totalPick) {
    rows.push({
      ...base,
      marketKey: "totalGoals",
      market: "总进球数",
      recommended: totalPick.pick || `${totalPick.totalGoals} 球`,
      resultText: `${actualTotal} 球`,
      odds: totalPick.odds,
      probability: totalPick.probability,
      hit: String(totalPick.side) === String(actualTotalBucket),
      settled: true,
    });
  }

  const scorePick = sporttery.items.score;
  if (scorePick) {
    rows.push({
      ...base,
      marketKey: "score",
      market: "比分",
      recommended: scorePick.pick || scorePick.score || "--",
      resultText: `${actual.home}-${actual.away}`,
      odds: scorePick.odds,
      probability: scorePick.probability,
      hit: String(scorePick.scoreKey || "") === actualScoreKey,
      settled: true,
    });
  }

  return rows;
}

function buildDerivativeHistoryRows(match, record, result) {
  const rows = [];
  const technical = result.technicalStats || {};
  for (const kind of ["corners", "cards"]) {
    const label = kind === "cards" ? "罚牌" : "角球";
    const predicted = record.derivatives?.[kind];
    const actual = technical[kind];
    if (!predicted || !actual) continue;
    const base = {
      matchId: historyKey(match),
      matchDate: match.dateInfo?.label || record.date || "",
      match: `${teamLabel(match.home)} vs ${teamLabel(match.away)}`,
      kind,
      label,
      sourceQuality: predicted.sourceQuality || null,
      sourceQualityLabel: predicted.sourceQuality?.label || "",
      sourceQualityScore: numberOrNull(predicted.sourceQuality?.score),
      actualHome: actual.home,
      actualAway: actual.away,
      actualTotal: actual.total,
      resultText: `${actual.home}-${actual.away}，总 ${actual.total}`,
      source: technical.source || "ESPN summary",
      predictionSource: record.source || "",
      generatedAt: record.generatedAt || "",
    };
    const totalRow = derivativeTotalHistoryRow(base, predicted.total);
    if (totalRow) rows.push(totalRow);
    const handicapRow = derivativeHandicapHistoryRow(base, predicted.handicap);
    if (handicapRow) rows.push(handicapRow);
  }
  return rows;
}

function derivativeTotalHistoryRow(base, total = {}) {
  const line = Number(total.line);
  const side = total.side || "watch";
  if (!Number.isFinite(line) || side === "watch") return null;
  const hit = side === "over" ? Number(base.actualTotal) > line : Number(base.actualTotal) < line;
  return {
    ...base,
    market: "大小",
    marketKey: `${base.kind}-total`,
    recommended: total.pick || `${side === "over" ? "大于" : "小于"} ${formatTotalLine(line)}`,
    line,
    side,
    hit,
    settled: true,
  };
}

function derivativeHandicapHistoryRow(base, handicap = {}) {
  const line = Number(handicap.line);
  const side = handicap.recommendedSide || "watch";
  if (!Number.isFinite(line) || side === "watch") return null;
  const hit = base.kind === "cards"
    ? settleCardHandicap(base, handicap, line, side)
    : settleCornerHandicap(base, handicap, line, side);
  return {
    ...base,
    market: "让球",
    marketKey: `${base.kind}-handicap`,
    recommended: handicap.pick || "让球观望",
    line,
    side,
    hit,
    settled: hit !== null,
  };
}

function settleCornerHandicap(base, handicap, line, side) {
  const favoriteSide = handicap.favoriteSide;
  if (!["home", "away"].includes(favoriteSide)) return null;
  const favoriteCount = favoriteSide === "home" ? Number(base.actualHome) : Number(base.actualAway);
  const underdogCount = favoriteSide === "home" ? Number(base.actualAway) : Number(base.actualHome);
  if (!Number.isFinite(favoriteCount) || !Number.isFinite(underdogCount)) return null;
  return side === "favorite"
    ? favoriteCount - underdogCount > line
    : underdogCount + line > favoriteCount;
}

function settleCardHandicap(base, handicap, line, side) {
  const pressureSide = handicap.pressureSide;
  if (!["home", "away"].includes(pressureSide)) return null;
  const pressureCount = pressureSide === "home" ? Number(base.actualHome) : Number(base.actualAway);
  const oppositeCount = pressureSide === "home" ? Number(base.actualAway) : Number(base.actualHome);
  if (!Number.isFinite(pressureCount) || !Number.isFinite(oppositeCount)) return null;
  return side === "pressure"
    ? pressureCount + line > oppositeCount
    : oppositeCount + line > pressureCount;
}

function summarizeDerivativeHistory(rows) {
  const clean = arrayFrom(rows).filter((row) => row.settled);
  const highQuality = clean.filter((row) => Number(row.sourceQualityScore || 0) >= 1 || /高|较高/.test(row.sourceQualityLabel || ""));
  const byKey = {};
  for (const key of ["corners-total", "corners-handicap", "cards-total", "cards-handicap"]) {
    const group = clean.filter((row) => row.marketKey === key);
    const hits = group.filter((row) => row.hit).length;
    byKey[key] = {
      evaluated: group.length,
      hits,
      accuracy: ratio(hits, group.length),
    };
  }
  const totalHits = clean.filter((row) => row.hit).length;
  const highQualityHits = highQuality.filter((row) => row.hit).length;
  return {
    evaluated: clean.length,
    hits: totalHits,
    accuracy: ratio(totalHits, clean.length),
    highQualityEvaluated: highQuality.length,
    highQualityHits,
    highQualityAccuracy: ratio(highQualityHits, highQuality.length),
    cornersTotal: byKey["corners-total"],
    cornersHandicap: byKey["corners-handicap"],
    cardsTotal: byKey["cards-total"],
    cardsHandicap: byKey["cards-handicap"],
    unavailableRows: arrayFrom(rows).length - clean.length,
  };
}

function summarizeSportteryHistory(rows) {
  const clean = arrayFrom(rows).filter((row) => row.settled);
  const byKey = {};
  for (const key of ["result", "handicap", "totalGoals", "score"]) {
    const group = clean.filter((row) => row.marketKey === key);
    const hits = group.filter((row) => row.hit).length;
    byKey[key] = {
      evaluated: group.length,
      hits,
      accuracy: ratio(hits, group.length),
    };
  }
  const hits = clean.filter((row) => row.hit).length;
  return {
    evaluated: clean.length,
    hits,
    accuracy: ratio(hits, clean.length),
    result: byKey.result,
    handicap: byKey.handicap,
    totalGoals: byKey.totalGoals,
    score: byKey.score,
    unavailableRows: arrayFrom(rows).length - clean.length,
  };
}

function parseScoreText(score) {
  const match = String(score || "").match(/(\d+)\s*[-:]\s*(\d+)/);
  return {
    home: match ? Number(match[1]) : 0,
    away: match ? Number(match[2]) : 0,
  };
}

function scoreDirection(score) {
  if (score.home > score.away) return "home";
  if (score.home < score.away) return "away";
  return "draw";
}

function historyKey(match) {
  return String(match?.id || "");
}

function ratio(numerator, denominator) {
  return denominator ? Number((numerator / denominator).toFixed(4)) : null;
}

function isMatchDateBeforeToday(match) {
  const date = match?.dateInfo?.date;
  return Boolean(date && date < todayShanghai());
}

function isMatchDateAfterToday(match) {
  const date = match?.dateInfo?.date;
  return Boolean(date && date > todayShanghai());
}

function hasMatchStarted(match, bufferMs = 0) {
  const start = matchStartMs(match);
  return Number.isFinite(start) && start <= Date.now() + bufferMs;
}

function todayShanghai() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date());
  const map = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${map.year}-${map.month}-${map.day}`;
}

async function getFootballDataWorldCup() {
  const key = String(process.env.FOOTBALL_DATA_API_KEY || process.env.FOOTBALL_DATA_TOKEN || "").trim();
  if (!key) {
    return {
      available: false,
      message: "未配置 football-data.org API key",
      matches: [],
      teams: [],
      source: `${FOOTBALL_DATA_API}/competitions/WC/matches`,
    };
  }

  try {
    return await cached("football-data-wc", 20 * 60 * 1000, async () => {
      const headers = { "X-Auth-Token": key };
      const [matchesJson, teamsJson] = await Promise.all([
        fetchJson(`${FOOTBALL_DATA_API}/competitions/WC/matches`, {
          headers,
          timeout: 18000,
        }),
        fetchJson(`${FOOTBALL_DATA_API}/competitions/WC/teams`, {
          headers,
          timeout: 18000,
        }),
      ]);
      return {
        available: true,
        matches: arrayFrom(matchesJson.matches),
        teams: arrayFrom(teamsJson.teams),
        source: `${FOOTBALL_DATA_API}/competitions/WC/matches`,
      };
    });
  } catch (error) {
    return {
      available: false,
      message: error.message,
      matches: [],
      teams: [],
      source: `${FOOTBALL_DATA_API}/competitions/WC/matches`,
    };
  }
}

async function findMatchByFootballDataAlias(matches, matchId) {
  const target = String(matchId || "");
  if (!/^\d{4,}$/.test(target)) return null;
  const cachedAlias = findMatchByPersistedAlias(matches, target);
  if (cachedAlias) return cachedAlias;
  const key = String(process.env.FOOTBALL_DATA_API_KEY || process.env.FOOTBALL_DATA_TOKEN || "").trim();
  if (!key) return null;
  const official = await cached(`football-data-match:${target}`, 20 * 60 * 1000, async () =>
    fetchJson(`${FOOTBALL_DATA_API}/matches/${encodeURIComponent(target)}`, {
      headers: { "X-Auth-Token": key },
      timeout: 12000,
    })
  ).catch(() => null);
  const matchData = official?.id ? official : official?.match || null;
  if (!matchData?.id) return null;
  const fallback = findFallbackMatch(matchData, arrayFrom(matches));
  if (fallback) rememberMatchIdAlias(matchData.id, fallback);
  return fallback || null;
}

function normalizeFootballDataMatch(match, fallbackMatches, footballTeams) {
  const fallback = findFallbackMatch(match, fallbackMatches);
  const officialDateInfo = parseIsoDateInfo(match.utcDate);
  const dateInfo = officialDateInfo.date ? officialDateInfo : fallback?.dateInfo || parseIsoDateInfo(match.utcDate);
  const homeTeam = findFootballDataTeam(footballTeams, match.homeTeam?.id, match.homeTeam?.name);
  const awayTeam = findFootballDataTeam(footballTeams, match.awayTeam?.id, match.awayTeam?.name);
  const group = String(match.group || fallback?.group || "").replace(/^GROUP_/, "");
  const type = match.stage === "GROUP_STAGE" ? "group" : String(match.stage || fallback?.type || "").toLowerCase();

  return {
    id: String(match.id),
    sourceIds: {
      footballData: String(match.id),
      worldcup26: fallback?.id || "",
    },
    group,
    matchday: String(match.matchday || fallback?.matchday || ""),
    type,
    localDateRaw: fallback?.localDateRaw || match.utcDate || "",
    kickoffUtc: match.utcDate || fallback?.kickoffUtc || "",
    dateInfo,
    venueDateInfo: fallback?.venueDateInfo || null,
    sortKey: `${dateInfo.date || "9999-99-99"} ${dateInfo.time || "99:99"} ${String(match.id).padStart(8, "0")}`,
    home: {
      id: String(match.homeTeam?.id || fallback?.home?.id || ""),
      footballDataId: String(match.homeTeam?.id || ""),
      name: match.homeTeam?.name || fallback?.home?.name || "TBD",
      displayName: teamChineseName(match.homeTeam?.tla || fallback?.home?.code, match.homeTeam?.name || fallback?.home?.name),
      code: match.homeTeam?.tla || fallback?.home?.code || "",
      flag: match.homeTeam?.crest || fallback?.home?.flag || "",
      group: homeTeam?.group || group,
      squadCount: arrayFrom(homeTeam?.squad).length,
      coach: homeTeam?.coach?.name || "",
    },
    away: {
      id: String(match.awayTeam?.id || fallback?.away?.id || ""),
      footballDataId: String(match.awayTeam?.id || ""),
      name: match.awayTeam?.name || fallback?.away?.name || "TBD",
      displayName: teamChineseName(match.awayTeam?.tla || fallback?.away?.code, match.awayTeam?.name || fallback?.away?.name),
      code: match.awayTeam?.tla || fallback?.away?.code || "",
      flag: match.awayTeam?.crest || fallback?.away?.flag || "",
      group: awayTeam?.group || group,
      squadCount: arrayFrom(awayTeam?.squad).length,
      coach: awayTeam?.coach?.name || "",
    },
    stadium: fallback?.stadium || {
      id: "",
      name: "",
      fifaName: "",
      city: "",
      country: "",
      capacity: 0,
      region: "",
    },
    finished: ["FINISHED", "AWARDED"].includes(String(match.status || "").toUpperCase()),
    score: {
      home: numberOrZero(match.score?.fullTime?.home),
      away: numberOrZero(match.score?.fullTime?.away),
    },
    footballData: {
      id: String(match.id),
      utcDate: match.utcDate,
      status: match.status,
      stage: match.stage,
      group: match.group,
      lastUpdated: match.lastUpdated,
      oddsMessage: match.odds?.msg || "",
    },
  };
}

function findFallbackMatch(match, fallbackMatches) {
  const home = match.homeTeam?.name || "";
  const away = match.awayTeam?.name || "";
  const officialStart = Date.parse(match.utcDate || "");
  const officialBeijingDate = Number.isFinite(officialStart)
    ? zonedDateInfoFromUtcMs(officialStart, "Asia/Shanghai").date
    : String(match.utcDate || "").slice(0, 10);
  const sameTeamMatches = fallbackMatches.filter((candidate) =>
    teamNamesOverlap(candidate.home.name, home) &&
    teamNamesOverlap(candidate.away.name, away)
  );
  if (sameTeamMatches.length && Number.isFinite(officialStart)) {
    const timed = sameTeamMatches
      .map((candidate) => ({
        candidate,
        delta: Math.abs(matchStartMs(candidate) - officialStart),
      }))
      .filter((item) => Number.isFinite(item.delta))
      .sort((a, b) => a.delta - b.delta);
    if (timed[0]?.delta <= 18 * 60 * 60 * 1000) return timed[0].candidate;
  }
  return (
    fallbackMatches.find((candidate) => {
      const sameTeams =
        teamNamesOverlap(candidate.home.name, home) &&
        teamNamesOverlap(candidate.away.name, away);
      const sameDate = !officialBeijingDate ||
        candidate.dateInfo.date === officialBeijingDate ||
        candidate.venueDateInfo?.date === officialBeijingDate;
      return sameTeams && sameDate;
    }) ||
    sameTeamMatches[0] ||
    null
  );
}

function findFootballDataTeam(teams, id, name) {
  const normalized = normalizeTeamName(name);
  return (
    arrayFrom(teams).find((team) => String(team.id) === String(id)) ||
    arrayFrom(teams).find((team) => normalizeTeamName(team.name) === normalized) ||
    null
  );
}

function normalizeMatch(game, stadiumMap, teamMap) {
  const homeTeam = teamMap.get(String(game.home_team_id)) || {};
  const awayTeam = teamMap.get(String(game.away_team_id)) || {};
  const stadium = stadiumMap.get(String(game.stadium_id)) || {};
  const venueDateInfo = parseLocalDate(game.local_date);
  const venueTimeZone = hostCityTimeZone(stadium);
  const kickoffUtcMs = venueTimeZone
    ? zonedLocalTimeToUtcMs(venueDateInfo.date, venueDateInfo.time, venueTimeZone)
    : NaN;
  const dateInfo = Number.isFinite(kickoffUtcMs)
    ? zonedDateInfoFromUtcMs(kickoffUtcMs, "Asia/Shanghai", "北京时间")
    : venueDateInfo;
  const homeName = game.home_team_name_en || game.home_team_label || homeTeam.name_en || "TBD";
  const awayName = game.away_team_name_en || game.away_team_label || awayTeam.name_en || "TBD";

  return {
    id: String(game.id),
    group: game.group || "",
    matchday: game.matchday || "",
    type: game.type || "",
    localDateRaw: game.local_date || "",
    kickoffUtc: Number.isFinite(kickoffUtcMs) ? new Date(kickoffUtcMs).toISOString() : "",
    dateInfo,
    venueDateInfo,
    sortKey: `${dateInfo.date || "9999-99-99"} ${dateInfo.time || "99:99"} ${String(game.id).padStart(3, "0")}`,
    home: {
      id: String(game.home_team_id || ""),
      name: homeName,
      displayName: teamChineseName(homeTeam.fifa_code, homeName),
      code: homeTeam.fifa_code || "",
      flag: homeTeam.flag || "",
      group: homeTeam.groups || game.group || "",
    },
    away: {
      id: String(game.away_team_id || ""),
      name: awayName,
      displayName: teamChineseName(awayTeam.fifa_code, awayName),
      code: awayTeam.fifa_code || "",
      flag: awayTeam.flag || "",
      group: awayTeam.groups || game.group || "",
    },
    stadium: {
      id: String(stadium.id || game.stadium_id || ""),
      name: stadium.name_en || "",
      fifaName: stadium.fifa_name || "",
      city: stadium.city_en || "",
      country: stadium.country_en || "",
      capacity: Number(stadium.capacity || 0),
      region: stadium.region || "",
    },
    finished: String(game.finished || "").toUpperCase() === "TRUE",
    score: {
      home: Number(game.home_score || 0),
      away: Number(game.away_score || 0),
    },
  };
}

function parseLocalDate(value) {
  const match = String(value || "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2})/);
  if (!match) {
    return { date: "", time: "", label: value || "" };
  }
  const [, mm, dd, yyyy, hh, min] = match;
  const date = `${yyyy}-${mm.padStart(2, "0")}-${dd.padStart(2, "0")}`;
  const time = `${hh.padStart(2, "0")}:${min}`;
  return {
    date,
    time,
    year: Number(yyyy),
    month: Number(mm),
    day: Number(dd),
    hour: Number(hh),
    minute: Number(min),
    label: `${date} ${time}`,
  };
}

function parseIsoDateInfo(value) {
  const iso = String(value || "");
  const ms = Date.parse(iso);
  if (Number.isFinite(ms)) {
    return zonedDateInfoFromUtcMs(ms, "Asia/Shanghai", "北京时间");
  }
  const match = iso.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
  if (!match) return { date: "", time: "", label: value || "" };
  const [, yyyy, mm, dd, hh, min] = match;
  return {
    date: `${yyyy}-${mm}-${dd}`,
    time: `${hh}:${min}`,
    year: Number(yyyy),
    month: Number(mm),
    day: Number(dd),
    hour: Number(hh),
    minute: Number(min),
    label: `${yyyy}-${mm}-${dd} ${hh}:${min} 北京时间`,
  };
}

function zonedDateInfoFromUtcMs(utcMs, timeZone, suffix = "") {
  if (!Number.isFinite(utcMs)) return { date: "", time: "", label: "" };
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).formatToParts(new Date(utcMs));
  const map = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  const hour = map.hour === "24" ? "00" : map.hour;
  const date = `${map.year}-${map.month}-${map.day}`;
  const time = `${hour}:${map.minute}`;
  return {
    date,
    time,
    year: Number(map.year),
    month: Number(map.month),
    day: Number(map.day),
    hour: Number(hour),
    minute: Number(map.minute),
    label: `${date} ${time}${suffix ? ` ${suffix}` : ""}`,
  };
}

async function geocodeVenue(venue) {
  const cacheKey = `geo:${venue.id || venue.name || venue.city}`;
  return cached(cacheKey, 7 * 24 * 60 * 60 * 1000, async () => {
    const knownGeo = venueGeoFallback(venue);
    if (knownGeo) return knownGeo;

    const queryParts = [
      venue.name,
      venue.fifaName,
      cleanCity(venue.city),
      venue.country,
    ].filter(Boolean);
    const q = uniqueWords(queryParts.join(", "));
    const url = `${NOMINATIM_SEARCH}?format=json&limit=1&q=${encodeURIComponent(q)}`;
    const nominatim = await fetchJson(url, { headers: REQUEST_HEADERS, timeout: 12000 }).catch(() => []);

    if (Array.isArray(nominatim) && nominatim[0]?.lat && nominatim[0]?.lon) {
      return {
        lat: Number(nominatim[0].lat),
        lon: Number(nominatim[0].lon),
        label: nominatim[0].display_name,
        source: "OpenStreetMap Nominatim",
      };
    }

    const city = cleanCity(venue.city);
    const geoUrl = `${OPEN_METEO_GEOCODING}?name=${encodeURIComponent(city)}&count=1&language=en&format=json`;
    const meteoGeo = await fetchJson(geoUrl, { timeout: 12000 });
    const result = meteoGeo.results?.[0];
    if (result) {
      return {
        lat: Number(result.latitude),
        lon: Number(result.longitude),
        label: `${result.name}, ${result.country}`,
        source: "Open-Meteo Geocoding",
      };
    }

    return {
      lat: null,
      lon: null,
      label: "未能定位球场",
      source: "none",
    };
  });
}

function fallbackGeo(venue, error) {
  return {
    lat: null,
    lon: null,
    label: `${venue?.name || venue?.fifaName || venue?.city || "球场"}：离线定位不可用`,
    source: "local fallback",
    message: error?.message || "地理编码不可用",
  };
}

function venueGeoFallback(venue = {}) {
  const key = hostCityKey(venue);
  const geo = key ? HOST_CITY_GEO[key] : null;
  if (!geo) return null;
  return {
    lat: geo.lat,
    lon: geo.lon,
    label: geo.label,
    source: "host city verified fallback",
    cityKey: key,
  };
}

function hostCityKey(venue = {}) {
  const text = [venue.city, venue.city_en, venue.name, venue.name_en, venue.fifaName, venue.fifa_name, venue.label]
    .filter(Boolean)
    .join(" ");
  if (!text) return "";
  const normalized = normalizeTeamName(cleanCity(text));
  return Object.keys(HOST_CITY_GEO).find((city) => {
    const key = normalizeTeamName(city);
    return normalized.includes(key) || key.includes(normalized);
  }) || "";
}

function buildClimateWeatherFallback(geo, dateInfo, venue = {}, reason = "") {
  const key = hostCityKey(venue) || hostCityKey({ city: geo?.label || "" });
  const climate = key ? HOST_CITY_CLIMATE[key] : null;
  if (!climate || !dateInfo?.date) {
    return unavailable(reason || "缺少可核对的场馆城市天气数据");
  }

  return {
    available: true,
    estimated: true,
    status: "climate_fallback",
    message: reason || "实时逐小时天气暂未返回，已使用主办城市同期气候基线兜底",
    current: {
      time: `${dateInfo.date}T${String(dateInfo.hour || 0).padStart(2, "0")}:00`,
      temperature: climate.temperature,
      humidity: climate.humidity,
      precipitationProbability: climate.precipitationProbability,
      precipitation: null,
      weatherCode: null,
      windSpeed: climate.windSpeed,
      windGusts: null,
      condition: climate.condition,
    },
    daily: {
      maxTemperature: climate.temperature + 2,
      minTemperature: climate.temperature - 5,
      maxPrecipitationProbability: climate.precipitationProbability,
      maxWindSpeed: climate.windSpeed + 5,
    },
    timezone: "venue-local",
    source: `host-city climate fallback: ${key}`,
  };
}

function fallbackResearch(match, error) {
  return {
    refreshedAt: new Date().toISOString(),
    structured: {
      espn: { available: false, message: error?.message || "离线模式暂不可用" },
      sportsDb: { available: false, message: "离线模式暂不可用" },
      footballData: { available: false, message: "离线模式暂不可用" },
      fifa: { available: false, message: "离线模式暂不可用" },
      formGuide: {
        available: false,
        home: summarizeNormalizedEvents([]),
        away: summarizeNormalizedEvents([]),
        headToHead: summarizeHeadToHead([]),
      },
      lineupProjection: buildLineupProjection(match, {}, {
        homeInjuryScore: 0,
        awayInjuryScore: 0,
        lineupScore: 0,
        lineupEvidence: [],
        homeInjuryEvidence: [],
        awayInjuryEvidence: [],
      }),
    },
    searchGroups: [],
    crawled: [],
    directSources: { available: false, entries: [], message: "离线兜底未连接附加盘口源" },
    signals: {
      homeInjuryScore: 0,
      awayInjuryScore: 0,
      homeInjuryEvidence: [],
      awayInjuryEvidence: [],
      lineupScore: 0,
      lineupEvidence: [],
      oddsConsensus: {
        homeLean: 0,
        drawLean: 0,
        awayLean: 0,
        overLean: 0,
        underLean: 0,
        evidence: [],
      },
      venue: {
        roofScore: 0,
        naturalGrassScore: 0,
        turfScore: 0,
        evidence: [],
      },
      form: {
        available: false,
        home: summarizeNormalizedEvents([]),
        away: summarizeNormalizedEvents([]),
        headToHead: summarizeHeadToHead([]),
      },
      fifa: {},
      sourceCount: 0,
    },
    source: "local fallback",
    searchSource: `离线兜底：${match.home.displayName || match.home.name} 对 ${match.away.displayName || match.away.name}`,
  };
}

async function getWeather(geo, dateInfo, venue = {}) {
  if (!geo?.lat || !geo?.lon || !dateInfo?.date) {
    return buildClimateWeatherFallback(geo, dateInfo, venue, "缺少经纬度或比赛日期，已尝试使用场馆城市气候兜底");
  }

  const key = `weather:${geo.lat.toFixed(3)},${geo.lon.toFixed(3)}:${dateInfo.date}`;
  return cached(key, 30 * 60 * 1000, async () => {
    const params = new URLSearchParams({
      latitude: String(geo.lat),
      longitude: String(geo.lon),
      hourly: [
        "temperature_2m",
        "relative_humidity_2m",
        "precipitation_probability",
        "precipitation",
        "weather_code",
        "wind_speed_10m",
        "wind_gusts_10m",
      ].join(","),
      daily: [
        "temperature_2m_max",
        "temperature_2m_min",
        "precipitation_probability_max",
        "wind_speed_10m_max",
      ].join(","),
      timezone: "auto",
      start_date: dateInfo.date,
      end_date: dateInfo.date,
    });

    const url = `${OPEN_METEO_FORECAST}?${params.toString()}`;
    const json = await fetchJson(url, { timeout: 15000 }).catch((error) => {
      return {
        error: true,
        message: error.message,
      };
    });

    if (json.error || !json.hourly?.time?.length) {
      return {
        ...buildClimateWeatherFallback(geo, dateInfo, venue, "该日期逐小时天气暂不可用，已使用主办城市气候基线兜底"),
        source: url,
        forecastSource: url,
      };
    }

    const target = `${dateInfo.date}T${String(dateInfo.hour || 0).padStart(2, "0")}:00`;
    const idx = nearestHourIndex(json.hourly.time, target);
    const current = {
      time: json.hourly.time[idx],
      temperature: numberOrNull(json.hourly.temperature_2m?.[idx]),
      humidity: numberOrNull(json.hourly.relative_humidity_2m?.[idx]),
      precipitationProbability: numberOrNull(json.hourly.precipitation_probability?.[idx]),
      precipitation: numberOrNull(json.hourly.precipitation?.[idx]),
      weatherCode: numberOrNull(json.hourly.weather_code?.[idx]),
      windSpeed: numberOrNull(json.hourly.wind_speed_10m?.[idx]),
      windGusts: numberOrNull(json.hourly.wind_gusts_10m?.[idx]),
      condition: describeWeather(numberOrNull(json.hourly.weather_code?.[idx])),
    };

    return {
      available: true,
      status: "ok",
      current,
      daily: {
        maxTemperature: numberOrNull(json.daily?.temperature_2m_max?.[0]),
        minTemperature: numberOrNull(json.daily?.temperature_2m_min?.[0]),
        maxPrecipitationProbability: numberOrNull(json.daily?.precipitation_probability_max?.[0]),
        maxWindSpeed: numberOrNull(json.daily?.wind_speed_10m_max?.[0]),
      },
      units: json.hourly_units || {},
      timezone: json.timezone || "",
      source: url,
    };
  });
}

async function getElevation(geo) {
  if (!geo?.lat || !geo?.lon) {
    return unavailable("缺少经纬度");
  }

  const key = `elevation:${geo.lat.toFixed(4)},${geo.lon.toFixed(4)}`;
  return cached(key, 7 * 24 * 60 * 60 * 1000, async () => {
    const url = `${OPEN_METEO_ELEVATION}?latitude=${geo.lat}&longitude=${geo.lon}`;
    const json = await fetchJson(url, { timeout: 12000 });
    return {
      available: true,
      meters: numberOrNull(json.elevation?.[0]),
      source: url,
    };
  });
}

async function buildResearch(match, venue, options = {}) {
  const home = match.home.name;
  const away = match.away.name;
  const homeZh = teamLabel(match.home);
  const awayZh = teamLabel(match.away);
  const venueName = venue.name || venue.fifaName || venue.city;
  const queries = [
    {
      id: "intel-24h",
      label: "24小时赛事情报",
      side: "intel",
      freshHours: 24,
      q: `"${home}" "${away}" World Cup 2026 team news injuries odds tactical preview last 24 hours`,
      context: ["team news", "injury", "odds", "preview", "tactical", "world cup", "soccer"],
    },
    {
      id: "intel-cn-24h",
      label: "24小时中文情报/彩经",
      side: "intel",
      freshHours: 24,
      q: `"${homeZh}" "${awayZh}" 世界杯 24小时 情报 伤停 阵容 盘口 彩经 推荐`,
      context: ["情报", "伤停", "阵容", "盘口", "彩经", "推荐", "世界杯"],
    },
    {
      id: "match-preview",
      label: "赛前阵容/伤停",
      side: "match",
      q: `"${home}" "${away}" World Cup 2026 preview predicted lineup injuries suspension FIFA ESPN`,
      context: ["soccer", "football", "world cup", "fifa", "lineup", "injury", "team news", "preview", "espn"],
    },
    {
      id: "lineups-deep",
      label: "首发阵容预测站",
      side: "match",
      q: `"${home}" "${away}" predicted lineups starting XI formation World Cup 2026 FotMob SofaScore WhoScored`,
      context: ["predicted lineups", "starting xi", "formation", "fotmob", "sofascore", "whoscored", "lineup"],
    },
    {
      id: "tactical-preview",
      label: "战术预演/比赛走势",
      side: "match",
      q: `"${home}" "${away}" tactical preview formation pressing transition set pieces World Cup 2026`,
      context: ["tactical preview", "formation", "pressing", "transition", "set pieces", "match preview", "team news"],
    },
    {
      id: "injury-deep",
      label: "伤停/停赛交叉验证",
      side: "match",
      q: `"${home}" "${away}" injuries suspensions team news unavailable doubtful World Cup 2026 Transfermarkt`,
      context: ["injuries", "suspensions", "unavailable", "doubtful", "team news", "transfermarkt"],
    },
    {
      id: "home-team",
      label: `${home} 阵容伤停`,
      side: "home",
      q: `"${home}" national team World Cup 2026 squad injury suspension predicted lineup`,
      context: ["soccer", "football", "world cup", "fifa", "lineup", "injury", "squad", "team news"],
    },
    {
      id: "away-team",
      label: `${away} 阵容伤停`,
      side: "away",
      q: `"${away}" national team World Cup 2026 squad injury suspension predicted lineup`,
      context: ["soccer", "football", "world cup", "fifa", "lineup", "injury", "squad", "team news"],
    },
    {
      id: "odds-en",
      label: "盘口/赔率英文站",
      side: "odds",
      q: `"${home}" vs "${away}" odds prediction handicap over under World Cup 2026`,
      context: ["odds", "betting", "handicap", "prediction", "over", "under", "world cup", "soccer"],
    },
    {
      id: "odds-books",
      label: "赔率聚合/博彩公司",
      side: "odds",
      q: `"${home}" "${away}" OddsChecker Oddspedia DraftKings BetMGM FanDuel Pinnacle World Cup odds handicap total`,
      context: ["odds", "betting", "bookmaker", "draftkings", "betmgm", "fanduel", "oddspedia", "oddschecker", "pinnacle"],
    },
    {
      id: "odds-consensus",
      label: "盘口共识/大小球",
      side: "odds",
      q: `"${home}" "${away}" Asian handicap over under betting preview prediction World Cup 2026`,
      context: ["asian handicap", "over under", "betting preview", "prediction", "odds", "total"],
    },
    {
      id: "corners-market",
      label: "角球盘口/大小",
      side: "odds",
      q: `"${home}" "${away}" corners handicap corner over under betting props World Cup 2026`,
      context: ["corner", "corners", "corner handicap", "over corners", "under corners", "props", "odds", "betting"],
    },
    {
      id: "cards-market",
      label: "罚牌盘口/大小",
      side: "odds",
      q: `"${home}" "${away}" cards bookings yellow cards referee handicap over under betting props World Cup 2026`,
      context: ["cards", "card", "bookings", "yellow cards", "red cards", "referee", "handicap", "over", "under", "props", "odds", "betting"],
    },
    {
      id: "special-odds-cn",
      label: "角球/罚牌中文盘口",
      side: "odds",
      q: `"${homeZh}" "${awayZh}" 世界杯 角球 盘口 大小 让球 罚牌 黄牌 彩经 竞彩 推荐`,
      context: ["角球", "角球数", "罚牌", "黄牌", "红牌", "牌数", "盘口", "大小", "让球", "彩经", "竞彩", "推荐"],
    },
    {
      id: "corners-cn",
      label: "角球数/角球彩经",
      side: "odds",
      q: `"${homeZh}" "${awayZh}" 角球数 角球大小 角球让球 角球盘口 彩经 竞彩 足彩 推荐`,
      context: ["角球", "角球数", "角球大小", "角球让球", "角球盘口", "彩经", "竞彩", "足彩", "推荐"],
    },
    {
      id: "cards-cn",
      label: "红黄牌/罚牌彩经",
      side: "odds",
      q: `"${homeZh}" "${awayZh}" 罚牌 黄牌 红牌 牌数 裁判 罚牌大小 罚牌让球 彩经 推荐`,
      context: ["罚牌", "黄牌", "红牌", "红黄牌", "牌数", "裁判", "彩经", "竞彩", "足彩", "推荐"],
    },
    {
      id: "kaiyun-derivative-cn",
      label: "开云/Kaiyun角球罚牌",
      side: "odds",
      q: `"${homeZh}" "${awayZh}" 开云 kaiyun.com 雷速 leisu 角球 罚牌 黄牌 盘口 大小 让球 世界杯`,
      context: ["kaiyun", "开云", "leisu", "雷速", "角球", "罚牌", "黄牌", "盘口", "大小", "让球", "世界杯"],
    },
    {
      id: "leisu-derivative-cn",
      label: "雷速角球罚牌",
      side: "odds",
      q: `"${homeZh}" "${awayZh}" site:leisu.com 角球 罚牌 黄牌 盘口 大小 让球 指数`,
      context: ["leisu", "雷速", "角球", "罚牌", "黄牌", "盘口", "大小", "让球", "指数"],
    },
    {
      id: "pinnacle-corners-cards",
      label: "Pinnacle角球罚牌",
      side: "odds",
      q: `"${home}" "${away}" site:pinnacle.com total corners cards bookings odds World Cup`,
      context: ["pinnacle", "total corners", "corners", "cards", "bookings", "odds"],
    },
    {
      id: "fanduel-corners-cards",
      label: "FanDuel角球罚牌",
      side: "odds",
      q: `"${home}" "${away}" site:sportsbook.fanduel.com cards corners over under World Cup soccer odds`,
      context: ["fanduel", "cards", "corners", "over", "under", "odds"],
    },
    {
      id: "rotowire-corners-cards",
      label: "RotoWire角球罚牌",
      side: "odds",
      q: `"${home}" "${away}" site:rotowire.com betting soccer corner spread cards picks odds`,
      context: ["rotowire", "corner", "spread", "cards", "picks", "odds"],
    },
    {
      id: "oddschecker-corners-cards",
      label: "Oddschecker角球罚牌",
      side: "odds",
      q: `"${home}" "${away}" site:oddschecker.com corner cards over under odds World Cup`,
      context: ["oddschecker", "corner", "cards", "over", "under", "odds"],
    },
    {
      id: "oddspedia-corners-cards",
      label: "Oddspedia角球罚牌",
      side: "odds",
      q: `"${home}" "${away}" site:oddspedia.com soccer corners bookings cards odds World Cup`,
      context: ["oddspedia", "soccer", "corners", "bookings", "cards", "odds", "world cup"],
    },
    {
      id: "oddsportal-corners-cards",
      label: "OddsPortal角球罚牌",
      side: "odds",
      q: `"${home}" "${away}" site:oddsportal.com soccer corners cards bookings odds World Cup`,
      context: ["oddsportal", "corners", "cards", "bookings", "odds", "world cup"],
    },
    {
      id: "betexplorer-corners-cards",
      label: "BetExplorer角球罚牌",
      side: "odds",
      q: `"${home}" "${away}" site:betexplorer.com football odds corners cards bookings World Cup`,
      context: ["betexplorer", "football", "odds", "corners", "cards", "bookings"],
    },
    {
      id: "flashscore-corners-cards",
      label: "Flashscore角球罚牌",
      side: "odds",
      q: `"${home}" "${away}" site:flashscore.com match summary corners yellow cards World Cup`,
      context: ["flashscore", "match summary", "corners", "yellow cards", "cards"],
    },
    {
      id: "global-props-corners-cards",
      label: "全球附加盘口聚合",
      side: "odds",
      q: `"${home}" "${away}" BetBrain WinComparator Soccerway corner handicap yellow cards bookings odds`,
      context: ["betbrain", "wincomparator", "soccerway", "corner handicap", "yellow cards", "bookings", "odds"],
    },
    {
      id: "bookmaker-props-cn",
      label: "博彩公司附加盘中文源",
      side: "odds",
      q: `"${homeZh}" "${awayZh}" bet365 Pinnacle Oddspedia OddsPortal 开云 角球 罚牌 盘口 推荐`,
      context: ["bet365", "pinnacle", "oddspedia", "oddsportal", "开云", "角球", "罚牌", "盘口", "推荐"],
    },
    {
      id: "bookmaker-props-en",
      label: "博彩公司附加盘英文源",
      side: "odds",
      q: `"${home}" "${away}" bet365 Pinnacle Oddspedia OddsPortal Kaiyun total corners cards bookings odds props World Cup 2026`,
      context: ["bet365", "pinnacle", "oddspedia", "oddsportal", "kaiyun", "total corners", "cards", "bookings", "props", "odds"],
    },
    {
      id: "euro-books-derivative",
      label: "欧洲博彩公司附加盘",
      side: "odds",
      q: `"${home}" "${away}" Betfair Betway Unibet William Hill bwin Ladbrokes Coral corners cards bookings odds World Cup`,
      context: ["betfair", "betway", "unibet", "william hill", "bwin", "ladbrokes", "coral", "corners", "cards", "bookings", "odds"],
    },
    {
      id: "us-books-derivative",
      label: "北美博彩公司附加盘",
      side: "odds",
      q: `"${home}" "${away}" FanDuel BetMGM Caesars PointsBet DraftKings corner cards player props soccer World Cup`,
      context: ["fanduel", "betmgm", "caesars", "pointsbet", "draftkings", "corner", "cards", "props", "soccer"],
    },
    {
      id: "global-odds-aggregators",
      label: "全球赔率聚合横向核对",
      side: "odds",
      q: `"${home}" "${away}" Oddspedia OddsPortal OddsChecker BetExplorer WinComparator BetBrain Asian handicap totals odds`,
      context: ["oddspedia", "oddsportal", "oddschecker", "betexplorer", "wincomparator", "betbrain", "asian handicap", "totals", "odds"],
    },
    {
      id: "asia-cn-markets",
      label: "中文/亚洲盘口横向核对",
      side: "odds",
      q: `"${homeZh}" "${awayZh}" 澳客 即时指数 亚盘 欧赔 大小球 让球 角球 黄牌 世界杯 推荐`,
      context: ["澳客", "即时指数", "亚盘", "欧赔", "大小球", "让球", "角球", "黄牌", "世界杯", "推荐"],
    },
    {
      id: "stats-corners-cards",
      label: "角球/罚牌技术统计趋势",
      side: "odds",
      q: `"${home}" "${away}" FootyStats StatBunker SofaScore FotMob WhoScored corners yellow cards fouls referee World Cup`,
      context: ["footystats", "statbunker", "sofascore", "fotmob", "whoscored", "corners", "yellow cards", "fouls", "referee"],
    },
    {
      id: "global-betting-tips",
      label: "全球投注平台观点",
      side: "prediction",
      q: `"${home}" "${away}" BettingExpert FreeSuperTips MightyTips SportsGambler OLBG betting tips correct score over under`,
      context: ["bettingexpert", "freesupertips", "mightytips", "sportsgambler", "olbg", "betting tips", "correct score", "over under"],
    },
    {
      id: "caijing-cn",
      label: "彩经/竞彩推荐",
      side: "odds",
      q: `"${homeZh}" "${awayZh}" 彩经 竞彩 足彩 赛事推荐 盘口分析 大小球 让球 世界杯`,
      context: ["彩经", "竞彩", "足彩", "赛事推荐", "盘口分析", "大小球", "让球", "世界杯", "推荐"],
    },
    {
      id: "prediction-sites",
      label: "赛前预测站",
      side: "odds",
      q: `"${home}" "${away}" Sports Mole prediction team news Forebet PredictZ World Cup 2026`,
      context: ["prediction", "team news", "preview", "sports mole", "forebet", "predictz", "world cup", "soccer"],
    },
    {
      id: "prediction-correct-score-en",
      label: "英文正确比分预测",
      side: "prediction",
      q: `"${home}" "${away}" correct score prediction betting tips SportsMole Forebet PredictZ WinDrawWin BetClan World Cup 2026`,
      context: ["correct score", "score prediction", "predicted score", "betting tips", "sports mole", "forebet", "predictz", "windrawwin", "betclan"],
    },
    {
      id: "prediction-consensus-en",
      label: "英文比分观点聚合",
      side: "prediction",
      q: `"${home}" vs "${away}" score prediction preview picks betting tips World Cup 2026 Sportskeeda Standard Evening Sports Mole`,
      context: ["score prediction", "preview", "picks", "betting tips", "world cup", "sportskeeda", "sports mole"],
    },
    {
      id: "prediction-cn-score",
      label: "中文比分/竞彩推荐",
      side: "prediction",
      q: `"${homeZh}" "${awayZh}" 比分推荐 比分预测 竞彩 彩经 足彩 胜平负 让球 世界杯`,
      context: ["比分推荐", "比分预测", "竞彩", "彩经", "足彩", "胜平负", "让球", "世界杯", "推荐"],
    },
    {
      id: "global-tips-score",
      label: "全球比分推荐汇总",
      side: "prediction",
      q: `"${home}" "${away}" BetClan WinDrawWin Forebet PredictZ CorrectScore FootballPredictions score prediction odds tips`,
      context: ["betclan", "windrawwin", "forebet", "predictz", "correctscore", "footballpredictions", "score prediction", "tips"],
    },
    {
      id: "form-h2h",
      label: "近况/历史交锋",
      side: "match",
      q: `"${home}" "${away}" head to head recent form last 10 matches soccerway 11v11 world cup`,
      context: ["head to head", "recent form", "last 10", "soccerway", "11v11", "h2h"],
    },
    {
      id: "odds-cn",
      label: "盘口/推荐中文站",
      side: "odds",
      q: `"${homeZh}" "${awayZh}" 世界杯 盘口 推荐 比分 预测 赔率`,
      context: ["盘口", "赔率", "推荐", "预测", "世界杯", "odds", "prediction", "betting"],
    },
    {
      id: "venue",
      label: "球场情况",
      side: "venue",
      q: `"${venueName}" World Cup 2026 stadium roof pitch surface weather altitude`,
      context: ["stadium", "pitch", "surface", "roof", "world cup", "fifa", "venue"],
    },
  ];

  const structured = await buildStructuredContext(match, { quick: options.quick });
  if (options.quick) {
    const directSources = options.quickDerivative
      ? await fetchPinnacleDerivativeContext(match).catch((error) => ({
          available: false,
          source: "Pinnacle World Cup direct",
          domain: "guest.api.arcadia.pinnacle.com",
          entries: [],
          message: `Pinnacle direct failed: ${error.message}`,
        }))
      : { available: false, entries: [], message: "quick mode skipped derivative markets" };
    const signals = extractResearchSignals({ match, searchGroups: [], crawled: [], structured, directSources });
    structured.lineupProjection = buildLineupProjection(match, structured, signals);
    return {
      refreshedAt: new Date().toISOString(),
      structured,
      searchGroups: [],
      crawled: [],
      directSources,
      signals,
      source: "quick-validation",
      searchSource: "结构化数据验证模式",
    };
  }

  const directSourcesPromise = fetchPinnacleDerivativeContext(match).catch((error) => ({
    available: false,
    source: "Pinnacle World Cup direct",
    domain: "guest.api.arcadia.pinnacle.com",
    entries: [],
    message: `Pinnacle 直连失败：${error.message}`,
  }));

  const activeQueries = selectResearchQueries(queries, options);
  const searchGroups = await mapLimit(
    activeQueries,
    Number(process.env.RESEARCH_SEARCH_CONCURRENCY || 6),
    async (query) => {
      const rawResults = await searchWeb(query.q, query.limit || 8).catch(() => []);
      return {
        ...query,
        results: filterRelevantResults(rawResults, query, match, venue).slice(0, 8),
        rawCount: rawResults.length,
      };
    }
  );

  const crawlTargets = searchGroups
    .flatMap((group) =>
      group.results.map((result) => ({
        ...result,
        side: group.side,
        groupLabel: group.label,
      }))
    )
    .filter((result) => result.url && isCrawlable(result.url))
    .slice(0, options.depth === "deep" ? 42 : Math.max(DEFAULT_RESEARCH_CRAWL_LIMIT + 8, 20));

  const [crawled, directSources] = await Promise.all([
    crawlPages(crawlTargets, options.depth === "deep" ? 26 : DEFAULT_RESEARCH_CRAWL_LIMIT),
    directSourcesPromise,
  ]);
  const resolvedDirectSources = directSources && typeof directSources === "object"
    ? directSources
    : { available: false, entries: [], message: "附加盘口直连未返回状态" };
  const signals = extractResearchSignals({ match, searchGroups, crawled, structured, directSources: resolvedDirectSources });
  const webDerivativeSnapshot = buildDerivativeSnapshotFromSignals(match, signals);
  if (webDerivativeSnapshot.entries.length) {
    saveDerivativeMarketSnapshot(match, webDerivativeSnapshot, { source: "全网盘口爬取缓存" });
  }
  structured.lineupProjection = buildLineupProjection(match, structured, signals);

  return {
    refreshedAt: new Date().toISOString(),
    structured,
    searchGroups,
    crawled,
    directSources: resolvedDirectSources,
    signals,
    source: DDG_HTML,
    searchSource: "Bing Search with DuckDuckGo fallback + Pinnacle World Cup direct",
  };
}

function selectResearchQueries(queries, options = {}) {
  if (options.depth === "deep" || process.env.RESEARCH_DEPTH === "deep") return queries;
  const highValueIds = [
    "intel-24h",
    "intel-cn-24h",
    "match-preview",
    "tactical-preview",
    "injury-deep",
    "prediction-correct-score-en",
    "prediction-cn-score",
    "prediction-consensus-en",
    "prediction-sites",
    "global-tips-score",
    "odds-books",
    "odds-consensus",
    "corners-market",
    "cards-market",
    "special-odds-cn",
    "kaiyun-derivative-cn",
    "leisu-derivative-cn",
    "global-odds-aggregators",
    "euro-books-derivative",
    "us-books-derivative",
    "asia-cn-markets",
    "stats-corners-cards",
    "global-betting-tips",
    "caijing-cn",
    "form-h2h",
    "venue",
  ];
  const byId = new Map(queries.map((query) => [query.id, query]));
  const selected = highValueIds.map((id) => byId.get(id)).filter(Boolean);
  const max = clamp(Number(process.env.RESEARCH_QUERY_LIMIT || DEFAULT_RESEARCH_QUERY_LIMIT), 8, queries.length);
  return selected.slice(0, max);
}

async function buildStructuredContext(match, options = {}) {
  if (options.quick) {
    const [espn, fifa] = await Promise.all([
      withTimeout(
        getEspnContext(match, { preferCache: true }),
        3000,
        { available: false, message: "快速模式 ESPN 结构化数据超时，深度分析补齐" }
      ).catch((error) => ({
        available: false,
        message: error.message,
      })),
      withTimeout(
        getFifaRankingContext(match, { preferLocal: true }),
        1800,
        { available: false, message: "快速模式 FIFA 排名读取超时，深度分析补齐" }
      ).catch((error) => ({
        available: false,
        message: error.message,
      })),
    ]);
    const sportsDb = { available: false, message: "快速模式跳过 TheSportsDB" };
    const footballData = { available: false, message: "快速模式跳过 football-data.org 名单接口" };
    const formGuide = buildQuickFormGuide(match, espn);
    return { espn, sportsDb, footballData, fifa, formGuide };
  }

  const [espn, sportsDb, footballData, fifa] = await Promise.all([
    getEspnContext(match).catch((error) => ({
      available: false,
      message: error.message,
    })),
    getSportsDbContext(match).catch((error) => ({
      available: false,
      message: error.message,
    })),
    getFootballDataContext(match).catch((error) => ({
      available: false,
      message: error.message,
    })),
    getFifaRankingContext(match).catch((error) => ({
      available: false,
      message: error.message,
    })),
  ]);
  const formGuide = await buildFormGuide(match, { espn, sportsDb, footballData }).catch((error) => ({
    available: false,
    message: error.message,
  }));
  return { espn, sportsDb, footballData, fifa, formGuide };
}

async function getFootballDataContext(match) {
  const data = await getFootballDataWorldCup();
  if (!data.available) return data;
  const homeTeam = findFootballDataTeam(data.teams, match.home.footballDataId || match.home.id, match.home.name);
  const awayTeam = findFootballDataTeam(data.teams, match.away.footballDataId || match.away.id, match.away.name);
  const fdMatch = data.matches.find((item) => String(item.id) === String(match.sourceIds?.footballData || match.footballData?.id || match.id));
  return {
    available: true,
    source: data.source,
    match: fdMatch
      ? {
          id: fdMatch.id,
          utcDate: fdMatch.utcDate,
          status: fdMatch.status,
          stage: fdMatch.stage,
          group: fdMatch.group,
          lastUpdated: fdMatch.lastUpdated,
          oddsMessage: fdMatch.odds?.msg || "",
        }
      : null,
    teams: {
      home: compactFootballDataTeam(homeTeam),
      away: compactFootballDataTeam(awayTeam),
    },
  };
}

function compactFootballDataTeam(team) {
  if (!team) return null;
  const squad = arrayFrom(team.squad);
  const byPosition = squad.reduce((acc, player) => {
    const key = player.position || "Unknown";
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
  return {
    id: team.id,
    name: team.name,
    shortName: team.shortName,
    code: team.tla,
    crest: team.crest,
    coach: team.coach?.name || "",
    lastUpdated: team.lastUpdated,
    squadCount: squad.length,
    byPosition,
    squad: squad.map((player) => ({
      id: player.id,
      name: player.name,
      position: player.position,
      dateOfBirth: player.dateOfBirth,
      nationality: player.nationality,
    })),
  };
}

async function getFifaRankingContext(match, options = {}) {
  let rankings = options.preferLocal ? getLocalFifaRankings() : await getFifaRankings();
  let home = findFifaRanking(rankings, match.home);
  let away = findFifaRanking(rankings, match.away);
  let sourceMode = options.preferLocal ? "local snapshot" : "official FIFA API";

  if (options.preferLocal && (!home?.rank || !away?.rank || fifaRankingsAreStale(home, away))) {
    const liveRankings = await getFifaRankings().catch(() => []);
    const liveHome = findFifaRanking(liveRankings, match.home);
    const liveAway = findFifaRanking(liveRankings, match.away);
    if (liveHome?.rank || liveAway?.rank) {
      rankings = liveRankings;
      home = liveHome || home;
      away = liveAway || away;
      sourceMode = "official FIFA API";
    }
  }

  const stale = fifaRankingsAreStale(home, away);
  if (stale && sourceMode === "official FIFA API") {
    sourceMode = "ranking snapshot fallback";
  }

  return {
    available: Boolean(home || away),
    source: `${FIFA_RANKINGS_API}?gender=1&count=211`,
    sourceMode,
    publishedAt: home?.publishedAt || away?.publishedAt || "",
    validation: {
      checked: true,
      ok: Boolean(home?.rank && away?.rank),
      fresh: !stale,
      message: home?.rank && away?.rank
        ? stale
          ? "FIFA 排名已匹配双方国家队代码，但发布日期较旧，需等待官方接口刷新"
          : "FIFA 排名已匹配双方国家队代码"
        : "FIFA 排名未完整匹配，已保留可用一侧",
    },
    teams: {
      home,
      away,
    },
  };
}

function fifaRankingsAreStale(home, away) {
  const published = home?.publishedAt || away?.publishedAt || "";
  const publishedMs = Date.parse(published);
  if (!Number.isFinite(publishedMs)) return true;
  return Date.now() - publishedMs > 45 * 24 * 60 * 60 * 1000;
}

function getLocalFifaRankings() {
  const localPath = new URL("data/fifa-rankings.json", import.meta.url);
  if (!existsSync(localPath)) return [];
  const json = JSON.parse(readFileSync(localPath, "utf8"));
  return normalizeFifaRankingsJson(json);
}

async function getFifaRankings() {
  return cached("fifa-rankings-men", 24 * 60 * 60 * 1000, async () => {
    const json = await fetchJson(`${FIFA_RANKINGS_API}?gender=1&count=211`, {
      headers: {
        ...REQUEST_HEADERS,
        Accept: "application/json,text/plain,*/*",
      },
      timeout: 18000,
      preferPowerShell: true,
    }).catch((error) => {
      const localPath = new URL("data/fifa-rankings.json", import.meta.url);
      if (!existsSync(localPath)) throw error;
      return JSON.parse(readFileSync(localPath, "utf8"));
    });
    return normalizeFifaRankingsJson(json);
  });
}

function normalizeFifaRankingsJson(json) {
  return arrayFrom(json.Results).map((row) => {
    const name = arrayFrom(row.TeamName).find((item) => item.Locale === "en-GB")?.Description ||
      arrayFrom(row.TeamName)[0]?.Description ||
      "";
    return {
      name,
      code: row.IdCountry,
      rank: numberOrNull(row.Rank),
      previousRank: numberOrNull(row.PrevRank),
      points: numberOrNull(row.DecimalTotalPoints ?? row.TotalPoints),
      confederation: row.ConfederationName || "",
      publishedAt: row.PubDate || "",
    };
  });
}

function findFifaRanking(rankings, team) {
  const code = normalizeCountryCode(team?.code);
  if (code) {
    const byCode = rankings.find((row) => normalizeCountryCode(row.code) === code);
    if (byCode) return byCode;
  }
  const keys = teamLookupKeys(team?.name);
  return rankings.find((row) => {
    const rowKeys = teamLookupKeys(row.name);
    return rowKeys.some((key) => keys.includes(key));
  }) || null;
}

async function buildFormGuide(match, structured) {
  const footballData = structured.footballData;
  const window = recentFormDateWindow(match);
  const [homeFootballEvents, awayFootballEvents] = await Promise.all([
    getFootballDataRecentMatches(footballData?.teams?.home?.id || match.home.footballDataId, match.home.name, window).catch(() => []),
    getFootballDataRecentMatches(footballData?.teams?.away?.id || match.away.footballDataId, match.away.name, window).catch(() => []),
  ]);

  const homeEvents = mergeRecentEvents([
    ...normalizeEspnRecentEvents(structured.espn?.form?.home?.events, match.home.name),
    ...homeFootballEvents,
    ...normalizeSportsDbRecentEvents(structured.sportsDb?.recentEvents?.home, match.home.name),
  ]);
  const awayEvents = mergeRecentEvents([
    ...normalizeEspnRecentEvents(structured.espn?.form?.away?.events, match.away.name),
    ...awayFootballEvents,
    ...normalizeSportsDbRecentEvents(structured.sportsDb?.recentEvents?.away, match.away.name),
  ]);
  const headToHeadEvents = buildHeadToHeadEvents(match, homeEvents, awayEvents);

  return {
    available: Boolean(homeEvents.length || awayEvents.length || headToHeadEvents.length),
    window,
    sources: [
      homeFootballEvents.length || awayFootballEvents.length ? "football-data.org team matches" : "",
      structured.espn?.form?.home?.events?.length || structured.espn?.form?.away?.events?.length ? "ESPN form" : "",
      structured.sportsDb?.recentEvents?.home?.length || structured.sportsDb?.recentEvents?.away?.length ? "TheSportsDB last events" : "",
    ].filter(Boolean),
    home: summarizeNormalizedEvents(homeEvents),
    away: summarizeNormalizedEvents(awayEvents),
    headToHead: summarizeHeadToHead(headToHeadEvents),
  };
}

function buildQuickFormGuide(match, espn) {
  const homeEvents = mergeRecentEvents([
    ...normalizeEspnRecentEvents(espn?.form?.home?.events, match.home.name),
  ]);
  const awayEvents = mergeRecentEvents([
    ...normalizeEspnRecentEvents(espn?.form?.away?.events, match.away.name),
  ]);
  const headToHeadEvents = buildHeadToHeadEvents(match, homeEvents, awayEvents);

  return {
    available: Boolean(homeEvents.length || awayEvents.length || headToHeadEvents.length),
    window: recentFormDateWindow(match),
    sources: homeEvents.length || awayEvents.length ? ["ESPN 本地缓存近况"] : [],
    home: summarizeNormalizedEvents(homeEvents),
    away: summarizeNormalizedEvents(awayEvents),
    headToHead: summarizeHeadToHead(headToHeadEvents),
  };
}

function buildLineupProjection(match, structured = {}, signals = {}) {
  const footballData = structured.footballData || {};
  const homeTeam = footballData.teams?.home || null;
  const awayTeam = footballData.teams?.away || null;
  const home = projectTeamLineup({
    side: "home",
    team: match.home,
    official: homeTeam,
    injuryScore: signals.homeInjuryScore,
    injuryEvidence: signals.homeInjuryEvidence,
    lineupEvidence: signals.lineupEvidence,
  });
  const away = projectTeamLineup({
    side: "away",
    team: match.away,
    official: awayTeam,
    injuryScore: signals.awayInjuryScore,
    injuryEvidence: signals.awayInjuryEvidence,
    lineupEvidence: signals.lineupEvidence,
  });

  return {
    available: home.available || away.available || Boolean(signals.lineupScore),
    source: footballData.available ? "football-data.org 官方名单 + 网页阵容信号" : "网页阵容信号 + 本地赛程",
    confidence: lineupConfidence({ home, away, signals, footballData }),
    updatedAt: new Date().toISOString(),
    home,
    away,
    comparison: {
      injuryEdge: Number(((signals.awayInjuryScore || 0) - (signals.homeInjuryScore || 0)).toFixed(2)),
      lineupSignal: signals.lineupScore || 0,
      evidenceCount:
        arrayFrom(signals.lineupEvidence).length +
        arrayFrom(signals.homeInjuryEvidence).length +
        arrayFrom(signals.awayInjuryEvidence).length,
    },
  };
}

function projectTeamLineup({ side, team, official, injuryScore = 0, injuryEvidence = [], lineupEvidence = [] }) {
  const squad = arrayFrom(official?.squad);
  const groups = groupSquadByRole(squad);
  const shape = chooseFormation(groups);
  const predictedXI = buildPredictedXI(groups, shape);
  const benchCandidates = buildBenchCandidates(squad, predictedXI);
  const evidence = [...arrayFrom(lineupEvidence), ...arrayFrom(injuryEvidence)]
    .filter((item) => !item.side || item.side === side || item.side === "match")
    .slice(0, 4);

  return {
    available: Boolean(squad.length || evidence.length),
    team: teamLabel(team),
    code: team?.code || "",
    coach: official?.coach || team?.coach || "",
    formation: shape.label,
    formationReason: shape.reason,
    squadCount: official?.squadCount ?? team?.squadCount ?? squad.length,
    predictedXI,
    benchCandidates,
    injuryRisk: injuryRiskLabel(injuryScore),
    injuryScore: Number(injuryScore || 0),
    evidence,
    source: squad.length ? "官方名单推演" : "等待官方名单，先用网页信号",
  };
}

function groupSquadByRole(squad) {
  const groups = {
    goalkeeper: [],
    defender: [],
    midfielder: [],
    forward: [],
    unknown: [],
  };
  for (const player of arrayFrom(squad)) {
    const role = normalizePlayerRole(player.position);
    groups[role].push({
      id: player.id,
      name: player.name,
      position: player.position || roleLabel(role),
      positionZh: playerPositionLabel(player.position || role),
      role,
    });
  }
  return groups;
}

function normalizePlayerRole(position) {
  const value = String(position || "").toLowerCase();
  if (/goal|keeper|gk/.test(value)) return "goalkeeper";
  if (/def|back|centre-back|center-back|full-back|cb|lb|rb/.test(value)) return "defender";
  if (/mid|winger|wing|dm|cm|am/.test(value)) return "midfielder";
  if (/forward|striker|attack|fw|st/.test(value)) return "forward";
  return "unknown";
}

function chooseFormation(groups) {
  const defenders = groups.defender.length;
  const midfielders = groups.midfielder.length;
  const forwards = groups.forward.length;
  if (defenders >= 5 && midfielders >= 3 && forwards >= 2) {
    return { label: "4-3-3", slots: { goalkeeper: 1, defender: 4, midfielder: 3, forward: 3 }, reason: "名单前场储备较足，默认使用进攻均衡结构" };
  }
  if (defenders >= 5 && midfielders >= 5) {
    return { label: "4-2-3-1", slots: { goalkeeper: 1, defender: 4, midfielder: 5, forward: 1 }, reason: "中场人数充足，优先稳控节奏" };
  }
  if (defenders >= 5 && midfielders >= 4 && forwards >= 2) {
    return { label: "3-5-2", slots: { goalkeeper: 1, defender: 3, midfielder: 5, forward: 2 }, reason: "边翼卫/中场储备较多，适合三中卫框架" };
  }
  return { label: "4-3-3", slots: { goalkeeper: 1, defender: 4, midfielder: 3, forward: 3 }, reason: "官方首发未公布，按国家队常见阵型生成候选首发" };
}

function buildPredictedXI(groups, shape) {
  const used = new Set();
  const picks = [];
  for (const role of ["goalkeeper", "defender", "midfielder", "forward"]) {
    const count = shape.slots[role] || 0;
    for (const player of groups[role].slice(0, count)) {
      used.add(player.id || player.name);
      picks.push({ ...player, slot: roleLabel(role) });
    }
  }

  const missing = 11 - picks.length;
  if (missing > 0) {
    const pool = [...groups.unknown, ...groups.midfielder, ...groups.defender, ...groups.forward]
      .filter((player) => !used.has(player.id || player.name));
    for (const player of pool.slice(0, missing)) {
      used.add(player.id || player.name);
      picks.push({ ...player, slot: player.positionZh || playerPositionLabel(player.position) || "候选" });
    }
  }

  while (picks.length < 11) {
    picks.push({
      id: `pending-${picks.length}`,
      name: "待确认",
      position: "官方名单未公布",
      role: "unknown",
      slot: "待确认",
    });
  }

  return picks.slice(0, 11);
}

function buildBenchCandidates(squad, predictedXI) {
  const used = new Set(predictedXI.map((player) => player.id || player.name));
  return arrayFrom(squad)
    .filter((player) => !used.has(player.id || player.name))
    .slice(0, 7)
    .map((player) => ({
      id: player.id,
      name: player.name,
      position: player.position || "替补候选",
      positionZh: playerPositionLabel(player.position || "替补候选"),
    }));
}

function playerPositionLabel(position) {
  const value = String(position || "").toLowerCase();
  if (/goalkeeper|keeper|gk|goal/.test(value)) return "门将";
  if (/left[-\s]?back|lb/.test(value)) return "左后卫";
  if (/right[-\s]?back|rb/.test(value)) return "右后卫";
  if (/centre[-\s]?back|center[-\s]?back|central defender|cb/.test(value)) return "中后卫";
  if (/full[-\s]?back|wing[-\s]?back/.test(value)) return "边后卫";
  if (/defender|defence|defense|back/.test(value)) return "后卫";
  if (/defensive midfield|holding midfield|dm/.test(value)) return "防守型中场";
  if (/attacking midfield|am/.test(value)) return "攻击型中场";
  if (/central midfield|centre midfield|center midfield|cm/.test(value)) return "中前卫";
  if (/midfielder|midfield/.test(value)) return "中场";
  if (/left winger|left wing|lw/.test(value)) return "左边锋";
  if (/right winger|right wing|rw/.test(value)) return "右边锋";
  if (/winger|wing/.test(value)) return "边锋";
  if (/centre[-\s]?forward|center[-\s]?forward|striker|forward|attack|fw|st/.test(value)) return "前锋";
  if (/substitute|bench|替补/.test(value)) return "替补候选";
  return roleLabel(normalizePlayerRole(position));
}

function roleLabel(role) {
  const labels = {
    goalkeeper: "门将",
    defender: "后卫",
    midfielder: "中场",
    forward: "前锋",
    unknown: "候选",
  };
  return labels[role] || "候选";
}

function injuryRiskLabel(score) {
  const value = Number(score || 0);
  if (value >= 5) return "高";
  if (value >= 2.5) return "中";
  if (value > 0) return "低";
  return "未见明显信号";
}

function lineupConfidence({ home, away, signals, footballData }) {
  let score = 35;
  if (footballData?.available) score += 30;
  if (home.predictedXI?.some((player) => player.name !== "待确认")) score += 10;
  if (away.predictedXI?.some((player) => player.name !== "待确认")) score += 10;
  score += Math.min(15, (signals.lineupScore || 0) * 2);
  const clamped = Math.round(clamp(score, 20, 88));
  return {
    score: clamped,
    label: clamped >= 75 ? "较高" : clamped >= 55 ? "中" : "偏低",
  };
}

async function getFootballDataRecentMatches(teamId, teamName, window) {
  const key = String(process.env.FOOTBALL_DATA_API_KEY || process.env.FOOTBALL_DATA_TOKEN || "").trim();
  if (!key || !teamId) return [];
  const cacheKey = `football-data-recent-${teamId}-${window.dateFrom}-${window.dateTo}`;
  return cached(cacheKey, 30 * 60 * 1000, async () => {
    const params = new URLSearchParams({
      status: "FINISHED",
      limit: "50",
      dateFrom: window.dateFrom,
      dateTo: window.dateTo,
    });
    const json = await fetchJson(`${FOOTBALL_DATA_API}/teams/${encodeURIComponent(teamId)}/matches?${params.toString()}`, {
      headers: { "X-Auth-Token": key },
      timeout: 18000,
    });
    return arrayFrom(json.matches)
      .map((event) => normalizeFootballDataRecentEvent(event, teamId, teamName))
      .filter(Boolean)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 10);
  });
}

function normalizeFootballDataRecentEvent(event, teamId, teamName) {
  const homeScore = numberOrNull(event.score?.fullTime?.home);
  const awayScore = numberOrNull(event.score?.fullTime?.away);
  if (!Number.isFinite(homeScore) || !Number.isFinite(awayScore)) return null;
  const isHome =
    String(event.homeTeam?.id) === String(teamId) ||
    normalizeTeamName(event.homeTeam?.name) === normalizeTeamName(teamName);
  const opponent = isHome ? event.awayTeam?.name : event.homeTeam?.name;
  return normalizeRecentEvent({
    date: event.utcDate,
    team: teamName,
    opponent,
    gf: isHome ? homeScore : awayScore,
    ga: isHome ? awayScore : homeScore,
    competition: event.competition?.name || event.stage || "",
    source: "football-data.org",
  });
}

function normalizeEspnRecentEvents(events, teamName) {
  return arrayFrom(events)
    .map((event) => {
      const homeScore = numberOrNull(event.homeScore);
      const awayScore = numberOrNull(event.awayScore);
      if (!Number.isFinite(homeScore) || !Number.isFinite(awayScore)) return null;
      return normalizeRecentEvent({
        date: event.date,
        team: teamName,
        opponent: event.opponent,
        gf: event.isHome ? homeScore : awayScore,
        ga: event.isHome ? awayScore : homeScore,
        competition: event.competition,
        source: "ESPN",
      });
    })
    .filter(Boolean);
}

function normalizeSportsDbRecentEvents(events, teamName) {
  const teamKeys = teamLookupKeys(teamName);
  return arrayFrom(events)
    .map((event) => {
      const homeScore = numberOrNull(event.homeScore);
      const awayScore = numberOrNull(event.awayScore);
      if (!Number.isFinite(homeScore) || !Number.isFinite(awayScore)) return null;
      const isHome = teamLookupKeys(event.homeTeam).some((key) => teamKeys.includes(key));
      const opponent = isHome ? event.awayTeam : event.homeTeam;
      return normalizeRecentEvent({
        date: event.date,
        team: teamName,
        opponent,
        gf: isHome ? homeScore : awayScore,
        ga: isHome ? awayScore : homeScore,
        competition: event.competition,
        source: event.source || "TheSportsDB",
      });
    })
    .filter(Boolean);
}

function normalizeRecentEvent(event) {
  const gf = numberOrNull(event.gf);
  const ga = numberOrNull(event.ga);
  if (!Number.isFinite(gf) || !Number.isFinite(ga)) return null;
  return {
    date: event.date || "",
    team: event.team || "",
    opponent: event.opponent || "",
    gf,
    ga,
    score: `${gf}-${ga}`,
    result: gf > ga ? "W" : gf === ga ? "D" : "L",
    competition: event.competition || "",
    source: event.source || "",
  };
}

function mergeRecentEvents(events) {
  const seen = new Set();
  return arrayFrom(events)
    .filter(Boolean)
    .sort((a, b) => sourcePriority(b.source) - sourcePriority(a.source))
    .filter((event) => {
      const key = [
        String(event.date || "").slice(0, 10),
        normalizeTeamName(event.opponent),
        event.gf,
        event.ga,
      ].join("|");
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 10);
}

function sourcePriority(source) {
  if (/football-data/i.test(source)) return 3;
  if (/espn/i.test(source)) return 2;
  if (/thesportsdb/i.test(source)) return 1;
  return 0;
}

function summarizeNormalizedEvents(events) {
  const clean = arrayFrom(events).filter((event) => Number.isFinite(event.gf) && Number.isFinite(event.ga));
  let points = 0;
  let wins = 0;
  let draws = 0;
  let losses = 0;
  let goalsFor = 0;
  let goalsAgainst = 0;
  for (const event of clean) {
    goalsFor += event.gf;
    goalsAgainst += event.ga;
    if (event.gf > event.ga) {
      wins += 1;
      points += 3;
    } else if (event.gf === event.ga) {
      draws += 1;
      points += 1;
    } else {
      losses += 1;
    }
  }
  const counted = clean.length;
  return {
    events: clean,
    matches: counted,
    wins,
    draws,
    losses,
    pointsPerGame: counted ? Number((points / counted).toFixed(2)) : null,
    goalsForPerGame: counted ? Number((goalsFor / counted).toFixed(2)) : null,
    goalsAgainstPerGame: counted ? Number((goalsAgainst / counted).toFixed(2)) : null,
    goalDiffPerGame: counted ? Number(((goalsFor - goalsAgainst) / counted).toFixed(2)) : null,
  };
}

function buildHeadToHeadEvents(match, homeEvents, awayEvents) {
  const awayKeys = teamLookupKeys(match.away.name);
  const homeKeys = teamLookupKeys(match.home.name);
  const fromHome = arrayFrom(homeEvents).filter((event) =>
    teamLookupKeys(event.opponent).some((key) => awayKeys.includes(key))
  );
  const fromAway = arrayFrom(awayEvents)
    .filter((event) => teamLookupKeys(event.opponent).some((key) => homeKeys.includes(key)))
    .map((event) =>
      normalizeRecentEvent({
        ...event,
        team: match.home.name,
        opponent: match.away.name,
        gf: event.ga,
        ga: event.gf,
      })
    );
  return mergeRecentEvents([...fromHome, ...fromAway]);
}

function summarizeHeadToHead(events) {
  const summary = summarizeNormalizedEvents(events);
  return {
    ...summary,
    sample: summary.matches,
  };
}

function recentFormDateWindow(match) {
  const now = new Date();
  const matchDateMs = Date.parse(match.dateInfo?.date || "");
  const end = Number.isFinite(matchDateMs) && matchDateMs < now.getTime()
    ? new Date(matchDateMs - 24 * 60 * 60 * 1000)
    : now;
  const start = new Date(end.getTime() - 720 * 24 * 60 * 60 * 1000);
  return {
    dateFrom: toDateOnly(start),
    dateTo: toDateOnly(end),
  };
}

function toDateOnly(date) {
  return date.toISOString().slice(0, 10);
}

async function getEspnContext(match, options = {}) {
  const dateKeys = espnScoreboardDateKeys(match);
  const date = dateKeys[0] || "";
  if (!date) return { available: false, message: "缺少 ESPN 查询日期" };
  const scoreboardUrl = `${ESPN_SCOREBOARD}?dates=${date}`;
  const cachedEvent = findCachedEspnEvent(match, date);

  if (options.preferCache && cachedEvent && !match?.finished) {
    return buildEspnContextFromEvent({
      event: cachedEvent.event,
      provider: cachedEvent.event.provider,
      match,
      summary: cachedEvent.event.summary,
      scoreboardUrl: cachedEvent.scoreboardUrl || scoreboardUrl,
      summaryUrl: cachedEvent.event.summaryUrl || `${ESPN_SUMMARY}?event=${cachedEvent.event.id}`,
      mode: "本地 ESPN 缓存",
      warning: "快速模式优先使用本地赛程缓存，深度分析会继续刷新实时源。",
      cacheFetchedAt: cachedEvent.cacheFetchedAt,
    });
  }

  try {
    for (const dateKey of dateKeys) {
      const candidateUrl = `${ESPN_SCOREBOARD}?dates=${dateKey}`;
      const board = await fetchJson(candidateUrl, { timeout: 15000 });
      const event = findEspnEvent(board.events || [], match);
      if (!event) continue;
      const summaryUrl = `${ESPN_SUMMARY}?event=${event.id}`;
      const summary = await fetchJson(summaryUrl, { timeout: 15000 }).catch(() => null);
      return buildEspnContextFromEvent({
        event,
        provider: board.provider,
        match,
        summary,
        scoreboardUrl: candidateUrl,
        summaryUrl,
        mode: "实时 ESPN",
      });
    }
  } catch (error) {
    if (cachedEvent) {
      return buildEspnContextFromEvent({
        event: cachedEvent.event,
        provider: cachedEvent.event.provider,
        match,
        summary: cachedEvent.event.summary,
        scoreboardUrl: cachedEvent.scoreboardUrl || scoreboardUrl,
        summaryUrl: cachedEvent.event.summaryUrl || `${ESPN_SUMMARY}?event=${cachedEvent.event.id}`,
        mode: "本地 ESPN 缓存",
        warning: `实时 ESPN 抓取失败，已使用缓存：${error.message}`,
        cacheFetchedAt: cachedEvent.cacheFetchedAt,
      });
    }
    return {
      available: false,
      message: `ESPN 抓取失败：${error.message}`,
      scoreboardUrl,
    };
  }

  if (cachedEvent) {
    return buildEspnContextFromEvent({
      event: cachedEvent.event,
      provider: cachedEvent.event.provider,
      match,
      summary: cachedEvent.event.summary,
      scoreboardUrl: cachedEvent.scoreboardUrl || scoreboardUrl,
      summaryUrl: cachedEvent.event.summaryUrl || `${ESPN_SUMMARY}?event=${cachedEvent.event.id}`,
      mode: "本地 ESPN 缓存",
      warning: "实时 ESPN 当日赛程未匹配到该场，已使用本地完整赛程缓存。",
      cacheFetchedAt: cachedEvent.cacheFetchedAt,
    });
  }

  return {
    available: false,
    message: "ESPN 当日赛程中未匹配到这场比赛",
    scoreboardUrl,
  };
}

function espnScoreboardDateKeys(match) {
  const keys = new Set();
  const addDate = (value) => {
    const date = normalizeHistoryRecordDate(value);
    if (date) keys.add(date.replaceAll("-", ""));
  };
  addDate(match?.dateInfo?.date);
  addDate(match?.venueDateInfo?.date);
  const start = matchStartMs(match);
  if (Number.isFinite(start)) {
    for (const offsetDays of [0, -1, 1]) {
      const shifted = start + offsetDays * 24 * 60 * 60 * 1000;
      addDate(new Date(shifted).toISOString().slice(0, 10));
      addDate(zonedDateInfoFromUtcMs(shifted, "Asia/Shanghai").date);
    }
  }
  return [...keys].filter(Boolean);
}

function buildEspnContextFromEvent({ event, provider, match, summary, scoreboardUrl, summaryUrl, mode, warning = "", cacheFetchedAt = "" }) {
  const form = extractEspnForm(summary, match);
  const odds = extractEspnOdds(event, provider, match);
  const links = (event.links || []).map((link) => ({
    text: link.text || link.shortText || "ESPN",
    href: link.href,
  }));
  const videos = (summary?.videos || []).slice(0, 4).map((video) => ({
    title: video.headline,
    description: video.description,
    url: video.links?.web?.href,
    published: video.originalPublishDate,
  }));
  const competition = event.competitions?.[0] || {};
  const venue = event.venue || competition.venue || {};
  const score = extractEspnActualScore(event, match);
  const technicalStats = extractEspnTechnicalStats(summary, match);
  const completed = Boolean(event.status?.type?.completed) ||
    /final|full time|ft|completed/i.test(event.status?.type?.description || event.status?.type?.detail || "");

  return {
    available: true,
    eventId: event.id,
    name: event.name,
    date: event.date,
    venue: venue.displayName || venue.fullName || "",
    status: event.status?.type?.description || "",
    completed,
    score,
    technicalStats,
    links,
    odds,
    form,
    videos,
    provider: provider?.displayName || provider?.name || event.provider?.displayName || event.provider?.name || "",
    scoreboardUrl,
    summaryUrl,
    mode,
    warning,
    cacheFetchedAt,
  };
}

function extractEspnActualScore(event, match) {
  const competitors = getEspnCompetitors(event);
  const homeKeys = teamLookupKeys(match.home.name);
  const awayKeys = teamLookupKeys(match.away.name);
  const namedHome = competitors.find((competitor) =>
    teamLookupKeys(competitor.team?.displayName || competitor.team?.name || "").some((key) => homeKeys.includes(key))
  );
  const namedAway = competitors.find((competitor) =>
    teamLookupKeys(competitor.team?.displayName || competitor.team?.name || "").some((key) => awayKeys.includes(key))
  );
  const homeCompetitor = namedHome || competitors.find((competitor) => competitor.homeAway === "home");
  const awayCompetitor = namedAway || competitors.find((competitor) => competitor.homeAway === "away");
  return {
    home: numberOrNull(homeCompetitor?.score),
    away: numberOrNull(awayCompetitor?.score),
  };
}

function extractEspnTechnicalStats(summary, match) {
  const teams = arrayFrom(summary?.boxscore?.teams);
  if (!teams.length) {
    return {
      available: false,
      source: "ESPN summary",
      message: "ESPN summary 暂未返回角球/罚牌技术统计",
    };
  }
  const home = findEspnStatsTeam(teams, match.home, "home");
  const away = findEspnStatsTeam(teams, match.away, "away");
  const homeStats = statsMap(home?.statistics);
  const awayStats = statsMap(away?.statistics);
  const homeCorners = statNumber(homeStats, ["wonCorners", "cornerKicks", "corners"]);
  const awayCorners = statNumber(awayStats, ["wonCorners", "cornerKicks", "corners"]);
  const homeYellow = statNumber(homeStats, ["yellowCards"]);
  const awayYellow = statNumber(awayStats, ["yellowCards"]);
  const homeRed = statNumber(homeStats, ["redCards"]);
  const awayRed = statNumber(awayStats, ["redCards"]);
  const homeCards = sumFinite(homeYellow, homeRed);
  const awayCards = sumFinite(awayYellow, awayRed);
  const hasCorners = Number.isFinite(homeCorners) && Number.isFinite(awayCorners);
  const hasCards = Number.isFinite(homeCards) && Number.isFinite(awayCards);
  return {
    available: hasCorners || hasCards,
    source: "ESPN summary",
    message: hasCorners || hasCards ? "已匹配 ESPN 官方技术统计" : "ESPN summary 暂未返回角球/罚牌技术统计",
    corners: hasCorners
      ? {
          home: homeCorners,
          away: awayCorners,
          total: homeCorners + awayCorners,
        }
      : null,
    cards: hasCards
      ? {
          home: homeCards,
          away: awayCards,
          total: homeCards + awayCards,
          yellow: {
            home: Number.isFinite(homeYellow) ? homeYellow : null,
            away: Number.isFinite(awayYellow) ? awayYellow : null,
          },
          red: {
            home: Number.isFinite(homeRed) ? homeRed : null,
            away: Number.isFinite(awayRed) ? awayRed : null,
          },
        }
      : null,
  };
}

function findEspnStatsTeam(teams, team, homeAway) {
  const keys = teamLookupKeys(team?.name);
  return arrayFrom(teams).find((item) => item.homeAway === homeAway) ||
    arrayFrom(teams).find((item) => {
      const name = item.team?.displayName || item.team?.name || "";
      const itemKeys = teamLookupKeys(name);
      return itemKeys.some((key) => keys.includes(key));
    }) ||
    null;
}

function statsMap(statistics) {
  const map = {};
  for (const stat of arrayFrom(statistics)) {
    if (stat.name) map[stat.name] = stat;
    if (stat.label) map[normalizeTeamName(stat.label)] = stat;
  }
  return map;
}

function statNumber(map, keys) {
  for (const key of keys) {
    const stat = map[key] || map[normalizeTeamName(key)];
    const value = numberOrNull(stat?.value ?? stat?.displayValue);
    if (Number.isFinite(value)) return value;
  }
  return null;
}

function sumFinite(...values) {
  const clean = values.filter((value) => Number.isFinite(value));
  if (!clean.length) return null;
  return clean.reduce((sum, value) => sum + value, 0);
}

function findCachedEspnEvent(match, date) {
  const cachePath = new URL("data/espn-cache.json", import.meta.url);
  if (!existsSync(cachePath)) return null;
  try {
    const cacheJson = JSON.parse(readFileSync(cachePath, "utf8"));
    const candidates = (cacheJson.events || []).filter((event) => !date || event.dateKey === date);
    const event = findEspnEvent(candidates, match) || findEspnEvent(cacheJson.events || [], match);
    if (!event) return null;
    const scoreboard = cacheJson.scoreboards?.[event.dateKey] || null;
    return {
      event,
      scoreboardUrl: scoreboard?.url || "",
      cacheFetchedAt: cacheJson.fetchedAt || "",
    };
  } catch {
    return null;
  }
}

function findEspnEvent(events, match) {
  const homeKeys = teamLookupKeys(match.home.name);
  const awayKeys = teamLookupKeys(match.away.name);
  return (
    events.find((event) => {
      const text = normalizeTeamName(`${event.name || ""} ${event.shortName || ""}`);
      const competitors = getEspnCompetitors(event);
      const teamKeySets = competitors.map((competitor) =>
        teamLookupKeys(competitor.team?.displayName || competitor.team?.name || "")
      );
      return (
        (homeKeys.some((key) => text.includes(key)) && awayKeys.some((key) => text.includes(key))) ||
        (teamKeySets.some((keys) => keys.some((key) => homeKeys.includes(key))) &&
          teamKeySets.some((keys) => keys.some((key) => awayKeys.includes(key))))
      );
    }) || null
  );
}

function getEspnCompetitors(event) {
  return event.competitions?.[0]?.competitors || event.competitors || [];
}

function extractEspnForm(summary, match) {
  const forms = summary?.boxscore?.form || [];
  const output = {};
  for (const side of ["home", "away"]) {
    const teamName = normalizeTeamName(match[side].name);
    const form = forms.find((item) => normalizeTeamName(item.team?.displayName || "") === teamName);
    const events = (form?.events || []).slice(0, 6).map((event) => ({
      date: event.gameDate,
      result: event.gameResult,
      score: event.score,
      competition: event.competitionName || event.leagueName,
      opponent: event.opponent?.displayName || "",
      homeScore: numberOrNull(event.homeTeamScore),
      awayScore: numberOrNull(event.awayTeamScore),
      isHome: String(event.homeTeamId) === String(form?.team?.id),
    }));
    output[side] = summarizeRecentForm(events);
  }
  return output;
}

function summarizeRecentForm(events) {
  let points = 0;
  let goalsFor = 0;
  let goalsAgainst = 0;
  let counted = 0;
  for (const event of events) {
    const homeScore = Number(event.homeScore);
    const awayScore = Number(event.awayScore);
    if (!Number.isFinite(homeScore) || !Number.isFinite(awayScore)) continue;
    const gf = event.isHome ? homeScore : awayScore;
    const ga = event.isHome ? awayScore : homeScore;
    goalsFor += gf;
    goalsAgainst += ga;
    counted += 1;
    if (gf > ga) points += 3;
    else if (gf === ga) points += 1;
  }
  return {
    events,
    matches: counted,
    pointsPerGame: counted ? Number((points / counted).toFixed(2)) : null,
    goalsForPerGame: counted ? Number((goalsFor / counted).toFixed(2)) : null,
    goalsAgainstPerGame: counted ? Number((goalsAgainst / counted).toFixed(2)) : null,
    goalDiffPerGame: counted ? Number(((goalsFor - goalsAgainst) / counted).toFixed(2)) : null,
  };
}

function extractEspnOdds(event, provider, match) {
  const raw = (event.competitions?.[0]?.odds || event.odds || []).filter(Boolean)[0];
  if (!raw) return { available: false };
  const details = raw.details || "";
  const american = parseAmericanLine(details);
  const total = parseEspnTotal(raw);
  const spread = parseEspnSpread(raw);
  const moneyline = parseEspnMoneyline(raw);
  const favorite = favoriteFromEspnOdds({
    american,
    moneyline,
    match,
    competitors: getEspnCompetitors(event),
  });

  return {
    available: true,
    provider: provider?.displayName || provider?.name || raw.provider?.displayName || raw.provider?.name || "ESPN odds provider",
    details,
    overUnder: total?.line ?? numberOrNull(raw.overUnder),
    total,
    spread,
    moneyline,
    favorite,
  };
}

function parseEspnTotal(raw) {
  const line = parseMarketLine(raw.total?.over?.close?.line)
    ?? parseMarketLine(raw.total?.under?.close?.line)
    ?? parseMarketLine(raw.total?.over?.open?.line)
    ?? parseMarketLine(raw.total?.under?.open?.line)
    ?? numberOrNull(raw.overUnder);
  if (!Number.isFinite(line)) return null;
  return {
    line,
    overOdds: normalizeAmericanOdds(raw.total?.over?.close?.odds ?? raw.total?.over?.open?.odds),
    underOdds: normalizeAmericanOdds(raw.total?.under?.close?.odds ?? raw.total?.under?.open?.odds),
    overOpen: normalizeAmericanOdds(raw.total?.over?.open?.odds),
    underOpen: normalizeAmericanOdds(raw.total?.under?.open?.odds),
  };
}

function parseEspnSpread(raw) {
  const market = raw.pointSpread || raw.spread;
  if (!market || typeof market !== "object") {
    const line = numberOrNull(raw.pointSpread);
    return Number.isFinite(line) ? { line: Math.abs(line), home: { line, odds: null }, away: { line: -line, odds: null } } : null;
  }
  const homeLine = parseMarketLine(market.home?.close?.line) ?? parseMarketLine(market.home?.open?.line);
  const awayLine = parseMarketLine(market.away?.close?.line) ?? parseMarketLine(market.away?.open?.line);
  return {
    line: Number.isFinite(homeLine) ? Math.abs(homeLine) : Number.isFinite(awayLine) ? Math.abs(awayLine) : null,
    home: {
      line: homeLine,
      odds: normalizeAmericanOdds(market.home?.close?.odds ?? market.home?.open?.odds),
      openLine: parseMarketLine(market.home?.open?.line),
      openOdds: normalizeAmericanOdds(market.home?.open?.odds),
    },
    away: {
      line: awayLine,
      odds: normalizeAmericanOdds(market.away?.close?.odds ?? market.away?.open?.odds),
      openLine: parseMarketLine(market.away?.open?.line),
      openOdds: normalizeAmericanOdds(market.away?.open?.odds),
    },
  };
}

function parseEspnMoneyline(raw) {
  const market = raw.moneyline || {};
  const home = normalizeAmericanOdds(market.home?.close?.odds ?? market.home?.open?.odds ?? raw.homeTeamOdds?.moneyLine);
  const away = normalizeAmericanOdds(market.away?.close?.odds ?? market.away?.open?.odds ?? raw.awayTeamOdds?.moneyLine);
  const draw = normalizeAmericanOdds(market.draw?.close?.odds ?? market.draw?.open?.odds ?? raw.drawOdds?.moneyLine);
  const implied = {
    home: americanToProbability(home),
    draw: americanToProbability(draw),
    away: americanToProbability(away),
  };
  return {
    home,
    draw,
    away,
    implied,
  };
}

function favoriteFromEspnOdds({ american, moneyline, match, competitors }) {
  if (american) {
    const sideFromCode = codeToMatchSide(american.code, match, competitors);
    return {
      code: american.code,
      line: american.line,
      implied: americanToProbability(american.line),
      side: sideFromCode,
    };
  }
  const homeImplied = moneyline?.implied?.home;
  const awayImplied = moneyline?.implied?.away;
  if (!Number.isFinite(homeImplied) && !Number.isFinite(awayImplied)) return null;
  const side = (homeImplied || 0) >= (awayImplied || 0) ? "home" : "away";
  const line = moneyline?.[side];
  return {
    code: match[side].code,
    line,
    implied: moneyline?.implied?.[side],
    side,
  };
}

function codeToMatchSide(code, match, competitors = []) {
  if (code === match.home.code) return "home";
  if (code === match.away.code) return "away";
  const competitor = competitors.find((item) => item.team?.abbreviation === code);
  if (competitor?.homeAway === "home") return "home";
  if (competitor?.homeAway === "away") return "away";
  return "unknown";
}

function parseMarketLine(value) {
  if (value === null || value === undefined) return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const match = String(value).match(/[ou]?([+-]?\d+(?:\.\d+)?)/i);
  return match ? Number(match[1]) : null;
}

function normalizeAmericanOdds(value) {
  if (value === null || value === undefined || value === "") return null;
  const normalized = Number(String(value).replace("+", "").trim());
  return Number.isFinite(normalized) ? normalized : null;
}

function parseAmericanLine(details) {
  const match = String(details || "").match(/\b([A-Z]{2,4})\s*([+-]\d{2,4})\b/);
  if (!match) return null;
  return {
    code: match[1],
    line: Number(match[2]),
  };
}

function americanToProbability(line) {
  const value = Number(line);
  if (!Number.isFinite(value) || value === 0) return null;
  return value < 0
    ? Number((Math.abs(value) / (Math.abs(value) + 100)).toFixed(4))
    : Number((100 / (value + 100)).toFixed(4));
}

async function getSportsDbContext(match) {
  const eventUrl = `${SPORTS_DB}/searchevents.php?e=${encodeURIComponent(`${match.home.name}_vs_${match.away.name}`)}`;
  const [eventJson, homeJson, awayJson] = await Promise.all([
    fetchJson(eventUrl, { timeout: 15000 }),
    fetchJson(`${SPORTS_DB}/searchteams.php?t=${encodeURIComponent(match.home.name)}`, { timeout: 15000 }),
    fetchJson(`${SPORTS_DB}/searchteams.php?t=${encodeURIComponent(match.away.name)}`, { timeout: 15000 }),
  ]);
  const event = (eventJson.event || [])[0] || null;
  const homeTeam = findSportsDbTeam(homeJson.teams, match.home.name);
  const awayTeam = findSportsDbTeam(awayJson.teams, match.away.name);
  const [homeRecent, awayRecent] = await Promise.all([
    getSportsDbRecentEvents(homeTeam?.idTeam).catch(() => []),
    getSportsDbRecentEvents(awayTeam?.idTeam).catch(() => []),
  ]);
  return {
    available: Boolean(event || homeTeam || awayTeam),
    eventUrl,
    event: event
      ? {
          id: event.idEvent,
          name: event.strEvent,
          league: event.strLeague,
          date: event.dateEventLocal || event.dateEvent,
          time: event.strTimeLocal || event.strTime,
          venue: event.strVenue,
          city: event.strCity,
          poster: event.strPoster,
          thumb: event.strThumb,
          status: event.strStatus,
        }
      : null,
    teams: {
      home: compactSportsDbTeam(homeTeam),
      away: compactSportsDbTeam(awayTeam),
    },
    recentEvents: {
      home: homeRecent,
      away: awayRecent,
    },
  };
}

async function getSportsDbRecentEvents(teamId) {
  if (!teamId) return [];
  return cached(`sportsdb-recent-${teamId}`, 60 * 60 * 1000, async () => {
    const json = await fetchJson(`${SPORTS_DB}/eventslast.php?id=${encodeURIComponent(teamId)}`, {
      timeout: 15000,
    });
    return arrayFrom(json.results).map((event) => ({
      id: event.idEvent,
      date: event.dateEvent,
      homeTeam: event.strHomeTeam,
      awayTeam: event.strAwayTeam,
      homeScore: numberOrNull(event.intHomeScore),
      awayScore: numberOrNull(event.intAwayScore),
      competition: event.strLeague,
      source: "TheSportsDB",
    }));
  });
}

function findSportsDbTeam(teams, name) {
  const normalized = normalizeTeamName(name);
  return (teams || []).find((team) => normalizeTeamName(team.strTeam) === normalized && team.strSport === "Soccer") || null;
}

function compactSportsDbTeam(team) {
  if (!team) return null;
  return {
    id: team.idTeam,
    name: team.strTeam,
    league: team.strLeague,
    stadium: team.strStadium,
    country: team.strCountry,
    badge: team.strBadge,
    logo: team.strLogo,
    description: normalizeWhitespace(team.strDescriptionEN || "").slice(0, 480),
    website: team.strWebsite,
  };
}

async function searchWeb(query, limit = 6) {
  const key = `search:${limit}:${query}`;
  return cached(key, SEARCH_CACHE_TTL_MS, async () => {
    const [news, duck, bing] = await Promise.all([
      withTimeout(searchBingNewsRss(query, limit), SEARCH_SOURCE_TIMEOUT_MS, []).catch(() => []),
      withTimeout(searchDuckDuckGo(query, limit), SEARCH_SOURCE_TIMEOUT_MS, []).catch(() => []),
      withTimeout(searchBing(query, limit), SEARCH_SOURCE_TIMEOUT_MS, []).catch(() => []),
    ]);
    return uniqueSearchResults([...news, ...duck, ...bing]).slice(0, limit);
  });
}

async function searchBingNewsRss(query, limit = 6) {
  const params = new URLSearchParams({
    q: query,
    format: "rss",
    cc: "US",
  });
  const xml = await fetchText(`${BING_NEWS_RSS}?${params.toString()}`, {
    headers: {
      ...REQUEST_HEADERS,
      Accept: "application/rss+xml,application/xml,text/xml,text/html;q=0.8",
      "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8",
    },
    timeout: 16000,
    preferPowerShell: true,
  });
  const $ = cheerio.load(xml, { xmlMode: true });
  const results = [];

  $("item").each((_idx, item) => {
    if (results.length >= limit) return false;
    const node = $(item);
    const rawUrl = normalizeWhitespace(node.find("link").first().text());
    const url = unwrapBingNewsUrl(rawUrl);
    const title = decodeHtml(normalizeWhitespace(node.find("title").first().text()));
    const snippet = decodeHtml(stripHtml(normalizeWhitespace(node.find("description").first().text())));
    const domain = safeHostname(url) || normalizeWhitespace(node.find("source").first().text());
    if (title || snippet) {
      results.push({
        title,
        snippet,
        url,
        domain,
        sourceType: "Bing News RSS",
        publishedAt: normalizeWhitespace(node.find("pubDate").first().text()),
      });
    }
    return undefined;
  });

  return results;
}

async function searchBing(query, limit = 6) {
  const params = new URLSearchParams({
    q: query,
    setlang: "zh-CN",
    mkt: "zh-CN",
  });
  const html = await fetchText(`${BING_SEARCH}?${params.toString()}`, {
    headers: REQUEST_HEADERS,
    timeout: 16000,
  });
  const $ = cheerio.load(html);
  const results = [];

  $("li.b_algo").each((_idx, element) => {
    if (results.length >= limit) return false;
    const node = $(element);
    const link = node.find("h2 a").first();
    const rawUrl = link.attr("href") || "";
    const url = unwrapBingUrl(rawUrl);
    const title = normalizeWhitespace(link.text());
    const snippet = normalizeWhitespace(
      node.find(".b_caption p").first().text() ||
        node.find("p").first().text() ||
        node.find(".b_snippet").first().text()
    );
    const domain = safeHostname(url);
    if ((title || snippet) && url && !domain.includes("bing.com")) {
      results.push({ title, snippet, url, domain });
    }
    return undefined;
  });

  return results;
}

async function searchDuckDuckGo(query, limit = 6) {
  const params = new URLSearchParams({ q: query });
  const html = await fetchText(`${DDG_HTML}?${params.toString()}`, {
    headers: REQUEST_HEADERS,
    timeout: 16000,
    preferPowerShell: true,
  });
  const $ = cheerio.load(html);
  const results = [];

  $(".result").each((_idx, element) => {
    if (results.length >= limit) return false;
    const node = $(element);
    const link = node.find("a.result__a").first();
    const rawUrl = link.attr("href") || "";
    const url = unwrapDuckDuckGoUrl(rawUrl);
    const title = normalizeWhitespace(link.text());
    const snippet = normalizeWhitespace(node.find(".result__snippet").text());
    const domain =
      normalizeWhitespace(node.find(".result__url").text()) || safeHostname(url);
    if (title || snippet) {
      results.push({ title, snippet, url, domain });
    }
    return undefined;
  });

  return results;
}

function uniqueSearchResults(results) {
  const seen = new Set();
  const output = [];
  for (const result of results) {
    const key = result.url || `${result.title}:${result.domain}`;
    if (!key || seen.has(key)) continue;
    seen.add(key);
    output.push(result);
  }
  return output;
}

async function crawlPages(targets, limit) {
  const unique = [];
  const seen = new Set();
  for (const target of targets) {
    const host = safeHostname(target.url);
    if (!host || seen.has(host) || /duckduckgo|google|bing|yahoo|facebook|x\.com|twitter/.test(host)) {
      continue;
    }
    seen.add(host);
    unique.push(target);
    if (unique.length >= limit) break;
  }

  const settled = await Promise.allSettled(unique.map((target) => crawlOnePageCached(target)));
  return settled
    .map((result) => (result.status === "fulfilled" ? result.value : null))
    .filter(Boolean);
}

async function crawlOnePageCached(target) {
  const page = await cached(`crawl:${target.url}`, CRAWL_CACHE_TTL_MS, () => crawlOnePage(target));
  return {
    ...page,
    side: target.side || page.side,
    groupLabel: target.groupLabel || page.groupLabel,
  };
}

async function crawlOnePage(target) {
  const html = await fetchText(target.url, {
    headers: REQUEST_HEADERS,
    timeout: CRAWL_PAGE_TIMEOUT_MS,
  });
  const $ = cheerio.load(html);
  $("script, style, nav, footer, header, aside, form, noscript").remove();
  const title = normalizeWhitespace($("title").first().text() || target.title);
  const h1 = normalizeWhitespace($("h1").first().text());
  const paragraphs = [];
  $("article p, main p, p").each((_idx, element) => {
    const text = normalizeWhitespace($(element).text());
    if (text.length >= 45) paragraphs.push(text);
    if (paragraphs.join(" ").length > 2200) return false;
    return undefined;
  });

  const text = normalizeWhitespace([h1, ...paragraphs].join(" ")).slice(0, 2600);
  return {
    title,
    h1,
    text,
    url: target.url,
    domain: safeHostname(target.url),
    side: target.side,
    groupLabel: target.groupLabel,
  };
}

function filterRelevantResults(results, query, match, venue) {
  const blockedDomains = [
    "baike.baidu.com",
    "iciba.com",
    "quickanswer.org",
    "britannica.com",
    "study.com",
    "wikipedia.org",
  ];
  const homeTokens = teamTokens(match.home.name, teamLabel(match.home), match.home.code);
  const awayTokens = teamTokens(match.away.name, teamLabel(match.away), match.away.code);
  const venueTokens = teamTokens(`${venue.name || ""} ${venue.fifaName || ""}`);
  const context = (query.context || []).map((item) => item.toLowerCase());

  return results.filter((result) => {
    const domain = safeHostname(result.url || "");
    if (blockedDomains.some((blocked) => domain.includes(blocked))) return false;
    const haystack = normalizeWhitespace(`${result.title} ${result.snippet} ${result.url} ${domain}`).toLowerCase();
    const hasContext = context.some((token) => haystack.includes(token));
    if (!hasContext) return false;

    if (query.side === "venue") {
      return venueTokens.some((token) => haystack.includes(token));
    }
    if (query.side === "odds" || query.side === "match" || query.side === "intel") {
      return (
        homeTokens.some((token) => haystack.includes(token)) &&
        awayTokens.some((token) => haystack.includes(token))
      );
    }
    if (query.side === "home") {
      return homeTokens.some((token) => haystack.includes(token));
    }
    if (query.side === "away") {
      return awayTokens.some((token) => haystack.includes(token));
    }
    return true;
  });
}

function teamTokens(...values) {
  const tokens = new Set();
  for (const value of values) {
    const raw = String(value || "").toLowerCase();
    for (const token of normalizeTeamName(raw).split(" ")) {
      if (token.length >= 3) tokens.add(token);
    }
    for (const token of raw.match(/[\u4e00-\u9fff]{2,}|[a-z0-9]{3,}/g) || []) {
      tokens.add(token);
    }
  }
  return [...tokens].filter(Boolean);
}

function extractResearchSignals({ match, searchGroups = [], crawled = [], structured, directSources = {} }) {
  const snippets = searchGroups.flatMap((group) =>
    group.results.map((result) => ({
      text: `${result.title}. ${result.snippet}`,
      side: group.side,
      domain: result.domain,
      url: result.url,
      groupLabel: group.label,
    }))
  );
  const directEntries = arrayFrom(directSources.entries).map((entry) => ({
    kind: entry.kind,
    text: entry.text,
    side: entry.side || "odds",
    domain: entry.domain || directSources.domain || "guest.api.arcadia.pinnacle.com",
    url: entry.url || directSources.url || "",
    groupLabel: entry.groupLabel || directSources.label || "Pinnacle World Cup 直连",
    sourceType: "direct",
    totalLine: entry.totalLine,
    handicapLine: entry.handicapLine,
    capturedAt: entry.capturedAt,
  }));
  const entries = [...snippets, ...crawled, ...directEntries];
  const homeName = match.home.name;
  const awayName = match.away.name;

  const homeInjuries = scoreKeywordSignals(entries, homeName, "home", INJURY_KEYWORDS);
  const awayInjuries = scoreKeywordSignals(entries, awayName, "away", INJURY_KEYWORDS);
  const lineups = scoreKeywordSignals(entries, `${homeName} ${awayName}`, "match", LINEUP_KEYWORDS);
  const homeSearchName = `${homeName} ${teamLabel(match.home)} ${match.home.code || ""}`;
  const awaySearchName = `${awayName} ${teamLabel(match.away)} ${match.away.code || ""}`;
  const oddsSignals = scoreOddsSignals(entries, homeSearchName, awaySearchName);
  const scoreConsensus = extractScoreConsensus(entries, match, homeSearchName, awaySearchName);
  const cornerSignals = scoreDerivativeMarketSignals(entries, homeSearchName, awaySearchName, "corners");
  const cardSignals = scoreDerivativeMarketSignals(entries, homeSearchName, awaySearchName, "cards");
  const venueSignals = scoreVenueSignals(entries);
  const form = structured?.formGuide || structured?.espn?.form || {};

  return {
    homeInjuryScore: homeInjuries.score,
    awayInjuryScore: awayInjuries.score,
    homeInjuryEvidence: homeInjuries.evidence,
    awayInjuryEvidence: awayInjuries.evidence,
    lineupScore: lineups.score,
    lineupEvidence: lineups.evidence,
    oddsConsensus: oddsSignals,
    scoreConsensus,
    corners: cornerSignals,
    cards: cardSignals,
    venue: venueSignals,
    form,
    fifa: structured?.fifa || {},
    sourceCount: entries.filter((entry) => entry.text?.length > 20).length,
  };
}

function buildDerivativeSnapshotFromSignals(match, signals = {}) {
  const entries = [];
  for (const [kind, label] of [
    ["corners", "角球"],
    ["cards", "罚牌"],
  ]) {
    const signal = signals[kind] || {};
    if (!Number(signal.sourceCount || 0)) continue;
    const totalLine = Number.isFinite(Number(signal.totalLine)) ? Number(signal.totalLine) : null;
    const handicapLine = Number.isFinite(Number(signal.handicapLine)) ? Number(signal.handicapLine) : null;
    if (!Number.isFinite(totalLine) && !Number.isFinite(handicapLine)) continue;
    const evidenceText = arrayFrom(signal.evidence)
      .map((item) => `${item.domain || "网页"}：${item.text || ""}`)
      .filter(Boolean)
      .slice(0, 3)
      .join("；");
    const lineText = [
      totalLine ? `${label}大小盘口线 ${formatTotalLine(totalLine)}` : "",
      handicapLine ? `${label}让球盘口线 ${formatTotalLine(handicapLine)}` : "",
      signal.overLean > signal.underLean ? "大盘信号偏多" : signal.underLean > signal.overLean ? "小盘信号偏多" : "",
    ].filter(Boolean).join("，");
    entries.push({
      kind,
      side: "odds",
      domain: "multi-source-cache",
      url: "",
      groupLabel: "全网盘口爬取缓存",
      sourceType: "web-signal",
      totalLine,
      handicapLine,
      text: `全网爬取${label}盘口信号：${lineText || "暂无明确盘口线"}。来源摘要：${evidenceText || "搜索/网页摘要已命中相关盘口关键词"}。`,
    });
  }
  return {
    available: entries.length > 0,
    source: "全网盘口爬取缓存",
    label: "全网盘口爬取缓存",
    domain: "multi-source-cache",
    entries,
    message: entries.length ? `已缓存 ${entries.length} 条全网角球/罚牌盘口信号` : "暂无可缓存的角球/罚牌盘口信号",
  };
}

const INJURY_KEYWORDS = [
  "injury",
  "injured",
  "fitness",
  "doubt",
  "doubtful",
  "suspended",
  "suspension",
  "ruled out",
  "unavailable",
  "absent",
  "伤",
  "伤停",
  "受伤",
  "缺阵",
  "停赛",
  "出战成疑",
];

const LINEUP_KEYWORDS = [
  "lineup",
  "starting xi",
  "squad",
  "formation",
  "roster",
  "tactical",
  "tactics",
  "pressing",
  "transition",
  "set pieces",
  "阵容",
  "首发",
  "名单",
  "大名单",
  "战术",
  "压迫",
  "反击",
  "定位球",
];

function scoreKeywordSignals(entries, teamName, preferredSide, keywords) {
  const name = String(teamName || "").toLowerCase();
  const evidence = [];
  let score = 0;

  for (const entry of entries) {
    const text = String(entry.text || "");
    const lower = text.toLowerCase();
    const sideBoost = entry.side === preferredSide ? 1 : 0;
    const mentionsTeam = !name || name.split(" ").some((part) => part.length > 3 && lower.includes(part));
    const hits = keywords.filter((keyword) => lower.includes(keyword.toLowerCase())).length;
    if (hits && (sideBoost || mentionsTeam || preferredSide === "match")) {
      const weight = sideBoost ? 1.2 : 0.65;
      score += hits * weight;
      if (evidence.length < 5) {
        evidence.push({
          text: selectEvidenceSentence(text, keywords),
          url: entry.url,
          domain: entry.domain,
          side: entry.side,
        });
      }
    }
  }

  return {
    score: Math.min(8, Number(score.toFixed(2))),
    evidence,
  };
}

function scoreOddsSignals(entries, homeName, awayName) {
  const homeTokens = teamTokens(homeName);
  const awayTokens = teamTokens(awayName);
  const out = {
    homeLean: 0,
    drawLean: 0,
    awayLean: 0,
    overLean: 0,
    underLean: 0,
    evidence: [],
  };

  for (const entry of entries) {
    const text = String(entry.text || "");
    const lower = text.toLowerCase();
    const isOddsText = ODDS_KEYWORDS.some((keyword) => lower.includes(keyword));
    if (!isOddsText) continue;

    const sentences = splitSentences(text).slice(0, 14);
    for (const sentence of sentences) {
      const s = sentence.toLowerCase();
      const normalizedSentence = normalizeTeamName(sentence);
      const rawSentence = sentence.toLowerCase();
      const mentionsHome = homeTokens.some((token) => normalizedSentence.includes(token) || rawSentence.includes(token));
      const mentionsAway = awayTokens.some((token) => normalizedSentence.includes(token) || rawSentence.includes(token));
      if (mentionsHome && /(win|favorite|favourite|pick|lean|胜|主胜|看好|推荐)/.test(s)) out.homeLean += 1;
      if (mentionsAway && /(win|favorite|favourite|pick|lean|胜|客胜|看好|推荐)/.test(s)) out.awayLean += 1;
      if (/(draw|tie|平局|平手|平赔)/.test(s)) out.drawLean += 0.7;
      if (/(over|大球|超过|高于)/.test(s)) out.overLean += 0.7;
      if (/(under|小球|低于|少于)/.test(s)) out.underLean += 0.7;
    }

    if (out.evidence.length < 8) {
      out.evidence.push({
        text: selectEvidenceSentence(text, ODDS_KEYWORDS),
        url: entry.url,
        domain: entry.domain,
        side: entry.side,
      });
    }
  }

  for (const key of ["homeLean", "drawLean", "awayLean", "overLean", "underLean"]) {
    out[key] = Number(out[key].toFixed(2));
  }
  return out;
}

const SCORE_PREDICTION_KEYWORDS = [
  "correct score",
  "score prediction",
  "predicted score",
  "predicts",
  "prediction",
  "betting tips",
  "pick",
  "tips",
  "比分推荐",
  "比分预测",
  "推荐比分",
  "预测比分",
  "竞彩",
  "彩经",
  "足彩",
  "赛果",
  "胜平负",
];

function extractScoreConsensus(entries, match, homeName, awayName) {
  const homeTokens = teamTokens(homeName, match?.home?.name, teamLabel(match?.home), match?.home?.code);
  const awayTokens = teamTokens(awayName, match?.away?.name, teamLabel(match?.away), match?.away?.code);
  const buckets = new Map();
  const seen = new Set();
  let sourceCount = 0;

  for (const entry of entries) {
    const rawText = normalizeWhitespace(String(entry.text || ""));
    if (!rawText || rawText.length < 12) continue;
    const lower = rawText.toLowerCase();
    const groupText = `${entry.side || ""} ${entry.groupLabel || ""} ${entry.domain || ""}`.toLowerCase();
    const predictionGroup = entry.side === "prediction" || /prediction|correct score|比分|竞彩|彩经|足彩|推荐/.test(groupText);
    const hasPredictionKeyword = SCORE_PREDICTION_KEYWORDS.some((keyword) => lower.includes(keyword.toLowerCase()));
    if (!predictionGroup && !hasPredictionKeyword) continue;

    const normalized = normalizeTeamName(rawText);
    const mentionsHome = homeTokens.some((token) => normalized.includes(token) || lower.includes(token));
    const mentionsAway = awayTokens.some((token) => normalized.includes(token) || lower.includes(token));
    if (!predictionGroup && !(mentionsHome && mentionsAway)) continue;

    const domain = String(entry.domain || safeHostname(entry.url || "") || "网页").toLowerCase();
    const sentences = splitSentences(rawText).slice(0, 16);
    let entryHit = false;

    for (const sentence of sentences) {
      const sentenceLower = sentence.toLowerCase();
      const sentenceHasKeyword = SCORE_PREDICTION_KEYWORDS.some((keyword) => sentenceLower.includes(keyword.toLowerCase()));
      const sentenceNormalized = normalizeTeamName(sentence);
      const sentenceMentionsHome = homeTokens.some((token) => sentenceNormalized.includes(token) || sentenceLower.includes(token));
      const sentenceMentionsAway = awayTokens.some((token) => sentenceNormalized.includes(token) || sentenceLower.includes(token));
      if (!sentenceHasKeyword && !(sentenceMentionsHome && sentenceMentionsAway)) continue;

      const matches = collectScoreMentions(sentence);
      for (const score of matches) {
        if (!isPlausibleFootballScore(score.home, score.away)) continue;
        if (!sentenceHasKeyword && looksLikeNonScoreNumberContext(sentenceLower)) continue;
        const scoreText = `${score.home}-${score.away}`;
        const seenKey = `${domain}|${scoreText}|${sentence.slice(0, 120)}`;
        if (seen.has(seenKey)) continue;
        seen.add(seenKey);

        const baseWeight = scorePredictionSourceWeight(entry, sentence);
        const keywordBoost = sentenceHasKeyword ? 0.45 : hasPredictionKeyword ? 0.22 : 0;
        const teamBoost = sentenceMentionsHome && sentenceMentionsAway ? 0.28 : mentionsHome && mentionsAway ? 0.12 : 0;
        const weight = Number(clamp(baseWeight + keywordBoost + teamBoost, 0.35, 2.2).toFixed(2));
        const bucket = buckets.get(scoreText) || {
          score: scoreText,
          homeGoals: score.home,
          awayGoals: score.away,
          weight: 0,
          sourceCount: 0,
          domains: new Set(),
          evidence: [],
        };
        bucket.weight += weight;
        bucket.sourceCount += 1;
        if (domain) bucket.domains.add(domain);
        if (bucket.evidence.length < 4) {
          bucket.evidence.push({
            text: selectEvidenceSentence(sentence, SCORE_PREDICTION_KEYWORDS),
            url: entry.url,
            domain: entry.domain || domain,
            groupLabel: entry.groupLabel,
          });
        }
        buckets.set(scoreText, bucket);
        entryHit = true;
      }
    }
    if (entryHit) sourceCount += 1;
  }

  const ranked = [...buckets.values()]
    .map((item) => ({
      ...item,
      weight: Number(item.weight.toFixed(2)),
      domains: [...item.domains].slice(0, 6),
    }))
    .sort((a, b) => b.weight - a.weight || b.sourceCount - a.sourceCount || a.homeGoals + a.awayGoals - (b.homeGoals + b.awayGoals));
  const totalWeight = ranked.reduce((sum, item) => sum + item.weight, 0);
  const topScores = ranked.slice(0, 6).map((item) => ({
    ...item,
    probability: Number((item.weight / (totalWeight || 1)).toFixed(4)),
  }));
  const directionMass = topScores.reduce(
    (acc, item) => {
      const direction = scoreDirection({ home: item.homeGoals, away: item.awayGoals });
      acc[direction] += item.weight;
      if (item.homeGoals + item.awayGoals >= 3) acc.over += item.weight;
      else acc.under += item.weight;
      return acc;
    },
    { home: 0, draw: 0, away: 0, over: 0, under: 0 }
  );

  return {
    available: topScores.length > 0 && totalWeight >= 0.9,
    sourceCount,
    totalWeight: Number(totalWeight.toFixed(2)),
    topScores,
    homeLean: Number(directionMass.home.toFixed(2)),
    drawLean: Number(directionMass.draw.toFixed(2)),
    awayLean: Number(directionMass.away.toFixed(2)),
    overLean: Number(directionMass.over.toFixed(2)),
    underLean: Number(directionMass.under.toFixed(2)),
    evidence: topScores.flatMap((item) => item.evidence || []).slice(0, 8),
  };
}

function collectScoreMentions(sentence) {
  const text = String(sentence || "");
  const matches = [];
  const patterns = [
    /(?:correct\s+score|score\s+prediction|predicted\s+score|prediction|predicts|pick|tips|比分(?:推荐|预测|参考)?|推荐比分|预测比分|赛果)[^\d]{0,42}(\d{1,2})\s*[-:：比]\s*(\d{1,2})/gi,
    /(?:^|[^\d(])(\d{1,2})\s*[-:：]\s*(\d{1,2})(?!\s*[-]\s*\d)(?!\d)/g,
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(text))) {
      matches.push({
        home: Number(match[1]),
        away: Number(match[2]),
      });
    }
  }
  return matches;
}

function isPlausibleFootballScore(home, away) {
  if (!Number.isInteger(home) || !Number.isInteger(away)) return false;
  if (home < 0 || away < 0 || home > 8 || away > 8) return false;
  if (home + away > 8) return false;
  return true;
}

function looksLikeNonScoreNumberContext(sentenceLower) {
  return /(rank|ranking|fifa\s*rank|odds|price|handicap|spread|line|total|over|under|corner|corners|cards|yellow|排名|指数|赔率|让球|大小|角球|罚牌|黄牌|红牌|第\s*\d+)/i.test(sentenceLower);
}

function scorePredictionSourceWeight(entry, sentence) {
  const domain = String(entry?.domain || safeHostname(entry?.url || "") || "").toLowerCase();
  const haystack = `${domain} ${entry?.groupLabel || ""} ${sentence || ""}`.toLowerCase();
  let weight = 0.62;
  if (/sportsmole|sports\s*mole|forebet|predictz|windrawwin|betclan|footballpredictions|standard|sportskeeda/.test(haystack)) weight = 1.12;
  if (/500\.com|sina|sohu|163|zhibo8|leisu|sporttery|竞彩网|中国体彩网|彩经|竞彩|足彩/.test(haystack)) weight = Math.max(weight, 1.05);
  if (/oddschecker|oddspedia|oddsportal|pinnacle|bet365|draftkings|fanduel/.test(haystack)) weight = Math.max(weight, 0.92);
  if (entry?.sourceType === "direct") weight += 0.18;
  if (/correct score|score prediction|比分推荐|比分预测|推荐比分|预测比分/.test(haystack)) weight += 0.2;
  return Number(clamp(weight, 0.45, 1.6).toFixed(2));
}

const ODDS_KEYWORDS = [
  "odds",
  "handicap",
  "spread",
  "over",
  "under",
  "moneyline",
  "bookmaker",
  "prediction",
  "betting",
  "盘口",
  "赔率",
  "让球",
  "大小球",
  "欧赔",
  "亚盘",
  "推荐",
];

const CORNER_KEYWORDS = [
  "corner",
  "corners",
  "corner kicks",
  "corner handicap",
  "team corners",
  "corner betting",
  "corner props",
  "corners over",
  "corners under",
  "角球",
  "角球数",
  "角球让球",
  "角球大小",
  "角球盘口",
  "角球推荐",
  "角球彩经",
];

const CARD_KEYWORDS = [
  "card",
  "cards",
  "booking",
  "bookings",
  "yellow card",
  "red card",
  "team cards",
  "card props",
  "booking points",
  "referee",
  "罚牌",
  "黄牌",
  "红牌",
  "红黄牌",
  "牌数",
  "裁判",
  "罚牌让球",
  "罚牌大小",
  "罚牌盘口",
  "罚牌推荐",
  "红黄牌推荐",
];

function scoreDerivativeMarketSignals(entries, homeName, awayName, kind) {
  const keywords = kind === "cards" ? CARD_KEYWORDS : CORNER_KEYWORDS;
  const homeTokens = teamTokens(homeName);
  const awayTokens = teamTokens(awayName);
  const marketIntentPattern = /\b(odds|bookmakers?|betting|bets?|pick|prediction|prop|props|line|spread|handicap|total)\b|best bet|over\/under|盘口|盘口线|竞彩|投注|赔率|水位|让球|让盘|大小|推荐|预测|彩经|指数|大小球|让分/i;
  const out = {
    kind,
    overLean: 0,
    underLean: 0,
    homeHandicapLean: 0,
    awayHandicapLean: 0,
    totalLine: null,
    handicapLine: null,
    sourceCount: 0,
    sourceWeight: 0,
    sourceQuality: {
      score: 0,
      label: "低",
      direct: 0,
      cache: 0,
      aggregate: 0,
      web: 0,
      domains: [],
      latestCapturedAt: "",
    },
    evidence: [],
  };
  const totalLines = [];
  const handicapLines = [];
  const qualityDomains = new Set();
  let latestCapturedAt = "";

  for (const entry of entries) {
    if (entry.kind && entry.kind !== kind) continue;
    const text = String(entry.text || "");
    const lower = text.toLowerCase();
    const marketText = derivativeMarketSearchText(lower, kind);
    const hasMarketKeyword = hasDerivativeMarketKeyword(marketText, keywords, kind);
    if (!hasMarketKeyword) continue;

    const totalLine = Number.isFinite(Number(entry.totalLine))
      ? normalizeDerivativeLine(entry.totalLine, kind, "total")
      : extractDerivativeLine(text, kind, "total");
    const handicapLine = Number.isFinite(Number(entry.handicapLine))
      ? normalizeDerivativeLine(entry.handicapLine, kind, "handicap")
      : extractDerivativeLine(text, kind, "handicap");
    const hasParsedLine = Number.isFinite(totalLine) || Number.isFinite(handicapLine);
    const hasBettingIntent = marketIntentPattern.test(lower);
    if (!hasParsedLine && !hasBettingIntent) continue;

    out.sourceCount += 1;
    const weight = derivativeSignalWeight(entry);
    out.sourceWeight += weight;
    const bucket = derivativeSignalBucket(entry);
    out.sourceQuality[bucket] = Number(out.sourceQuality[bucket] || 0) + 1;
    if (entry.domain) qualityDomains.add(entry.domain);
    const capturedAt = entry.capturedAt || entry.updatedAt || "";
    if (capturedAt && (!latestCapturedAt || Date.parse(capturedAt) > Date.parse(latestCapturedAt))) {
      latestCapturedAt = capturedAt;
    }
    if (Number.isFinite(totalLine)) totalLines.push(totalLine);
    if (Number.isFinite(handicapLine)) handicapLines.push(Math.abs(handicapLine));

    const sentences = splitSentences(text).slice(0, 14);
    for (const sentence of sentences) {
      const s = sentence.toLowerCase();
      const normalizedSentence = normalizeTeamName(sentence);
      const rawSentence = sentence.toLowerCase();
      const mentionsKind = keywords.some((keyword) => s.includes(keyword.toLowerCase()));
      if (!mentionsKind) continue;

      if (/(over|higher|more|大|高于|超过|更多)/.test(s)) out.overLean += 0.75;
      if (/(under|lower|less|小|低于|少于|更少)/.test(s)) out.underLean += 0.75;
      if (/(handicap|spread|line|让|让球|让盘)/.test(s)) {
        if (homeTokens.some((token) => normalizedSentence.includes(token) || rawSentence.includes(token))) out.homeHandicapLean += 0.8;
        if (awayTokens.some((token) => normalizedSentence.includes(token) || rawSentence.includes(token))) out.awayHandicapLean += 0.8;
      }
    }

    if (out.evidence.length < 6) {
      out.evidence.push({
        text: selectEvidenceSentence(text, [...keywords, "handicap", "spread", "over", "under", "盘口", "大小", "让球"]),
        url: entry.url,
        domain: entry.domain,
        side: entry.side,
        groupLabel: entry.groupLabel,
      });
    }
  }

  out.totalLine = medianLine(totalLines);
  out.handicapLine = medianLine(handicapLines);
  out.sourceWeight = Number(out.sourceWeight.toFixed(2));
  out.sourceQuality = {
    ...out.sourceQuality,
    score: out.sourceWeight,
    label: derivativeSourceQualityLabel(out.sourceWeight, out.sourceQuality),
    domains: [...qualityDomains].slice(0, 6),
    latestCapturedAt,
  };
  for (const key of ["overLean", "underLean", "homeHandicapLean", "awayHandicapLean"]) {
    out[key] = Number(out[key].toFixed(2));
  }
  return out;
}

function derivativeSignalBucket(entry = {}) {
  const domain = String(entry.domain || "").toLowerCase();
  const sourceType = String(entry.sourceType || "").toLowerCase();
  if (sourceType === "direct" || domain.includes("pinnacle") || domain.includes("guest.api.arcadia")) return "direct";
  if (sourceType === "local-cache") return "cache";
  if (domain === "multi-source-cache" || sourceType === "web-signal") return "aggregate";
  return "web";
}

function derivativeSignalWeight(entry = {}) {
  const bucket = derivativeSignalBucket(entry);
  if (bucket === "direct") return 1;
  if (bucket === "cache") return 0.72;
  if (bucket === "aggregate") return 0.42;
  const domain = String(entry.domain || "").toLowerCase();
  if (/oddsportal|oddspedia|oddschecker|betexplorer|flashscore|leisu|kaiyun|bet365|fanduel|rotowire|betfair|betway|unibet|williamhill|bwin|ladbrokes|coral|betmgm|caesars|pointsbet|footystats|statbunker|sofascore|fotmob|whoscored/.test(domain)) return 0.58;
  return 0.25;
}

function derivativeSourceQualityLabel(score, quality = {}) {
  const value = Number(score || 0);
  if (Number(quality.direct || 0) >= 2 || value >= 2.25) return "高";
  if (Number(quality.direct || 0) >= 1 || value >= 1.25) return "较高";
  if (value >= 0.72) return "中";
  if (value > 0) return "低";
  return "无";
}

function derivativeMarketSearchText(lower, kind) {
  const text = String(lower || "");
  if (kind !== "corners") return text;
  return text
    .replace(/\bright around the corner\b/g, " ")
    .replace(/\baround the corner\b/g, " ");
}

function hasDerivativeMarketKeyword(text, keywords, kind) {
  if (kind === "corners") {
    return /\bcorners?\b|\bcorner kicks?\b|角球/i.test(text);
  }
  return keywords.some((keyword) => text.includes(String(keyword).toLowerCase()));
}

function extractDerivativeLine(text, kind, type) {
  const lower = String(text || "").toLowerCase();
  const directLine = extractDirectDerivativeLine(lower, kind, type);
  if (Number.isFinite(directLine)) return directLine;
  const keywordPattern = kind === "cards"
    ? /\b(cards?|bookings?|yellow cards?|red cards?)\b|罚牌|黄牌|红牌|牌数/i
    : /\b(corners?|corner kicks?)\b|角球|角球数/i;
  const typePattern = type === "handicap"
    ? /\b(handicap|spread)\b|让球|让盘|让/i
    : /\b(over|under|total|line)\b|大小|大|小|总数|盘口/i;
  const matches = [...lower.matchAll(/-?\d+(?:\.\d+)?/g)];
  const min = kind === "cards"
    ? type === "total" ? 2.5 : 0.5
    : type === "total" ? 6 : 0.5;
  const max = kind === "cards"
    ? type === "total" ? 9 : 4
    : type === "total" ? 16 : 5;

  for (const match of matches) {
    const value = Number(match[0]);
    if (!Number.isFinite(value) || Math.abs(value) < min || Math.abs(value) > max) continue;
    const start = Math.max(0, match.index - 42);
    const end = Math.min(lower.length, match.index + match[0].length + 42);
    const window = lower.slice(start, end);
    if (keywordPattern.test(window) && typePattern.test(window)) return normalizeDerivativeLine(Math.abs(value), kind, type);
  }
  return null;
}

function extractDirectDerivativeLine(text, kind, type) {
  const unit = kind === "cards"
    ? "(?:cards?|bookings?|yellow cards?|red cards?|罚牌|黄牌|红牌|牌数)"
    : "(?:corners?|corner kicks?|角球|角球数)";
  const totalPatterns = [
    new RegExp(`\\b(?:over|under|o/u|total)\\s*([0-9]+(?:\\.[0-9]+)?)\\s*${unit}\\b`, "i"),
    new RegExp(`\\b${unit}\\s*(?:over|under|o/u|total|line)?\\s*([0-9]+(?:\\.[0-9]+)?)\\b`, "i"),
    new RegExp(`(?:大|小|大小|总数|盘口线?)\\s*([0-9]+(?:\\.[0-9]+)?)\\s*(?:张|个)?\\s*${unit}`, "i"),
    new RegExp(`${unit}\\s*(?:大|小|大小|总数|盘口线?)\\s*([0-9]+(?:\\.[0-9]+)?)`, "i"),
  ];
  const handicapPatterns = [
    new RegExp(`\\b${unit}\\s*(?:spread|handicap|line)\\s*([+-]?[0-9]+(?:\\.[0-9]+)?)\\b`, "i"),
    new RegExp(`\\b(?:spread|handicap|line)\\s*([+-]?[0-9]+(?:\\.[0-9]+)?)\\s*${unit}\\b`, "i"),
    new RegExp(`\\b(?:cover|covers?)\\s*([+-]?[0-9]+(?:\\.[0-9]+)?)\\s*${unit}\\b`, "i"),
    new RegExp(`${unit}\\s*(?:让球|让盘|让)\\s*([+-]?[0-9]+(?:\\.[0-9]+)?)`, "i"),
  ];
  const patterns = type === "handicap" ? handicapPatterns : totalPatterns;
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (!match) continue;
    const value = normalizeDerivativeLine(Math.abs(Number(match[1])), kind, type);
    if (Number.isFinite(value) && isDerivativeLineInRange(value, kind, type)) return value;
  }
  return null;
}

function normalizeDerivativeLine(value, kind, type) {
  const number = Math.abs(Number(value));
  if (!Number.isFinite(number)) return null;
  let normalized = number;
  if (!Number.isInteger(normalized * 2)) normalized = Math.round(normalized * 2) / 2;
  if (kind === "cards" && type === "total" && normalized < 2.5) return null;
  if (kind === "corners" && type === "total" && normalized < 6) return null;
  return Number(normalized.toFixed(1));
}

function isDerivativeLineInRange(value, kind, type) {
  const min = kind === "cards"
    ? type === "total" ? 2.5 : 0.5
    : type === "total" ? 6 : 0.5;
  const max = kind === "cards"
    ? type === "total" ? 9 : 4
    : type === "total" ? 16 : 5;
  return Number.isFinite(value) && value >= min && value <= max;
}

function medianLine(values) {
  const clean = values.filter((value) => Number.isFinite(value)).sort((a, b) => a - b);
  if (!clean.length) return null;
  const mid = Math.floor(clean.length / 2);
  const value = clean.length % 2 ? clean[mid] : (clean[mid - 1] + clean[mid]) / 2;
  return Number(value.toFixed(1));
}

async function fetchPinnacleDerivativeContext(match) {
  const key = pinnacleDerivativeCacheKey(match);
  const now = Date.now();
  const hit = cache.get(key);
  if (hit && hit.value && typeof hit.value === "object" && now - hit.created < DERIVATIVE_COVERAGE_REFRESH_MS) return hit.value;

  const cachedSnapshot = readCachedDerivativeMarketContext(match);
  let value;
  try {
    value = await (async () => {
      const matchups = await fetchPinnacleWorldCupMatchups();
      return buildPinnacleDerivativeContextFromMatchups(match, matchups);
    })();
  } catch (error) {
    if (cachedSnapshot.available) {
      const fallback = mergeDerivativeSourceContexts(match, [
        {
          available: false,
          source: "Pinnacle World Cup direct",
          label: "Pinnacle World Cup 直连",
          domain: "guest.api.arcadia.pinnacle.com",
          entries: [],
          errors: [error.message],
          message: `Pinnacle 实时抓取失败：${error.message}`,
        },
        cachedSnapshot,
      ]);
      cache.set(key, { created: now, value: fallback });
      return fallback;
    }
    throw error;
  }
  if (!value || typeof value !== "object") {
    if (cachedSnapshot.available) return cachedSnapshot;
    value = {
      available: false,
      source: "Pinnacle World Cup direct",
      label: "Pinnacle World Cup 直连",
      domain: "guest.api.arcadia.pinnacle.com",
      url: pinnacleLeagueMatchupsUrl(),
      entries: [],
      message: "Pinnacle 直连返回为空，下一次分析会自动重试",
    };
  }
  if (arrayFrom(value.entries).length) {
    saveDerivativeMarketSnapshot(match, value, { source: "Pinnacle World Cup 直连" });
  }
  const merged = mergeDerivativeSourceContexts(match, [value, cachedSnapshot]);
  const finalValue = merged.available ? merged : value;
  if (!value.partial || cachedSnapshot.available) {
    cache.set(key, { created: now, value: finalValue });
  }
  return finalValue;
}

function pinnacleDerivativeCacheKey(match) {
  const home = teamLookupKeys(match?.home?.name || match?.home?.displayName).sort().join("|") || normalizeTeamName(match?.home?.name);
  const away = teamLookupKeys(match?.away?.name || match?.away?.displayName).sort().join("|") || normalizeTeamName(match?.away?.name);
  return `pinnacle-derivative:${home}:${away}:${match?.dateInfo?.date || ""}`;
}

async function warmPinnacleDerivativeCoverage(matches) {
  const now = Date.now();
  if (derivativeCoverageState.status === "running") return derivativeCoverageState;
  if (derivativeCoverageState.status !== "error" && derivativeCoverageState.refreshedAt) {
    const last = Date.parse(derivativeCoverageState.refreshedAt);
    const incompleteCoverage = Number(derivativeCoverageState.totalMatches || 0) > 0
      && Number(derivativeCoverageState.completeMatches || 0) < Number(derivativeCoverageState.totalMatches || 0);
    const refreshMs = incompleteCoverage ? 60 * 1000 : DERIVATIVE_COVERAGE_REFRESH_MS;
    if (Number.isFinite(last) && now - last < refreshMs) return derivativeCoverageState;
  }

  const upcoming = arrayFrom(matches)
    .filter((match) => isMatchWithinNextWindow(match, now, DERIVATIVE_COVERAGE_WINDOW_MS))
    .slice(0, 16);

  derivativeCoverageState.status = "running";
  derivativeCoverageState.windowHours = Math.round(DERIVATIVE_COVERAGE_WINDOW_MS / 3600000);
  derivativeCoverageState.totalMatches = upcoming.length;
  derivativeCoverageState.coveredMatches = 0;
  derivativeCoverageState.cornerMatches = 0;
  derivativeCoverageState.cardMatches = 0;
  derivativeCoverageState.completeMatches = 0;
  derivativeCoverageState.directEntries = 0;
  derivativeCoverageState.errors = [];

  try {
    if (!upcoming.length) {
      derivativeCoverageState.status = "idle";
      derivativeCoverageState.refreshedAt = new Date().toISOString();
      return derivativeCoverageState;
    }

    const matchups = await fetchPinnacleWorldCupMatchups();
    let covered = 0;
    let cornerMatches = 0;
    let cardMatches = 0;
    let completeMatches = 0;
    let entries = 0;
    const errors = [];

    for (const match of upcoming) {
      try {
        const value = await buildPinnacleDerivativeContextFromMatchups(match, matchups);
        if (arrayFrom(value?.entries).length) {
          saveDerivativeMarketSnapshot(match, value, { source: "Pinnacle World Cup 直连预热" });
        }
        const cachedSnapshot = readCachedDerivativeMarketContext(match);
        const resolvedValue = mergeDerivativeSourceContexts(match, [value, cachedSnapshot]);
        if (resolvedValue && typeof resolvedValue === "object") {
          cache.set(pinnacleDerivativeCacheKey(match), { created: Date.now(), value: resolvedValue });
          if (arrayFrom(value?.errors).length) {
            errors.push(`${teamLabel(match.home)}-${teamLabel(match.away)}：${arrayFrom(value.errors).join("；")}`);
          }
          const directEntries = arrayFrom(resolvedValue.entries);
          const hasCorners = directEntries.some((entry) => entry.kind === "corners");
          const hasCards = directEntries.some((entry) => entry.kind === "cards");
          if (hasCorners) cornerMatches += 1;
          if (hasCards) cardMatches += 1;
          if (hasCorners && hasCards) completeMatches += 1;
          if (directEntries.length) {
            covered += 1;
            entries += directEntries.length;
          }
        }
      } catch (error) {
        errors.push(`${teamLabel(match.home)}-${teamLabel(match.away)}：${error.message}`);
      }
    }

    derivativeCoverageState.status = "ready";
    derivativeCoverageState.refreshedAt = new Date().toISOString();
    derivativeCoverageState.coveredMatches = covered;
    derivativeCoverageState.cornerMatches = cornerMatches;
    derivativeCoverageState.cardMatches = cardMatches;
    derivativeCoverageState.completeMatches = completeMatches;
    derivativeCoverageState.directEntries = entries;
    derivativeCoverageState.errors = errors.slice(0, 5);
    return derivativeCoverageState;
  } catch (error) {
    derivativeCoverageState.status = "error";
    derivativeCoverageState.refreshedAt = new Date().toISOString();
    derivativeCoverageState.errors = [error.message];
    return derivativeCoverageState;
  }
}

function isMatchWithinNextWindow(match, now, windowMs) {
  const start = matchStartMs(match);
  return Number.isFinite(start) && start >= now && start <= now + windowMs;
}

function matchStartMs(match) {
  const kickoffUtc = match?.kickoffUtc || match?.utcDate || "";
  if (kickoffUtc) {
    const kickoffMs = Date.parse(kickoffUtc);
    if (Number.isFinite(kickoffMs)) return kickoffMs;
  }
  const raw = match?.localDateRaw || match?.utcDate || "";
  if (hasExplicitTimeZone(raw)) {
    const rawMs = Date.parse(raw);
    if (Number.isFinite(rawMs)) return rawMs;
  }
  const localInfo = match?.venueDateInfo || match?.dateInfo || {};
  const date = localInfo.date;
  const time = localInfo.time || "00:00";
  const venueTimeZone = hostCityTimeZone(match?.stadium);
  const zonedMs = venueTimeZone ? zonedLocalTimeToUtcMs(date, time, venueTimeZone) : NaN;
  if (Number.isFinite(zonedMs)) return zonedMs;
  const utcMs = Date.parse(`${match?.dateInfo?.date || date}T${match?.dateInfo?.time || time}:00+08:00`);
  return Number.isFinite(utcMs) ? utcMs : NaN;
}

function hasExplicitTimeZone(value) {
  return /(?:z|utc|gmt|[+-]\d{2}:?\d{2})$/i.test(String(value || "").trim());
}

function hostCityTimeZone(venue = {}) {
  const key = hostCityKey(venue);
  if (["Mexico City", "Guadalajara", "Monterrey"].includes(key)) return "Etc/GMT+6";
  if (key && HOST_CITY_TIMEZONE[key]) return HOST_CITY_TIMEZONE[key];
  const text = normalizeTeamName(
    [
      venue.city,
      venue.city_en,
      venue.name,
      venue.name_en,
      venue.fifaName,
      venue.fifa_name,
      venue.label,
      venue.region,
      venue.country,
      venue.country_en,
    ]
      .filter(Boolean)
      .join(" ")
  );
  if (!text) return "";
  if (text.includes("vancouver")) return "America/Vancouver";
  if (text.includes("toronto")) return "America/Toronto";
  if (text.includes("guadalajara") || text.includes("zapopan") || text.includes("mexico city") || text.includes("azteca")) {
    return "Etc/GMT+6";
  }
  if (text.includes("monterrey")) return "Etc/GMT+6";
  if (text.includes("los angeles") || text.includes("inglewood") || text.includes("seattle") || text.includes("san francisco") || text.includes("santa clara")) {
    return "America/Los_Angeles";
  }
  if (text.includes("houston") || text.includes("dallas") || text.includes("arlington") || text.includes("kansas city")) {
    return "America/Chicago";
  }
  if (text.includes("new york") || text.includes("new jersey") || text.includes("east rutherford") || text.includes("boston") || text.includes("foxborough") || text.includes("philadelphia") || text.includes("atlanta") || text.includes("miami")) {
    return "America/New_York";
  }
  if (text.includes("western")) return "America/Los_Angeles";
  if (text.includes("central")) return "America/Chicago";
  if (text.includes("eastern")) return "America/New_York";
  return "";
}

function zonedLocalTimeToUtcMs(date, time, timeZone) {
  const dateMatch = String(date || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  const timeMatch = String(time || "").match(/^(\d{1,2}):(\d{2})/);
  if (!dateMatch || !timeMatch || !timeZone) return NaN;
  const [, yyyy, mm, dd] = dateMatch;
  const [, hh, min] = timeMatch;
  const localAsUtc = Date.UTC(Number(yyyy), Number(mm) - 1, Number(dd), Number(hh), Number(min), 0);
  let offset = timeZoneOffsetMs(timeZone, localAsUtc);
  if (!Number.isFinite(offset)) return NaN;
  let utc = localAsUtc - offset;
  const secondOffset = timeZoneOffsetMs(timeZone, utc);
  if (Number.isFinite(secondOffset) && secondOffset !== offset) {
    utc = localAsUtc - secondOffset;
  }
  return utc;
}

function timeZoneOffsetMs(timeZone, utcMs) {
  try {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone,
      hour12: false,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }).formatToParts(new Date(utcMs));
    const map = Object.fromEntries(parts.map((part) => [part.type, part.value]));
    const asUtc = Date.UTC(
      Number(map.year),
      Number(map.month) - 1,
      Number(map.day),
      Number(map.hour),
      Number(map.minute),
      Number(map.second)
    );
    return asUtc - utcMs;
  } catch {
    return NaN;
  }
}

async function buildPinnacleDerivativeContextFromMatchups(match, matchups) {
  const baseMatchup = findPinnacleBaseMatchup(matchups, match);
  if (!baseMatchup) {
    return {
      available: false,
      source: "Pinnacle World Cup direct",
      label: "Pinnacle World Cup 直连",
      domain: "guest.api.arcadia.pinnacle.com",
      url: pinnacleLeagueMatchupsUrl(),
      entries: [],
      message: "Pinnacle World Cup 暂未找到该场比赛的可匹配主盘口",
    };
  }

  const cornersMatchup = findPinnacleSpecialMatchup(matchups, baseMatchup, "corners");
  const bookingsMatchup = findPinnacleSpecialMatchup(matchups, baseMatchup, "cards");
  const [cornerResult, bookingResult] = await Promise.all([
    fetchPinnacleMarketsWithRetry(cornersMatchup),
    fetchPinnacleMarketsWithRetry(bookingsMatchup),
  ]);
  const entries = [
    buildPinnacleDerivativeEntry({ kind: "corners", match, baseMatchup, specialMatchup: cornersMatchup, markets: cornerResult.markets }),
    buildPinnacleDerivativeEntry({ kind: "cards", match, baseMatchup, specialMatchup: bookingsMatchup, markets: bookingResult.markets }),
  ].filter(Boolean);
  const fetchErrors = [cornerResult, bookingResult].filter((result) => result.error);

  return {
    available: entries.length > 0,
    partial: fetchErrors.length > 0,
    source: "Pinnacle World Cup direct",
    label: "Pinnacle World Cup 直连",
    domain: "guest.api.arcadia.pinnacle.com",
    url: pinnacleLeagueMatchupsUrl(),
    leagueId: PINNACLE_WORLD_CUP_LEAGUE_ID,
    matchedMatchupId: baseMatchup.id,
    matchedLabel: pinnacleParticipantsLabel(baseMatchup),
    entries,
    errors: fetchErrors.map((result) => result.error.message).slice(0, 2),
    message: entries.length
      ? `Pinnacle 已匹配 ${pinnacleParticipantsLabel(baseMatchup)}，采纳 ${entries.length} 条角球/Bookings 盘口${fetchErrors.length ? "；部分特殊盘将继续重试" : ""}`
      : "Pinnacle 找到主比赛，但暂未开放角球或 Bookings 特殊盘",
  };
}

async function fetchPinnacleWorldCupMatchups() {
  return cached("pinnacle-worldcup-matchups", 3 * 60 * 1000, async () => {
    const options = {
      headers: pinnacleHeaders(),
      timeout: 22000,
    };
    let json;
    try {
      json = await fetchJson(pinnacleLeagueMatchupsUrl(), options);
    } catch (error) {
      await delay(650);
      json = await fetchJson(pinnacleLeagueMatchupsUrl(), options);
    }
    return arrayFrom(json);
  });
}

async function fetchPinnacleMarketsForMatchup(matchupId) {
  const id = String(matchupId || "");
  if (!id) return [];
  return cached(`pinnacle-markets:${id}`, 90 * 1000, async () => {
    const url = `${PINNACLE_GUEST_API}/matchups/${encodeURIComponent(id)}/markets/straight?primaryOnly=false&withSpecials=true`;
    const json = await fetchJson(url, {
      headers: pinnacleHeaders(),
      timeout: 18000,
    });
    return arrayFrom(json);
  });
}

async function fetchPinnacleMarketsWithRetry(matchup) {
  if (!matchup?.id) return { attempted: false, markets: [], error: null };
  let lastError = null;
  const pauses = [0, 550, 1200];
  for (const pause of pauses) {
    if (pause) await delay(pause);
    try {
      return { attempted: true, markets: await fetchPinnacleMarketsForMatchup(matchup.id), error: null };
    } catch (error) {
      lastError = error;
    }
  }
  return { attempted: true, markets: [], error: lastError };
}

function pinnacleLeagueMatchupsUrl() {
  return `${PINNACLE_GUEST_API}/leagues/${PINNACLE_WORLD_CUP_LEAGUE_ID}/matchups?withSpecials=true&brandId=0`;
}

function pinnacleHeaders() {
  return {
    Accept: "application/json",
    "X-API-Key": PINNACLE_API_KEY,
  };
}

function findPinnacleBaseMatchup(matchups, match) {
  const homeKeys = teamLookupKeys(match?.home?.name);
  const awayKeys = teamLookupKeys(match?.away?.name);
  const targetDate = match?.dateInfo?.date || "";
  const candidates = arrayFrom(matchups)
    .filter((item) => !item.parentId && arrayFrom(item.participants).length === 2)
    .filter((item) => {
      const names = item.participants.map((participant) => cleanPinnacleParticipantName(participant.name));
      return (
        participantMatchesTeam(names[0], homeKeys) &&
        participantMatchesTeam(names[1], awayKeys)
      ) || (
        participantMatchesTeam(names[1], homeKeys) &&
        participantMatchesTeam(names[0], awayKeys)
      );
    })
    .map((item) => ({
      item,
      score: pinnacleDateScore(item, targetDate),
    }))
    .sort((a, b) => a.score - b.score);
  return candidates[0]?.item || null;
}

function findPinnacleSpecialMatchup(matchups, baseMatchup, kind) {
  if (!baseMatchup?.id) return null;
  const keyword = kind === "cards" ? /bookings?|cards?|yellow/i : /corners?/i;
  const baseNames = arrayFrom(baseMatchup.participants)
    .map((participant) => cleanPinnacleParticipantName(participant.name))
    .map((name) => normalizeTeamName(name))
    .filter(Boolean);
  return arrayFrom(matchups)
    .filter((item) => String(item.parentId || "") === String(baseMatchup.id))
    .map((item) => {
      const label = pinnacleParticipantsLabel(item);
      return {
        item,
        label,
        score: pinnacleSpecialMatchupScore(label, item, baseNames, kind, keyword),
      };
    })
    .filter((candidate) => candidate.score > 0)
    .sort((a, b) => b.score - a.score)[0]?.item || null;
}

function pinnacleSpecialMatchupScore(label, matchup, baseNames, kind, keyword) {
  const normalized = normalizeTeamName(label);
  if (!keyword.test(label)) return 0;
  let score = 1;
  const participantCount = arrayFrom(matchup.participants).length;
  const mentionsBothTeams = baseNames.length >= 2 && baseNames.every((name) => normalized.includes(name));
  if (mentionsBothTeams) score += 12;
  if (kind === "cards" && /\(bookings?\)/i.test(label)) score += 16;
  if (kind === "cards" && /\bbookings?\b/i.test(label)) score += 10;
  if (kind === "corners" && /\(corners?\)/i.test(label)) score += 16;
  if (kind === "corners" && /\bcorners?\b/i.test(label)) score += 10;
  if (participantCount === 2) score += 5;
  if (participantCount > 3) score -= 8;
  if (/player|to be carded|goalscorer|assist/i.test(label)) score -= 12;
  return score;
}

function buildPinnacleDerivativeEntry({ kind, match, baseMatchup, specialMatchup, markets }) {
  if (!specialMatchup || !arrayFrom(markets).length) return null;
  const openMarkets = arrayFrom(markets).filter((market) =>
    Number(market.period || 0) === 0 && (!market.status || String(market.status).toLowerCase() === "open")
  );
  const total = chooseBalancedMarket(openMarkets, "total");
  const spread = chooseBalancedMarket(openMarkets, "spread");
  const homeTeamTotal = chooseBalancedTeamTotal(openMarkets, "home");
  const awayTeamTotal = chooseBalancedTeamTotal(openMarkets, "away");
  if (!total && !spread && !homeTeamTotal && !awayTeamTotal) return null;

  const unitZh = kind === "cards" ? "罚牌/Bookings" : "角球";
  const totalUnitEn = kind === "cards" ? "cards" : "corners";
  const handicapUnitEn = kind === "cards" ? "bookings" : "corners";
  const homeName = match?.home?.name || pinnacleParticipantNameByAlignment(baseMatchup, "home");
  const awayName = match?.away?.name || pinnacleParticipantNameByAlignment(baseMatchup, "away");
  const homeZh = teamLabel(match?.home);
  const awayZh = teamLabel(match?.away);
  const parts = [`Pinnacle World Cup 直连${unitZh}盘口：${homeName} / ${awayName}（${homeZh} 对 ${awayZh}）`];

  if (total) {
    const line = marketPoint(total, "over") ?? marketPoint(total, "under");
    parts.push(`Over ${formatTotalLine(line)} ${totalUnitEn} ${formatPinnaclePrice(priceForDesignation(total, "over"))}，Under ${formatTotalLine(line)} ${totalUnitEn} ${formatPinnaclePrice(priceForDesignation(total, "under"))}`);
  }
  if (spread) {
    const homePoint = marketPoint(spread, "home");
    const awayPoint = marketPoint(spread, "away");
    parts.push(`${handicapUnitEn} spread ${formatSignedLine(homePoint)}：${homeName} ${formatPinnaclePrice(priceForDesignation(spread, "home"))} / ${awayName} ${formatSignedLine(awayPoint)} ${formatPinnaclePrice(priceForDesignation(spread, "away"))}`);
  }
  if (homeTeamTotal) {
    const line = marketPoint(homeTeamTotal, "over") ?? marketPoint(homeTeamTotal, "under");
    parts.push(`${homeName} team total ${totalUnitEn} Over ${formatTotalLine(line)} ${formatPinnaclePrice(priceForDesignation(homeTeamTotal, "over"))}`);
  }
  if (awayTeamTotal) {
    const line = marketPoint(awayTeamTotal, "over") ?? marketPoint(awayTeamTotal, "under");
    parts.push(`${awayName} team total ${totalUnitEn} Over ${formatTotalLine(line)} ${formatPinnaclePrice(priceForDesignation(awayTeamTotal, "over"))}`);
  }

  const url = `${PINNACLE_GUEST_API}/matchups/${specialMatchup.id}/markets/straight`;
  return {
    kind,
    side: "odds",
    domain: "guest.api.arcadia.pinnacle.com",
    url,
    groupLabel: "Pinnacle World Cup 直连",
    text: `${parts.join("。")}。`,
    matchupId: specialMatchup.id,
    totalLine: total ? marketPoint(total, "over") ?? marketPoint(total, "under") : null,
    handicapLine: spread ? Math.abs(marketPoint(spread, "home") ?? marketPoint(spread, "away") ?? 0) : null,
    capturedAt: new Date().toISOString(),
  };
}

function chooseBalancedMarket(markets, type) {
  return arrayFrom(markets)
    .filter((market) => market.type === type && arrayFrom(market.prices).length >= 2)
    .sort((a, b) => marketBalanceScore(a) - marketBalanceScore(b))[0] || null;
}

function chooseBalancedTeamTotal(markets, side) {
  return arrayFrom(markets)
    .filter((market) => market.type === "team_total" && market.side === side && arrayFrom(market.prices).length >= 2)
    .sort((a, b) => marketBalanceScore(a) - marketBalanceScore(b))[0] || null;
}

function marketBalanceScore(market) {
  if (market?.type === "spread") {
    return Math.abs(pinnacleAmericanToProbability(priceForDesignation(market, "home")) - pinnacleAmericanToProbability(priceForDesignation(market, "away")));
  }
  return Math.abs(pinnacleAmericanToProbability(priceForDesignation(market, "over")) - pinnacleAmericanToProbability(priceForDesignation(market, "under")));
}

function pinnacleAmericanToProbability(price) {
  const value = Number(price);
  if (!Number.isFinite(value) || value === 0) return 0.5;
  return value > 0 ? 100 / (value + 100) : Math.abs(value) / (Math.abs(value) + 100);
}

function priceForDesignation(market, designation) {
  const price = arrayFrom(market?.prices).find((item) => item.designation === designation);
  return Number.isFinite(Number(price?.price)) ? Number(price.price) : null;
}

function marketPoint(market, designation) {
  const price = arrayFrom(market?.prices).find((item) => item.designation === designation);
  return Number.isFinite(Number(price?.points)) ? Number(price.points) : null;
}

function formatPinnaclePrice(price) {
  const value = Number(price);
  if (!Number.isFinite(value)) return "";
  return value > 0 ? `+${value}` : String(value);
}

function formatSignedLine(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "--";
  return number > 0 ? `+${formatTotalLine(number)}` : formatTotalLine(number);
}

function pinnacleDateScore(matchup, targetDate) {
  if (!targetDate) return 0;
  const start = String(matchup.startTime || matchup.parent?.startTime || "").slice(0, 10);
  return start === targetDate ? 0 : 1;
}

function participantMatchesTeam(name, keys) {
  const normalized = normalizeTeamName(name);
  if (!normalized || normalized.length < 2) return false;
  return arrayFrom(keys).some((key) => normalized === key || normalized.includes(key) || key.includes(normalized));
}

function cleanPinnacleParticipantName(value) {
  return String(value || "")
    .replace(/\((?:corners?|bookings?|cards?|yellow cards?)\)/gi, "")
    .replace(/\([+-]?\d+(?:\.\d+)?\)/g, "")
    .replace(/\b(draw|neither|yes|no)\b/gi, "")
    .trim();
}

function pinnacleParticipantNameByAlignment(matchup, alignment) {
  return arrayFrom(matchup?.participants).find((participant) => participant.alignment === alignment)?.name || "";
}

function pinnacleParticipantsLabel(matchup) {
  return arrayFrom(matchup?.participants).map((participant) => participant.name).filter(Boolean).join(" / ");
}

function scoreVenueSignals(entries) {
  const venueEntries = entries.filter((entry) => entry.side === "venue");
  const text = venueEntries.map((entry) => entry.text || "").join(" ").toLowerCase();
  return {
    roofScore: countMatches(text, /roof|retractable|dome|indoor|covered|屋顶|穹顶/g),
    naturalGrassScore: countMatches(text, /grass|natural grass|草皮|天然草/g),
    turfScore: countMatches(text, /artificial|turf|synthetic|人造草/g),
    evidence: venueEntries.slice(0, 5).map((entry) => ({
      text: selectEvidenceSentence(entry.text || "", ["roof", "pitch", "grass", "surface", "weather", "altitude"]),
      url: entry.url,
      domain: entry.domain,
    })),
  };
}

async function fetchOdds(match, oddsKey) {
  if (!oddsKey) {
    return {
      enabled: false,
      available: false,
      message: "未配置 The Odds API Key。仍会展示网页搜索到的盘口/推荐信息。",
      markets: [],
    };
  }

  try {
    const primary = await fetchOddsApiEvents(oddsKey, ODDS_API_EXTENDED_MARKETS).catch(async (error) => {
      const fallback = await fetchOddsApiEvents(oddsKey, ODDS_API_CORE_MARKETS);
      fallback.warning = `扩展盘口请求失败，已回落核心盘口：${error.message}`;
      return fallback;
    });
    const { events, url, marketsRequested, warning } = primary;
    const event = findOddsEvent(events, match);
    if (!event) {
      return {
        enabled: true,
        available: false,
        message: "赔率 API 可用，但暂未匹配到这场比赛。",
        source: url.replace(oddsKey, "REDACTED"),
        marketsRequested,
        warning,
        markets: [],
      };
    }

    const markets = summarizeOddsEvent(event, match);
    return {
      enabled: true,
      available: true,
      event: {
        id: event.id,
        commenceTime: event.commence_time,
        homeTeam: event.home_team,
        awayTeam: event.away_team,
      },
      markets,
      source: url.replace(oddsKey, "REDACTED"),
      marketsRequested,
      warning,
    };
  } catch (error) {
    return {
      enabled: true,
      available: false,
      message: error.message,
      markets: [],
    };
  }
}

async function fetchOddsApiEvents(oddsKey, markets) {
  const params = new URLSearchParams({
    apiKey: oddsKey,
    regions: process.env.ODDS_API_REGIONS || "us,uk,eu,au",
    markets,
    oddsFormat: "decimal",
    dateFormat: "iso",
  });
  const url = `https://api.the-odds-api.com/v4/sports/${ODDS_SPORT_KEY}/odds/?${params.toString()}`;
  const events = await fetchJson(url, { timeout: 18000 });
  return { events, url, marketsRequested: markets };
}

function findOddsEvent(events, match) {
  if (!Array.isArray(events)) return null;
  const home = normalizeTeamName(match.home.name);
  const away = normalizeTeamName(match.away.name);
  return (
    events.find((event) => {
      const teams = [event.home_team, event.away_team].map(normalizeTeamName);
      return teams.includes(home) && teams.includes(away);
    }) || null
  );
}

function summarizeOddsEvent(event, match) {
  const home = normalizeTeamName(match.home.name);
  const away = normalizeTeamName(match.away.name);
  const marketMap = new Map();

  for (const bookmaker of event.bookmakers || []) {
    for (const market of bookmaker.markets || []) {
      const bucket = marketMap.get(market.key) || [];
      for (const outcome of market.outcomes || []) {
        bucket.push({
          bookmaker: bookmaker.title,
          name: outcome.name,
          normalizedName: normalizeTeamName(outcome.name),
          price: Number(outcome.price),
          point: typeof outcome.point === "number" ? outcome.point : null,
        });
      }
      marketMap.set(market.key, bucket);
    }
  }

  return [...marketMap.entries()].map(([key, outcomes]) => {
    if (key === "h2h") {
      const homePrices = outcomes.filter((o) => o.normalizedName === home).map((o) => o.price);
      const awayPrices = outcomes.filter((o) => o.normalizedName === away).map((o) => o.price);
      const drawPrices = outcomes.filter((o) => /draw/i.test(o.name)).map((o) => o.price);
      return {
        key,
        label: "胜平负",
        homeAvg: average(homePrices),
        drawAvg: average(drawPrices),
        awayAvg: average(awayPrices),
        books: outcomes.length,
      };
    }

    const lines = outcomes.slice(0, 12).map((o) => ({
      bookmaker: o.bookmaker,
      name: o.name,
      price: o.price,
      point: o.point,
    }));
    return {
      key,
      label: key === "spreads" ? "让球" : key === "totals" ? "大小球" : key,
      lines,
      books: outcomes.length,
    };
  });
}

function fifaRankingImpact(fifa) {
  const home = fifa?.teams?.home;
  const away = fifa?.teams?.away;
  if (!home?.rank || !away?.rank) {
    return { available: false, diff: 0, detail: "" };
  }
  const rankDiff = away.rank - home.rank;
  const pointsDiff = (home.points ?? 1500) - (away.points ?? 1500);
  const diff = clamp(rankDiff * 0.012 + pointsDiff * 0.0012, -0.95, 0.95);
  return {
    available: true,
    diff: Number(diff.toFixed(3)),
    detail: `${home.name} 排名 ${home.rank}（${home.points ?? "--"} 分），${away.name} 排名 ${away.rank}（${away.points ?? "--"} 分）；排名差 ${Math.abs(rankDiff)} 位、积分差 ${Math.abs(pointsDiff).toFixed(1)}。`,
  };
}

function marketGoalDiffFromProbabilities(homeProb, awayProb) {
  const home = clamp(homeProb, 0.02, 0.98);
  const away = clamp(awayProb, 0.02, 0.98);
  const edge = home - away;
  if (Math.abs(edge) < 0.01) return 0;
  const favoriteProb = clamp(Math.max(home, away), 0.5, 0.98);
  return Number((Math.sign(edge) * clamp(logit(favoriteProb) * 0.52, 0.1, 1.9)).toFixed(3));
}

function buildEspnMarketProfile(espnOdds) {
  const implied = clamp(espnOdds.favorite?.implied, 0.5, 0.985);
  const side = espnOdds.favorite?.side || "unknown";
  const totalLine = espnOdds.total?.line ?? espnOdds.overUnder;
  const spreadLine = espnOdds.spread?.line;
  const spreadBoost = Number.isFinite(spreadLine) && spreadLine >= 3 ? 0.18 : 0;
  const goalDiff = clamp(logit(implied) * 0.52 + spreadBoost, 0.12, 2.35);
  let strength = "normal";
  let label = "普通热门盘";
  let favoriteMinXg = 1.45;
  let underdogMaxXg = 1.25;

  if (implied >= 0.9) {
    strength = "extreme";
    label = "极端热门盘";
    favoriteMinXg = totalLine && totalLine >= 4.5 ? 3.35 : totalLine && totalLine >= 4 ? 3.05 : 2.65;
    underdogMaxXg = Number.isFinite(spreadLine) && spreadLine >= 3.5 ? 0.48 : 0.55;
  } else if (implied >= 0.78) {
    strength = "strong";
    label = "强热门盘";
    favoriteMinXg = totalLine && totalLine >= 3.5 ? 2.45 : 2.1;
    underdogMaxXg = 0.85;
  } else if (implied >= 0.66) {
    strength = "lean";
    label = "明显热门盘";
    favoriteMinXg = 1.75;
    underdogMaxXg = 1.1;
  }

  return {
    side,
    implied,
    strength,
    label,
    goalDiff: Number(goalDiff.toFixed(3)),
    favoriteMinXg,
    underdogMaxXg,
    totalLine,
    spreadLine,
  };
}

async function getSportteryContext(match) {
  const officialMatches = await fetchSportteryMatches();
  const officialMatch = findSportteryMatch(match, officialMatches);
  if (!officialMatch) {
    return unavailableSporttery("中国体彩网/竞彩网当前受注赛程中未匹配到该场比赛");
  }
  return {
    available: true,
    source: "中国体彩网/竞彩网",
    url: SPORTTERY_PAGE,
    officialMatchId: officialMatch.matchId,
    matchNum: officialMatch.matchNumStr || officialMatch.matchNum || "",
    updateTime: officialMatch.updateTime || "",
    match: officialMatch,
    markets: officialMatch.markets,
    message: "已匹配中国体彩网/竞彩网官方受注数据",
  };
}

function unavailableSporttery(message = "暂无体彩官方数据") {
  return {
    available: false,
    source: "中国体彩网/竞彩网",
    url: SPORTTERY_PAGE,
    officialMatchId: "",
    matchNum: "",
    updateTime: "",
    markets: {},
    message,
  };
}

async function fetchSportteryMatches() {
  return cached("sporttery-football-calculator", 2 * 60 * 1000, async () => {
    const params = new URLSearchParams({
      channel: "c",
      poolCode: SPORTTERY_POOL_CODE,
    });
    const json = await fetchJson(`${SPORTTERY_API}?${params.toString()}`, {
      timeout: 18000,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
        Referer: SPORTTERY_PAGE,
        Origin: "https://www.sporttery.cn",
        Accept: "application/json,text/plain,*/*",
      },
    });
    if (String(json.errorCode) !== "0") {
      throw new Error(json.errorMessage || "中国体彩网/竞彩网接口返回异常");
    }
    return arrayFrom(json.value?.matchInfoList)
      .flatMap((group) => arrayFrom(group.subMatchList).map((item) => normalizeSportteryMatch(item, group)))
      .filter(Boolean);
  });
}

function normalizeSportteryMatch(item, group = {}) {
  const markets = {
    result: normalizeSportteryResultMarket(item.had, "HAD"),
    handicap: normalizeSportteryResultMarket(item.hhad, "HHAD"),
    totalGoals: normalizeSportteryTotalGoalsMarket(item.ttg),
    score: normalizeSportteryScoreMarket(item.crs),
  };
  const updateTime = [
    markets.result?.updateTime,
    markets.handicap?.updateTime,
    markets.totalGoals?.updateTime,
    markets.score?.updateTime,
  ].filter(Boolean).sort().at(-1) || "";
  return {
    matchId: String(item.matchId || ""),
    businessDate: item.businessDate || group.businessDate || "",
    matchDate: item.matchDate || "",
    matchTime: item.matchTime || "",
    matchNum: String(item.matchNum || ""),
    matchNumStr: item.matchNumStr || "",
    matchNumDate: item.matchNumDate || "",
    leagueName: item.leagueAllName || item.leagueAbbName || "",
    status: item.matchStatus || "",
    updateTime,
    home: {
      code: item.homeTeamCode || item.homeTeamAbbEnName || "",
      name: item.homeTeamAllName || item.homeTeamAbbName || "",
      abbr: item.homeTeamAbbName || "",
      en: item.homeTeamAbbEnName || "",
      rank: item.homeRank || "",
    },
    away: {
      code: item.awayTeamCode || item.awayTeamAbbEnName || "",
      name: item.awayTeamAllName || item.awayTeamAbbName || "",
      abbr: item.awayTeamAbbName || "",
      en: item.awayTeamAbbEnName || "",
      rank: item.awayRank || "",
    },
    markets,
    raw: {
      poolCodes: arrayFrom(item.poolList).map((pool) => pool.poolCode).filter(Boolean),
    },
  };
}

function normalizeSportteryResultMarket(raw = {}, poolCode = "") {
  const odds = {
    home: numberOrNull(raw.h),
    draw: numberOrNull(raw.d),
    away: numberOrNull(raw.a),
  };
  const available = Object.values(odds).some((value) => Number.isFinite(value) && value > 0);
  return {
    available,
    poolCode,
    line: numberOrNull(raw.goalLineValue || raw.goalLine),
    odds,
    updateTime: [raw.updateDate, raw.updateTime].filter(Boolean).join(" "),
  };
}

function normalizeSportteryTotalGoalsMarket(raw = {}) {
  const odds = {};
  for (let i = 0; i <= 7; i += 1) {
    odds[String(i)] = numberOrNull(raw[`s${i}`]);
  }
  return {
    available: Object.values(odds).some((value) => Number.isFinite(value) && value > 0),
    poolCode: "TTG",
    odds,
    updateTime: [raw.updateDate, raw.updateTime].filter(Boolean).join(" "),
  };
}

function normalizeSportteryScoreMarket(raw = {}) {
  const odds = {};
  for (const [key, value] of Object.entries(raw || {})) {
    if (!/^s(?:\d{2}s\d{2}|1s[had])$/.test(key)) continue;
    odds[key] = numberOrNull(value);
  }
  return {
    available: Object.values(odds).some((value) => Number.isFinite(value) && value > 0),
    poolCode: "CRS",
    odds,
    updateTime: [raw.updateDate, raw.updateTime].filter(Boolean).join(" "),
  };
}

function findSportteryMatch(match, officialMatches) {
  const homeKeys = sportteryTeamKeys(match.home);
  const awayKeys = sportteryTeamKeys(match.away);
  const matchDate = match?.dateInfo?.date || "";
  const scored = arrayFrom(officialMatches)
    .map((item) => {
      const homeOk = sportteryKeysIntersect(homeKeys, sportteryTeamKeys(item.home));
      const awayOk = sportteryKeysIntersect(awayKeys, sportteryTeamKeys(item.away));
      if (!homeOk || !awayOk) return null;
      const dateDelta = sportteryDateDeltaDays(matchDate, item.matchDate || item.businessDate);
      const dateScore = dateDelta === 0 ? 6 : dateDelta === 1 ? 3 : matchDate ? 0 : 1;
      const leagueScore = /世界杯|world cup/i.test(item.leagueName || "") ? 2 : 0;
      return { item, score: 20 + dateScore + leagueScore };
    })
    .filter(Boolean)
    .sort((a, b) => b.score - a.score);
  return scored[0]?.item || null;
}

function sportteryTeamKeys(team = {}) {
  const raw = [
    team.code,
    team.en,
    team.name,
    team.displayName,
    team.abbr,
    teamLabel(team),
    TEAM_NAME_ZH[normalizeSportteryTeamCode(team.code || team.en || "")],
  ];
  const keys = new Set();
  for (const value of raw) {
    const code = normalizeCountryCode(value);
    const canonicalCode = normalizeSportteryTeamCode(value);
    if (/^[A-Z]{2,4}$/.test(code)) keys.add(`code:${code}`);
    if (/^[A-Z]{2,4}$/.test(canonicalCode)) {
      keys.add(`code:${canonicalCode}`);
      const canonicalName = TEAM_NAME_ZH[canonicalCode];
      if (canonicalName) keys.add(`text:${normalizeSportteryTextKey(canonicalName)}`);
    }
    const latin = normalizeTeamName(value);
    if (latin) {
      keys.add(`latin:${latin}`);
      for (const alias of teamLookupKeys(value)) keys.add(`latin:${alias}`);
    }
    const text = normalizeSportteryTextKey(value);
    if (text) keys.add(`text:${text}`);
  }
  return [...keys];
}

function normalizeSportteryTeamCode(value) {
  const code = normalizeCountryCode(value);
  return SPORTTERY_TEAM_CODE_ALIASES[code] || code;
}

function normalizeSportteryTextKey(value) {
  return String(value || "")
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "")
    .trim();
}

function sportteryKeysIntersect(a, b) {
  const set = new Set(a);
  return b.some((key) => set.has(key));
}

function sportteryDateDeltaDays(left, right) {
  if (!left || !right) return Infinity;
  const a = Date.parse(`${left}T00:00:00Z`);
  const b = Date.parse(`${String(right).slice(0, 10)}T00:00:00Z`);
  if (!Number.isFinite(a) || !Number.isFinite(b)) return Infinity;
  return Math.abs(Math.round((a - b) / 86400000));
}

function buildSportteryRecommendation({ match, sporttery, probabilities, primaryScore, scorePortfolio, matrix }) {
  if (!sporttery?.available) {
    return buildModelSportteryRecommendation({ match, sporttery, probabilities, primaryScore, scorePortfolio, matrix });
    return {
      available: false,
      source: "中国体彩网/竞彩网",
      message: sporttery?.message || "暂无体彩官方数据",
      items: [],
    };
  }
  const official = sporttery.match || {};
  const markets = sporttery.markets || official.markets || {};
  const anchor = buildSportteryAnchor({ probabilities, primaryScore, scorePortfolio, markets });
  const items = [
    buildSportteryResultPick({ match, probabilities, market: markets.result, anchor }),
    buildSportteryHandicapPick({ match, matrix, market: markets.handicap, anchor }),
    buildSportteryTotalGoalsPick({ matrix, market: markets.totalGoals, anchor }),
    buildSportteryScorePick({ primaryScore, scorePortfolio, market: markets.score, anchor }),
  ].filter(Boolean);
  const alignment = validateSportteryAlignment({ items, anchor });
  return {
    available: true,
    source: "中国体彩网/竞彩网",
    url: SPORTTERY_PAGE,
    logicVersion: "sporttery-anchor-v2",
    officialMatchId: sporttery.officialMatchId || official.matchId || "",
    matchNum: sporttery.matchNum || official.matchNumStr || "",
    updateTime: sporttery.updateTime || official.updateTime || "",
    officialMatch: {
      home: official.home?.name || "",
      away: official.away?.name || "",
      leagueName: official.leagueName || "",
      matchDate: official.matchDate || "",
      matchTime: official.matchTime || "",
    },
    items,
    alignment,
    message: alignment.ok
      ? `已按统一比分锚点 ${anchor.score} 对齐胜平负、让球、总进球数和比分`
      : `体彩推荐已生成，但仍需人工复核：${alignment.issues.join("；")}`,
  };
}

function buildModelSportteryRecommendation({ match, sporttery, probabilities, primaryScore, scorePortfolio, matrix }) {
  const anchor = buildSportteryAnchor({ probabilities, primaryScore, scorePortfolio, markets: {} });
  const handicapLine = modelSportteryHandicapLine(anchor, probabilities);
  anchor.handicapLine = handicapLine;
  anchor.handicapSide = sportteryHandicapSide(anchor.homeGoals, anchor.awayGoals, handicapLine);
  const resultOptions = [
    { side: "home", probability: probabilities.homeWin || 0 },
    { side: "draw", probability: probabilities.draw || 0 },
    { side: "away", probability: probabilities.awayWin || 0 },
  ];
  const handicapDistribution = sportteryHandicapDistribution(matrix, handicapLine);
  const handicapOptions = [
    { side: "home", probability: handicapDistribution.home },
    { side: "draw", probability: handicapDistribution.draw },
    { side: "away", probability: handicapDistribution.away },
  ];
  const totalDistribution = sportteryTotalGoalsDistribution(matrix);
  const totalOptions = Object.entries(totalDistribution).map(([bucket, probability]) => ({
    side: bucket,
    probability,
  }));
  const totalPick = totalOptions.find((item) => item.side === anchor.totalGoals) ||
    totalOptions.sort((a, b) => b.probability - a.probability)[0] ||
    { side: anchor.totalGoals || "0", probability: 0 };
  const scoreProbability = Number(anchor.probability || 0);
  const items = [
    sportteryPickItem({
      marketKey: "result",
      market: "胜平负",
      pick: sportteryResultLabel(anchor.resultSide, match),
      side: anchor.resultSide,
      probability: sportteryResultProbability(probabilities, anchor.resultSide),
      odds: null,
      confidence: confidenceLabel(sportteryProbabilityEdge({ side: anchor.resultSide, probability: sportteryResultProbability(probabilities, anchor.resultSide) }, resultOptions)),
      reason: `官方体彩暂未匹配，使用统一比分锚点 ${anchor.score} 推导胜平负方向；该项为模型参考，不等同于官方固定奖金。`,
    }),
    sportteryPickItem({
      marketKey: "handicap",
      market: "让球胜平负",
      pick: sportteryHandicapResultLabel(anchor.handicapSide, handicapLine, match),
      side: anchor.handicapSide,
      line: handicapLine,
      probability: (handicapOptions.find((item) => item.side === anchor.handicapSide) || {}).probability || 0,
      odds: null,
      confidence: confidenceLabel(sportteryProbabilityEdge({ side: anchor.handicapSide, probability: (handicapOptions.find((item) => item.side === anchor.handicapSide) || {}).probability || 0 }, handicapOptions)),
      reason: `官方让球盘暂未匹配，按模型基准线 ${formatSignedLine(handicapLine)} 与比分锚点 ${anchor.score} 推导让球方向。`,
    }),
    sportteryPickItem({
      marketKey: "totalGoals",
      market: "总进球数",
      pick: `${sportteryTotalGoalsLabel(totalPick.side)}球`,
      side: totalPick.side,
      totalGoals: totalPick.side,
      probability: totalPick.probability,
      odds: null,
      confidence: confidenceLabel(sportteryProbabilityEdge(totalPick, totalOptions)),
      reason: `官方总进球玩法暂未匹配，按比分锚点 ${anchor.score} 的总进球 ${anchor.totalGoalCount} 球推导。`,
    }),
    sportteryPickItem({
      marketKey: "score",
      market: "比分",
      pick: sportteryScoreLabel(anchor.scoreKey, anchor.score),
      side: anchor.scoreKey,
      scoreKey: anchor.scoreKey,
      score: anchor.score,
      probability: scoreProbability,
      odds: null,
      confidence: confidenceLabel(scoreProbability),
      reason: `比分项直接使用当前统一锚点 ${anchor.score}，并与胜平负、让球、总进球数保持同一结算口径。`,
    }),
  ];
  const alignment = validateSportteryAlignment({ items, anchor });
  return {
    available: true,
    modelFallback: true,
    source: "模型体彩建议（官方暂未匹配）",
    url: SPORTTERY_PAGE,
    logicVersion: "sporttery-model-fallback-v1",
    officialMatchId: "",
    matchNum: "模型",
    updateTime: "",
    officialMatch: {
      home: teamLabel(match.home),
      away: teamLabel(match.away),
      leagueName: "官方受注未匹配",
      matchDate: match.dateInfo?.date || "",
      matchTime: match.dateInfo?.time || "",
    },
    items,
    alignment,
    message: `${sporttery?.message || "官方体彩数据暂未匹配"}；已使用模型体彩建议临时补齐四项推荐，待官方受注数据可用后自动覆盖。`,
  };
}

function modelSportteryHandicapLine(anchor, probabilities = {}) {
  const homeWin = Number(probabilities.homeWin || 0);
  const awayWin = Number(probabilities.awayWin || 0);
  const diff = Number(anchor?.homeGoals || 0) - Number(anchor?.awayGoals || 0);
  if (diff >= 2 || homeWin - awayWin >= 0.25 || homeWin >= 0.58) return -1;
  if (diff <= -2 || awayWin - homeWin >= 0.25 || awayWin >= 0.58) return 1;
  return diff >= 0 ? -1 : 1;
}

function buildSportteryAnchor({ probabilities, primaryScore, scorePortfolio, markets = {} }) {
  const candidates = buildSportteryAnchorCandidates({ primaryScore, scorePortfolio, scoreMarket: markets.score });
  const fallback = candidates[0] || makeSportteryAnchorCandidate({ score: "0-0", homeGoals: 0, awayGoals: 0, probability: 0 }, markets.score);
  const strongest = strongestSportteryResult(probabilities);
  const primarySideProbability = sportteryResultProbability(probabilities, fallback.resultSide);
  const shouldFollowAggregate =
    strongest.side !== fallback.resultSide &&
    strongest.probability >= 0.36 &&
    strongest.probability - primarySideProbability >= 0.045;
  const preferredSide = shouldFollowAggregate ? strongest.side : fallback.resultSide;
  const preferred = chooseSportteryAnchorCandidate(candidates, preferredSide) || fallback;
  const line = Number(markets.handicap?.line);
  const homeGoals = Number(preferred.homeGoals);
  const awayGoals = Number(preferred.awayGoals);
  return {
    ...preferred,
    homeGoals,
    awayGoals,
    score: preferred.score || `${homeGoals}-${awayGoals}`,
    scoreKey: sportteryScoreKey(homeGoals, awayGoals),
    resultSide: scoreDirection({ home: homeGoals, away: awayGoals }),
    totalGoals: sportteryTotalGoalsBucket(homeGoals + awayGoals),
    totalGoalCount: homeGoals + awayGoals,
    handicapLine: Number.isFinite(line) ? line : null,
    handicapSide: Number.isFinite(line) ? sportteryHandicapSide(homeGoals, awayGoals, line) : null,
    aggregateSide: strongest.side,
    aggregateProbability: strongest.probability,
    switchedFromPrimary: Boolean(fallback.score && preferred.score && fallback.score !== preferred.score),
    primaryScore: fallback.score || "",
    switchReason: shouldFollowAggregate
      ? `胜平负聚合概率更支持${sportteryResultName(strongest.side)}方向`
      : "沿用当前最高一致性比分",
  };
}

function buildSportteryAnchorCandidates({ primaryScore, scorePortfolio, scoreMarket = {} }) {
  const seen = new Set();
  const raw = [...arrayFrom(scorePortfolio), primaryScore].filter(Boolean);
  return raw
    .map((item) => makeSportteryAnchorCandidate(item, scoreMarket))
    .filter((item) => item && !seen.has(item.score) && seen.add(item.score));
}

function makeSportteryAnchorCandidate(item = {}, scoreMarket = {}) {
  const parsed = parseScoreText(item.score);
  const homeGoals = Number.isFinite(Number(item.homeGoals)) ? Number(item.homeGoals) : parsed.home;
  const awayGoals = Number.isFinite(Number(item.awayGoals)) ? Number(item.awayGoals) : parsed.away;
  if (!Number.isFinite(homeGoals) || !Number.isFinite(awayGoals)) return null;
  const score = item.score || `${homeGoals}-${awayGoals}`;
  const scoreKey = sportteryScoreKey(homeGoals, awayGoals);
  const odds = scoreMarket?.odds?.[scoreKey];
  return {
    score,
    homeGoals,
    awayGoals,
    scoreKey,
    resultSide: scoreDirection({ home: homeGoals, away: awayGoals }),
    probability: Number(item.probability || 0),
    rawProbability: Number(item.rawProbability || item.probability || 0),
    odds,
    hasOfficialOdds: Number.isFinite(Number(odds)),
    calibrationNote: item.calibrationNote || "",
  };
}

function chooseSportteryAnchorCandidate(candidates, preferredSide) {
  const sameSide = arrayFrom(candidates).filter((item) => item.resultSide === preferredSide);
  return sameSide.find((item) => item.hasOfficialOdds) || sameSide[0] || candidates.find((item) => item.hasOfficialOdds) || candidates[0];
}

function strongestSportteryResult(probabilities = {}) {
  const options = [
    { side: "home", probability: sportteryResultProbability(probabilities, "home") },
    { side: "draw", probability: sportteryResultProbability(probabilities, "draw") },
    { side: "away", probability: sportteryResultProbability(probabilities, "away") },
  ].sort((a, b) => b.probability - a.probability);
  return {
    ...options[0],
    edge: options[0].probability - (options[1]?.probability || 0),
    options,
  };
}

function sportteryResultProbability(probabilities = {}, side) {
  if (side === "home") return Number(probabilities.homeWin || 0);
  if (side === "away") return Number(probabilities.awayWin || 0);
  return Number(probabilities.draw || 0);
}

function sportteryResultName(side) {
  if (side === "home") return "主胜";
  if (side === "away") return "客胜";
  return "平局";
}

function sportteryProbabilityEdge(pick, options) {
  const probability = Number(typeof pick === "object" ? pick?.probability : pick);
  const side = typeof pick === "object" ? pick?.side : "";
  const others = arrayFrom(options).filter((item) => (side ? item.side !== side : Number(item.probability) !== probability));
  const next = others.reduce((max, item) => Math.max(max, Number(item.probability || 0)), 0);
  return Number(probability || 0) - next;
}

function buildSportteryResultPick({ match, probabilities, market = {}, anchor }) {
  if (!market.available) return sportteryWatchItem("result", "胜平负", "官方胜平负未开放");
  const side = anchor?.resultSide || strongestSportteryResult(probabilities).side;
  const options = [
    { side: "home", probability: probabilities.homeWin || 0, odds: market.odds?.home },
    { side: "draw", probability: probabilities.draw || 0, odds: market.odds?.draw },
    { side: "away", probability: probabilities.awayWin || 0, odds: market.odds?.away },
  ];
  const pick = options.find((item) => item.side === side) || options.sort((a, b) => b.probability - a.probability)[0];
  const strongest = [...options].sort((a, b) => b.probability - a.probability)[0];
  const alignmentNote = strongest.side === pick.side
    ? "该方向也是胜平负聚合概率最高项。"
    : `为避免与比分锚点 ${anchor?.score || "--"} 冲突，胜平负已按比分方向降级展示。`;
  return sportteryPickItem({
    marketKey: "result",
    market: "胜平负",
    pick: sportteryResultLabel(pick.side, match),
    side: pick.side,
    probability: pick.probability,
    odds: pick.odds,
    confidence: confidenceLabel(sportteryProbabilityEdge(pick, options)),
    reason: `按统一比分锚点 ${anchor?.score || "--"} 推出${sportteryResultLabel(pick.side, match)}，该方向模型概率 ${formatProbabilityPercent(pick.probability)}，官方固定奖金 ${formatOdds(pick.odds)}。${alignmentNote}`,
  });
}

function buildSportteryHandicapPick({ match, matrix, market = {}, anchor }) {
  const line = Number(market.line);
  if (!market.available || !Number.isFinite(line)) return sportteryWatchItem("handicap", "让球胜平负", "官方让球胜平负未开放");
  const distribution = sportteryHandicapDistribution(matrix, line);
  const options = [
    { side: "home", probability: distribution.home, odds: market.odds?.home },
    { side: "draw", probability: distribution.draw, odds: market.odds?.draw },
    { side: "away", probability: distribution.away, odds: market.odds?.away },
  ];
  const side = anchor?.handicapSide || sportteryHandicapSide(anchor?.homeGoals, anchor?.awayGoals, line);
  const pick = options.find((item) => item.side === side) || options.sort((a, b) => b.probability - a.probability)[0];
  return sportteryPickItem({
    marketKey: "handicap",
    market: "让球胜平负",
    pick: sportteryHandicapResultLabel(pick.side, line, match),
    side: pick.side,
    line,
    probability: pick.probability,
    odds: pick.odds,
    confidence: confidenceLabel(sportteryProbabilityEdge(pick, options)),
    reason: `同一比分锚点 ${anchor?.score || "--"} 按官方主队让球 ${formatSignedLine(line)} 结算为${sportteryHandicapResultLabel(pick.side, line, match)}；模型整盘该方向概率 ${formatProbabilityPercent(pick.probability)}，固定奖金 ${formatOdds(pick.odds)}。`,
  });
}

function buildSportteryTotalGoalsPick({ matrix, market = {}, anchor }) {
  if (!market.available) return sportteryWatchItem("totalGoals", "总进球数", "官方总进球数未开放");
  const distribution = sportteryTotalGoalsDistribution(matrix);
  const options = Object.entries(distribution)
    .map(([bucket, probability]) => ({ side: bucket, totalGoals: bucket, probability, odds: market.odds?.[bucket] }));
  const side = anchor?.totalGoals || options.sort((a, b) => b.probability - a.probability)[0]?.side;
  const pick = options.find((item) => item.side === side) || options.sort((a, b) => b.probability - a.probability)[0];
  return sportteryPickItem({
    marketKey: "totalGoals",
    market: "总进球数",
    pick: `${sportteryTotalGoalsLabel(pick.side)}球`,
    side: pick.side,
    totalGoals: pick.side,
    probability: pick.probability,
    odds: pick.odds,
    confidence: confidenceLabel(sportteryProbabilityEdge(pick, options)),
    reason: `同一比分锚点 ${anchor?.score || "--"} 的总进球为 ${anchor?.totalGoalCount ?? "--"}，对应官方总进球数 ${sportteryTotalGoalsLabel(pick.side)}球；模型该桶概率 ${formatProbabilityPercent(pick.probability)}，固定奖金 ${formatOdds(pick.odds)}。`,
  });
}

function buildSportteryScorePick({ primaryScore, scorePortfolio, market = {}, anchor }) {
  if (!market.available) return sportteryWatchItem("score", "比分", "官方比分玩法未开放");
  const top = anchor || primaryScore || arrayFrom(scorePortfolio)[0] || {};
  const home = Number(top.homeGoals);
  const away = Number(top.awayGoals);
  const scoreKey = sportteryScoreKey(home, away);
  const otherBest = arrayFrom(scorePortfolio)
    .filter((item) => item?.score !== top.score)
    .reduce((max, item) => Math.max(max, Number(item.probability || 0)), 0);
  const switchNote = top.switchedFromPrimary
    ? `原最高单比分 ${top.primaryScore} 与胜平负聚合方向不一致，已切换到同方向候选比分，避免体彩四项互相冲突。`
    : "该比分为当前锚点，体彩四项均按它结算。";
  return sportteryPickItem({
    marketKey: "score",
    market: "比分",
    pick: sportteryScoreLabel(scoreKey, top.score || `${home}-${away}`),
    side: scoreKey,
    scoreKey,
    score: top.score || `${home}-${away}`,
    probability: top.probability || 0,
    odds: market.odds?.[scoreKey],
    confidence: confidenceLabel((top.probability || 0) - otherBest),
    reason: `比分推荐使用统一锚点 ${top.score || "--"}，模型概率 ${formatProbabilityPercent(top.probability || 0)}，官方固定奖金 ${formatOdds(market.odds?.[scoreKey])}。${switchNote}`,
  });
}

function validateSportteryAlignment({ items, anchor }) {
  const issues = [];
  const result = arrayFrom(items).find((item) => item.marketKey === "result" && item.side !== "watch");
  const handicap = arrayFrom(items).find((item) => item.marketKey === "handicap" && item.side !== "watch");
  const totalGoals = arrayFrom(items).find((item) => item.marketKey === "totalGoals" && item.side !== "watch");
  const score = arrayFrom(items).find((item) => item.marketKey === "score" && item.side !== "watch");
  if (result && result.side !== anchor.resultSide) issues.push(`胜平负 ${result.pick} 与比分 ${anchor.score} 不一致`);
  if (handicap && anchor.handicapSide && handicap.side !== anchor.handicapSide) issues.push(`让球 ${handicap.pick} 与比分 ${anchor.score} 不一致`);
  if (totalGoals && totalGoals.totalGoals !== anchor.totalGoals) issues.push(`总进球数 ${totalGoals.pick} 与比分 ${anchor.score} 不一致`);
  if (score && score.scoreKey !== anchor.scoreKey) issues.push(`比分 ${score.pick} 与锚点 ${anchor.score} 不一致`);
  return {
    ok: issues.length === 0,
    issues,
    anchorScore: anchor.score,
    resultSide: anchor.resultSide,
    handicapSide: anchor.handicapSide,
    handicapLine: anchor.handicapLine,
    totalGoals: anchor.totalGoals,
    switchedFromPrimary: anchor.switchedFromPrimary,
    primaryScore: anchor.primaryScore,
  };
}

function sportteryPickItem(item) {
  const probability = numberOrNull(item.probability);
  const odds = oddsOrNull(item.odds);
  const valueIndex = Number.isFinite(probability) && Number.isFinite(odds)
    ? Number((probability * odds).toFixed(2))
    : null;
  return {
    ...item,
    probability,
    odds,
    valueIndex,
  };
}

function oddsOrNull(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : null;
}

function sportteryWatchItem(marketKey, market, reason) {
  return {
    marketKey,
    market,
    pick: `${market}观望`,
    side: "watch",
    probability: null,
    odds: null,
    valueIndex: null,
    confidence: "低",
    reason,
  };
}

function sportteryHandicapDistribution(matrix, line) {
  const out = { home: 0, draw: 0, away: 0 };
  for (let h = 0; h < matrix.length; h += 1) {
    for (let a = 0; a < matrix[h].length; a += 1) {
      const side = sportteryHandicapSide(h, a, line);
      out[side] += matrix[h][a] || 0;
    }
  }
  return out;
}

function sportteryHandicapSide(homeGoals, awayGoals, line) {
  const adjustedHome = Number(homeGoals) + Number(line || 0);
  if (adjustedHome > Number(awayGoals)) return "home";
  if (adjustedHome < Number(awayGoals)) return "away";
  return "draw";
}

function sportteryTotalGoalsDistribution(matrix) {
  const out = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0 };
  for (let h = 0; h < matrix.length; h += 1) {
    for (let a = 0; a < matrix[h].length; a += 1) {
      out[sportteryTotalGoalsBucket(h + a)] += matrix[h][a] || 0;
    }
  }
  return out;
}

function sportteryTotalGoalsBucket(total) {
  const goals = Number(total);
  if (!Number.isFinite(goals)) return "0";
  return String(Math.min(7, Math.max(0, Math.round(goals))));
}

function sportteryTotalGoalsLabel(bucket) {
  return String(bucket) === "7" ? "7+" : String(bucket);
}

function sportteryScoreKey(homeGoals, awayGoals) {
  const h = Number(homeGoals);
  const a = Number(awayGoals);
  if (!Number.isFinite(h) || !Number.isFinite(a)) return "";
  if (h === a) {
    return h <= 3 ? `s${String(h).padStart(2, "0")}s${String(a).padStart(2, "0")}` : "s1sd";
  }
  if (h > a) {
    const exact = h >= 1 && h <= 5 && a >= 0 && a <= 2;
    return exact ? `s${String(h).padStart(2, "0")}s${String(a).padStart(2, "0")}` : "s1sh";
  }
  const exact = a >= 1 && a <= 5 && h >= 0 && h <= 2;
  return exact ? `s${String(h).padStart(2, "0")}s${String(a).padStart(2, "0")}` : "s1sa";
}

function sportteryScoreLabel(key, fallback = "") {
  if (key === "s1sh") return "胜其他";
  if (key === "s1sd") return "平其他";
  if (key === "s1sa") return "负其他";
  const match = String(key || "").match(/^s(\d{2})s(\d{2})$/);
  if (!match) return fallback || "--";
  return `${Number(match[1])}-${Number(match[2])}`;
}

function sportteryResultLabel(side, match) {
  if (side === "home") return `${teamLabel(match.home)} 胜`;
  if (side === "away") return `${teamLabel(match.away)} 胜`;
  return "平局";
}

function sportteryHandicapResultLabel(side, line, match) {
  const direction = side === "home" ? "让胜" : side === "away" ? "让负" : "让平";
  return `${direction}（${teamLabel(match.home)} ${formatSignedLine(line)}）`;
}

function formatOdds(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number.toFixed(2) : "--";
}

function buildPrediction({ match, venue, weather, elevation, research, odds, sporttery, scoreCalibration }) {
  const factors = [];
  let totalGoals = 2.45;
  let goalDiff = 0;

  const homeHost = isHostTeam(match.home.name, venue.country);
  const awayHost = isHostTeam(match.away.name, venue.country);
  if (homeHost) {
    goalDiff += 0.22;
    factors.push({
      name: "东道主/主场氛围",
      impact: "+0.22 主队净胜球期望",
      detail: `${match.home.name} 在 ${venue.country} 作战，给轻微环境熟悉度加成。`,
    });
  }
  if (awayHost) {
    goalDiff -= 0.22;
    factors.push({
      name: "东道主/主场氛围",
      impact: "+0.22 客队净胜球期望",
      detail: `${match.away.name} 在 ${venue.country} 作战，给轻微环境熟悉度加成。`,
    });
  }

  const footballData = research.structured?.footballData;
  if (footballData?.available) {
    const homeSquad = footballData.teams?.home?.squadCount ?? match.home.squadCount ?? "--";
    const awaySquad = footballData.teams?.away?.squadCount ?? match.away.squadCount ?? "--";
    factors.push({
      name: "官方名单数据",
      impact: "纳入数据质量",
      detail: `football-data.org 已同步主队 ${homeSquad} 人、客队 ${awaySquad} 人名单；主教练 ${footballData.teams?.home?.coach || "--"} / ${footballData.teams?.away?.coach || "--"}。`,
    });
  }

  const fifaImpact = fifaRankingImpact(research.structured?.fifa);
  if (fifaImpact.available) {
    goalDiff += fifaImpact.diff;
    factors.push({
      name: "FIFA 国际排名",
      impact: `${formatSigned(fifaImpact.diff)} 净胜球期望`,
      detail: fifaImpact.detail,
    });
  }

  const oddsH2h = odds.available
    ? odds.markets.find((market) => market.key === "h2h" && market.homeAvg && market.awayAvg)
    : null;
  const espnOdds = research.structured?.espn?.odds;
  let marketProfile = null;
  if (oddsH2h) {
    const implied = normalizeImpliedProbabilities(oddsH2h);
    const marketImpact = marketGoalDiffFromProbabilities(implied.home, implied.away);
    goalDiff += marketImpact;
    factors.push({
      name: "赔率市场",
      impact: `${formatSigned(marketImpact)} 净胜球期望`,
      detail: `按平均欧赔折算：主胜 ${(implied.home * 100).toFixed(1)}%，平 ${(implied.draw * 100).toFixed(1)}%，客胜 ${(implied.away * 100).toFixed(1)}%。`,
    });
  } else if (
    espnOdds?.available &&
    espnOdds.favorite?.side &&
    espnOdds.favorite.side !== "unknown" &&
    Number.isFinite(espnOdds.favorite.implied)
  ) {
    const direction = espnOdds.favorite.side === "home" ? 1 : -1;
    marketProfile = buildEspnMarketProfile(espnOdds);
    const marketImpact = direction * marketProfile.goalDiff;
    goalDiff += marketImpact;
    const marketTotalLine = espnOdds.total?.line ?? espnOdds.overUnder;
    if (marketTotalLine) {
      totalGoals = totalGoals * 0.65 + marketTotalLine * 0.35;
      if (marketProfile.strength === "extreme") totalGoals += 0.35;
      else if (marketProfile.strength === "strong") totalGoals += 0.18;
      const overImplied = americanToProbability(espnOdds.total?.overOdds);
      const underImplied = americanToProbability(espnOdds.total?.underOdds);
      if (Number.isFinite(overImplied) && Number.isFinite(underImplied)) {
        if (underImplied - overImplied >= 0.06) totalGoals -= 0.14;
        if (overImplied - underImplied >= 0.06) totalGoals += 0.14;
      }
    }
    factors.push({
      name: "ESPN/DraftKings 盘口",
      impact: `${formatSigned(marketImpact)} 净胜球期望`,
      detail: `${espnOdds.details || "盘口摘要"}，${marketProfile.label}，隐含强弱信号 ${(espnOdds.favorite.implied * 100).toFixed(1)}%，大小球盘口 ${marketTotalLine ?? "--"}，让球 ${espnOdds.spread?.line ?? "--"}。`,
    });
  } else {
    const consensus = research.signals.oddsConsensus;
    const webLean = clamp((consensus.homeLean - consensus.awayLean) * 0.08, -0.35, 0.35);
    goalDiff += webLean;
    if (webLean !== 0) {
      factors.push({
        name: "网页盘口倾向",
        impact: `${formatSigned(webLean)} 净胜球期望`,
        detail: "未配置赔率 API 时，使用搜索摘要/文章中的盘口推荐词频作为弱信号。",
      });
    }
  }

  const formImpact = recentFormImpact(research.signals.form);
  if (formImpact.available) {
    goalDiff += formImpact.diff;
    totalGoals += formImpact.total;
    factors.push({
      name: "近期状态",
      impact: `${formatSigned(formImpact.diff)} 净胜球期望，${formatSigned(formImpact.total)} 总进球期望`,
      detail: formImpact.detail,
    });
  }

  const homeInjuryPenalty = clamp(research.signals.homeInjuryScore * 0.028, 0, 0.18);
  const awayInjuryPenalty = clamp(research.signals.awayInjuryScore * 0.028, 0, 0.18);
  if (homeInjuryPenalty || awayInjuryPenalty) {
    factors.push({
      name: "阵容伤停",
      impact: `主队 -${homeInjuryPenalty.toFixed(2)} xG，客队 -${awayInjuryPenalty.toFixed(2)} xG`,
      detail: "基于队伍相关搜索结果中的 injury/suspended/伤停/停赛等信号计分。",
    });
  }

  const weatherImpact = weather.available ? weatherGoalImpact(weather, research.signals.venue) : 0;
  totalGoals += weatherImpact;
  if (weather.available) {
    factors.push({
      name: "天气",
      impact: `${formatSigned(weatherImpact)} 总进球期望`,
      detail: [
        `${weather.current.condition}`,
        `${weather.current.temperature ?? "-"} C`,
        `湿度 ${weather.current.humidity ?? "-"}%`,
        `风速 ${weather.current.windSpeed ?? "-"} km/h`,
        `降水概率 ${weather.current.precipitationProbability ?? "-"}%`,
      ].join("，"),
    });
  } else {
    factors.push({
      name: "天气",
      impact: "未纳入",
      detail: weather.message || "天气预报暂不可用。",
    });
  }

  const altitudeImpact = altitudeGoalImpact(elevation.meters);
  totalGoals += altitudeImpact.total;
  goalDiff += altitudeImpact.diff;
  if (elevation.available) {
    factors.push({
      name: "海拔",
      impact: `${formatSigned(altitudeImpact.total)} 总进球期望`,
      detail: `${Math.round(elevation.meters ?? 0)} 米。高海拔会降低比赛节奏并增加不确定性。`,
    });
  }

  if (/r16|r32|qf|sf|final|third/i.test(match.type)) {
    totalGoals -= 0.08;
    factors.push({
      name: "淘汰赛阶段",
      impact: "-0.08 总进球期望",
      detail: "淘汰赛通常更保守，模型给总进球轻微下调。",
    });
  }

  const overUnderLean = research.signals.oddsConsensus.overLean - research.signals.oddsConsensus.underLean;
  totalGoals += clamp(overUnderLean * 0.04, -0.18, 0.18);

  totalGoals = clamp(totalGoals, 1.25, 4.65);
  goalDiff = clamp(goalDiff, -2.8, 2.8);

  let homeXg = clamp(totalGoals / 2 + goalDiff / 2 - homeInjuryPenalty + awayInjuryPenalty * 0.2, 0.12, 4.8);
  let awayXg = clamp(totalGoals / 2 - goalDiff / 2 - awayInjuryPenalty + homeInjuryPenalty * 0.2, 0.12, 4.8);

  if (marketProfile?.strength === "strong" || marketProfile?.strength === "extreme") {
    if (marketProfile.side === "home") {
      homeXg = clamp(Math.max(homeXg, marketProfile.favoriteMinXg), 0.12, 4.8);
      awayXg = clamp(Math.min(awayXg, marketProfile.underdogMaxXg), 0.08, 4.8);
    } else if (marketProfile.side === "away") {
      awayXg = clamp(Math.max(awayXg, marketProfile.favoriteMinXg), 0.12, 4.8);
      homeXg = clamp(Math.min(homeXg, marketProfile.underdogMaxXg), 0.08, 4.8);
    }
    factors.push({
      name: "强弱盘修正",
      impact: `${marketProfile.side === "home" ? match.home.name : match.away.name} xG 下限 ${marketProfile.favoriteMinXg}`,
      detail: "极端热门盘口下，模型将大球来源主要分配给热门队，避免把弱队进球率错误抬高。",
    });
  }

  const matrix = scoreMatrix(homeXg, awayXg, 8);
  const probs = summarizeMatrix(matrix);
  const totalLines = {
    twoPointFive: summarizeTotalLine(matrix, 2.5),
    market: buildMarketTotalLine(matrix, espnOdds),
  };
  const spreadLine = buildMarketSpreadLine(matrix, espnOdds, match);
  const derivativeMarkets = buildDerivativeMarkets({
    match,
    probs,
    research,
    totalGoals: homeXg + awayXg,
    goalDiff,
    weather,
  });
  probs.totals = totalLines;
  if (totalLines.market?.available) {
    probs.marketOver = totalLines.market.over;
    probs.marketUnder = totalLines.market.under;
    probs.marketLine = totalLines.market.line;
  }
  const scoreCandidates = buildRawScoreCandidates(matrix);
  const scoreContext = buildScoreRecommendationContext({
    fifaImpact,
    formImpact,
    marketProfile,
    probabilities: probs,
    totalLines,
    spreadLine,
    homeXg,
    awayXg,
  });
  const scorePortfolio = buildCalibratedScorePortfolio({
    candidates: scoreCandidates,
    probabilities: probs,
    totalLines,
    spreadLine,
    homeXg,
    awayXg,
    marketProfile,
    scoreCalibration,
    scoreConsensus: research.signals?.scoreConsensus,
    scoreContext,
  }).slice(0, 8);
  const primaryScore = scorePortfolio[0] || { score: "0-0", homeGoals: 0, awayGoals: 0, probability: 0 };
  const topScores = scorePortfolio;
  const scoreConsensus = research.signals?.scoreConsensus;
  if (scoreConsensus?.available && scoreConsensus.topScores?.length) {
    const topConsensus = scoreConsensus.topScores[0];
    factors.push({
      name: "外部比分共识",
      impact: `${topConsensus.score} · ${formatProbabilityPercent(topConsensus.probability)}`,
      detail: `已纳入 ${scoreConsensus.sourceCount || 0} 个网页/摘要里的推荐比分信号，来源包括 ${(topConsensus.domains || []).slice(0, 3).join("、") || "全网搜索"}；该信号仅做候选比分低权重校准。`,
    });
  }
  factors.push({
    name: "比分校准",
    impact: `首选 ${primaryScore.score} · ${formatProbabilityPercent(primaryScore.probability)}`,
    detail: primaryScore.calibrationNote || "比分候选已同时核对胜平负强度、大小球方向、让球盘、历史反馈和双方 xG 差，避免比分与推荐口径互相冲突。",
  });

  const marketSummary = buildMarketSummary({ match, probs, primaryScore, totalLines, spreadLine });
  const expectedGoals = {
    home: Number(homeXg.toFixed(2)),
    away: Number(awayXg.toFixed(2)),
    total: Number((homeXg + awayXg).toFixed(2)),
  };
  const historyRecord = findPredictionHistoryRecord(match);
  const simulation = buildMatchSimulation({
    match,
    research,
    weather,
    expectedGoals,
    probabilities: probs,
    primaryScore,
    scorePortfolio,
    derivativeMarkets,
    marketSummary,
    goalDiff,
    historyRecord,
  });
  const resultContext = buildResultContext({
    match,
    research,
    primaryScore,
    scorePortfolio,
    historyRecord,
  });
  let recommendations = buildRecommendations({ match, probs, topScores, primaryScore, odds, research, marketProfile, totalLines, spreadLine, marketSummary });
  recommendations.push(...derivativeMarkets.recommendations);
  const quality = dataQuality({ weather, odds, research });
  const sportteryRecommendation = buildSportteryRecommendation({ match, sporttery, probabilities: probs, primaryScore, scorePortfolio, matrix });
  const validation = validatePredictionConsistency({ primaryScore, probabilities: probs, recommendations, totalLines, marketSummary, derivativeMarkets, simulation });
  recommendations = alignRecommendationsWithValidation(recommendations, validation);
  const bettingToolkit = buildBettingToolkit({
    match,
    probabilities: probs,
    primaryScore,
    scorePortfolio,
    marketSummary,
    derivativeMarkets,
    weather,
    research,
    validation,
  });
  const intelligence24h = buildIntelligence24h({
    match,
    venue,
    research,
    weather,
    marketSummary,
    derivativeMarkets,
    primaryScore,
    probabilities: probs,
    validation,
  });
  const bettingPlatform = buildBettingPlatform({
    match,
    research,
    odds,
    sporttery,
    marketSummary,
    derivativeMarkets,
    sportteryRecommendation,
    validation,
    quality,
    primaryScore,
    scorePortfolio,
    probabilities: probs,
    totalLines,
    spreadLine,
  });

  return {
    model: "透明启发式 Poisson v1",
    expectedGoals,
    resultContext,
    probabilities: probs,
    totalLines,
    spreadLine,
    marketSummary,
    simulation,
    derivativeMarkets,
    sportteryRecommendation,
    primaryScore,
    scorePortfolio,
    topScores,
    factors,
    recommendations,
    bettingToolkit,
    bettingPlatform,
    intelligence24h,
    marketProfile,
    quality,
    validation,
    disclaimer:
      "足球比分随机性很高，盘口信息可能延迟或来自第三方网页摘要。本工具仅用于赛前研究，不构成投注建议。",
  };
}

function buildRawScoreCandidates(matrix) {
  return matrix.flatMap((row, homeGoals) =>
    row.map((probability, awayGoals) => ({
      score: `${homeGoals}-${awayGoals}`,
      homeGoals,
      awayGoals,
      rawProbability: Number(probability || 0),
    }))
  );
}

function buildScoreRecommendationContext({
  fifaImpact,
  formImpact,
  marketProfile,
  probabilities,
  totalLines,
  spreadLine,
  homeXg,
  awayXg,
}) {
  const expectedHome = Math.max(0, Number(homeXg) || 0);
  const expectedAway = Math.max(0, Number(awayXg) || 0);
  const expectedTotal = expectedHome + expectedAway;
  const expectedDiff = expectedHome - expectedAway;
  const probabilityEdge = Number(probabilities?.homeWin || 0) - Number(probabilities?.awayWin || 0);
  const favoriteSide = Math.abs(expectedDiff) >= 0.14
    ? expectedDiff > 0 ? "home" : "away"
    : Math.abs(probabilityEdge) >= 0.04
    ? probabilityEdge > 0 ? "home" : "away"
    : "draw";
  const favoriteXg = favoriteSide === "home" ? expectedHome : favoriteSide === "away" ? expectedAway : 0;
  const underdogXg = favoriteSide === "home" ? expectedAway : favoriteSide === "away" ? expectedHome : 0;
  const rankEdge = Number(fifaImpact?.diff || 0);
  const formEdge = Number(formImpact?.diff || 0);
  const formTotal = Number(formImpact?.total || 0);
  const marketEdge = marketProfile?.side === "home"
    ? Number(marketProfile.goalDiff || 0)
    : marketProfile?.side === "away"
    ? -Number(marketProfile.goalDiff || 0)
    : 0;
  const alignedEdges = [expectedDiff, rankEdge, formEdge, marketEdge].filter((value) => Math.abs(value) >= 0.08);
  const favoriteSign = favoriteSide === "home" ? 1 : favoriteSide === "away" ? -1 : 0;
  const favoriteAgreement = favoriteSign
    ? ratio(alignedEdges.filter((value) => Math.sign(value) === favoriteSign).length, alignedEdges.length) || 0
    : 0;
  const strengthGap = clamp(
    Math.abs(expectedDiff) * 0.55 +
      Math.abs(rankEdge) * 0.22 +
      Math.abs(formEdge) * 0.2 +
      Math.abs(marketEdge) * 0.24 +
      (favoriteAgreement >= 0.75 ? 0.15 : 0),
    0,
    2.25
  );
  const marketTotal = totalLines?.market?.available ? totalLines.market : totalLines?.twoPointFive;
  const totalLine = Number(marketTotal?.line ?? 2.5);
  const over = Number(marketTotal?.over ?? probabilities?.over25);
  const under = Number(marketTotal?.under ?? probabilities?.under25);
  const totalSide = Number.isFinite(over) && Number.isFinite(under) && Math.abs(over - under) >= 0.025
    ? over > under ? "over" : "under"
    : "neutral";
  const drawBias = clamp((Number(probabilities?.draw || 0) - 0.25) * 1.45 - Math.abs(expectedDiff) * 0.16, -0.35, 0.3);
  const bttsBias = clamp((Number(probabilities?.btts || 0) - 0.5) * 1.25, -0.35, 0.35);

  return {
    favoriteSide,
    favoriteXg,
    underdogXg,
    expectedHome,
    expectedAway,
    expectedTotal,
    expectedDiff,
    rankEdge,
    formEdge,
    formTotal,
    marketEdge,
    favoriteAgreement,
    strengthGap,
    totalLine,
    totalSide,
    over,
    under,
    drawBias,
    bttsBias,
    spreadLineValue: Number(spreadLine?.line),
    spreadFavoriteCover: Number(spreadLine?.favoriteCover),
    spreadUnderdogCover: Number(spreadLine?.underdogCover),
  };
}

function buildCalibratedScorePortfolio({
  candidates,
  probabilities,
  totalLines,
  spreadLine,
  homeXg,
  awayXg,
  marketProfile,
  scoreCalibration,
  scoreConsensus,
  scoreContext = {},
}) {
  const homeWin = Number(probabilities?.homeWin || 0);
  const awayWin = Number(probabilities?.awayWin || 0);
  const draw = Number(probabilities?.draw || 0);
  const edge = homeWin - awayWin;
  const favoriteSide = Math.abs(edge) >= 0.04 ? (edge > 0 ? "home" : "away") : "draw";
  const favoriteProbability = favoriteSide === "home" ? homeWin : favoriteSide === "away" ? awayWin : draw;
  const marketTotal = totalLines?.market?.available ? totalLines.market : totalLines?.twoPointFive;
  const totalLine = Number(marketTotal?.line ?? 2.5);
  const over = Number(marketTotal?.over ?? probabilities?.over25);
  const under = Number(marketTotal?.under ?? probabilities?.under25);
  const totalSide = Number.isFinite(over) && Number.isFinite(under) && Math.abs(over - under) >= 0.035
    ? over > under ? "over" : "under"
    : "neutral";
  const expectedTotal = Number(homeXg || 0) + Number(awayXg || 0);
  const expectedDiff = Number(homeXg || 0) - Number(awayXg || 0);
  const strongFavorite = favoriteSide !== "draw" && (favoriteProbability >= 0.58 || Math.abs(expectedDiff) >= 0.75);
  const extremeFavorite = favoriteSide !== "draw" && (favoriteProbability >= 0.72 || Math.abs(expectedDiff) >= 1.35 || marketProfile?.strength === "extreme");
  const scored = arrayFrom(candidates).map((candidate) => {
    const homeGoals = Number(candidate.homeGoals || 0);
    const awayGoals = Number(candidate.awayGoals || 0);
    const scoreTotal = homeGoals + awayGoals;
    const scoreDiff = homeGoals - awayGoals;
    const direction = scoreDirection({ home: homeGoals, away: awayGoals });
    let multiplier = 1;
    const notes = [];

    if (favoriteSide !== "draw") {
      if (direction === favoriteSide) {
        multiplier *= strongFavorite ? 1.16 : 1.08;
        notes.push("胜负方向一致");
      } else if (direction === "draw") {
        multiplier *= extremeFavorite ? 0.42 : strongFavorite ? 0.62 : 0.86;
        notes.push("强弱差下调平局");
      } else {
        multiplier *= extremeFavorite ? 0.22 : strongFavorite ? 0.48 : 0.72;
        notes.push("爆冷比分降权");
      }
    } else if (draw >= 0.27 && direction === "draw") {
      multiplier *= 1.12;
      notes.push("平局权重较高");
    }

    if (totalSide === "over") {
      if (scoreTotal > totalLine) {
        multiplier *= 1.08;
        notes.push("大小球方向一致");
      } else {
        multiplier *= 0.78;
      }
    } else if (totalSide === "under") {
      if (scoreTotal < totalLine) {
        multiplier *= 1.08;
        notes.push("大小球方向一致");
      } else {
        multiplier *= 0.78;
      }
    }

    const totalError = Math.abs(scoreTotal - expectedTotal);
    const diffError = Math.abs(scoreDiff - expectedDiff);
    multiplier *= clamp(1.12 - totalError * 0.06, 0.72, 1.12);
    multiplier *= clamp(1.1 - diffError * 0.055, 0.68, 1.1);

    if (marketProfile?.strength === "strong" || marketProfile?.strength === "extreme") {
      const favoriteGoals = marketProfile.side === "home" ? homeGoals : awayGoals;
      const underdogGoals = marketProfile.side === "home" ? awayGoals : homeGoals;
      if (direction !== marketProfile.side) multiplier *= marketProfile.strength === "extreme" ? 0.28 : 0.48;
      if (underdogGoals >= 2) multiplier *= 0.52;
      if (underdogGoals >= 1 && Number(marketProfile.underdogMaxXg) <= 0.65) multiplier *= 0.74;
      if (favoriteGoals < 2 && Number(marketProfile.favoriteMinXg) >= 2.1) multiplier *= 0.78;
      notes.push(`${marketProfile.label}校准`);
    }

    if (spreadLine?.available) {
      const favoriteMargin = spreadLine.favoriteSide === "home" ? scoreDiff : -scoreDiff;
      if (Number.isFinite(Number(spreadLine.line))) {
        if (spreadLine.favoriteCover >= 0.56 && favoriteMargin > Number(spreadLine.line)) {
          multiplier *= 1.06;
          notes.push("让球穿盘一致");
        } else if (spreadLine.underdogCover >= 0.56 && favoriteMargin <= Number(spreadLine.line)) {
          multiplier *= 1.04;
          notes.push("受让方向一致");
        }
      }
    }

    const shapeMultiplier = scoreShapeMultiplier(candidate, scoreContext);
    multiplier *= shapeMultiplier.value;
    notes.push(...shapeMultiplier.notes);

    const priorMultiplier = scorePriorMultiplier(candidate.score, scoreCalibration);
    if (priorMultiplier !== 1) {
      multiplier *= priorMultiplier;
      notes.push("历史比分先验");
    }
    const historyMultiplier = historicalScoreMultiplier(candidate, scoreCalibration);
    if (historyMultiplier !== 1) {
      multiplier *= historyMultiplier;
      notes.push("历史命中反馈");
    }
    const consensusMultiplier = scoreConsensusMultiplier(candidate, scoreConsensus, {
      favoriteSide,
      totalSide,
      totalLine,
    });
    if (consensusMultiplier !== 1) {
      multiplier *= consensusMultiplier;
      notes.push("外部比分共识");
    }

    const adjustedWeight = Math.max(0, Number(candidate.rawProbability || candidate.probability || 0) * multiplier);
    return {
      ...candidate,
      rawProbability: Number((candidate.rawProbability || candidate.probability || 0).toFixed(5)),
      adjustedWeight,
      calibrationNote: notes.length
        ? `已校准：${[...new Set(notes)].join("、")}。`
        : "已按胜平负、大小球、让球盘和 xG 差完成一致性校准。",
    };
  });

  const adjustedTotal = scored.reduce((sum, item) => sum + item.adjustedWeight, 0) || 1;
  return scored
    .map((item) => ({
      ...item,
      probability: Number((item.adjustedWeight / adjustedTotal).toFixed(4)),
    }))
    .sort((a, b) => b.probability - a.probability || b.rawProbability - a.rawProbability)
    .map((item, index) => ({
      score: item.score,
      homeGoals: item.homeGoals,
      awayGoals: item.awayGoals,
      probability: item.probability,
      rawProbability: item.rawProbability,
      calibrationNote: item.calibrationNote,
      primary: index === 0,
    }));
}

function scoreShapeMultiplier(candidate, context = {}) {
  const homeGoals = Number(candidate.homeGoals || 0);
  const awayGoals = Number(candidate.awayGoals || 0);
  const scoreTotal = homeGoals + awayGoals;
  const scoreDiff = homeGoals - awayGoals;
  const direction = scoreDirection({ home: homeGoals, away: awayGoals });
  const favoriteSide = context.favoriteSide || "draw";
  const expectedTotal = Number(context.expectedTotal || 0);
  const expectedDiff = Number(context.expectedDiff || 0);
  const strengthGap = Number(context.strengthGap || 0);
  const notes = [];
  let multiplier = 1;

  if (favoriteSide !== "draw") {
    const favoriteGoals = favoriteSide === "home" ? homeGoals : awayGoals;
    const underdogGoals = favoriteSide === "home" ? awayGoals : homeGoals;
    const favoriteMargin = favoriteGoals - underdogGoals;
    const favoriteXg = Number(context.favoriteXg || 0);
    const underdogXg = Number(context.underdogXg || 0);
    const favoriteAgreement = Number(context.favoriteAgreement || 0);

    if (direction === favoriteSide) {
      if (favoriteXg >= 1.75 && favoriteGoals >= 2) {
        multiplier *= clamp(1.06 + (favoriteXg - 1.75) * 0.08, 1.06, 1.18);
        notes.push("强队进攻量校准");
      }
      if (favoriteXg >= 2.25 && favoriteGoals >= 3 && (expectedTotal >= 3 || strengthGap >= 1.05)) {
        multiplier *= 1.08;
        notes.push("高xG比分上沿");
      }
      if (favoriteXg >= 2.05 && favoriteGoals <= 1) {
        multiplier *= 0.86;
        notes.push("强队一球保守降权");
      }
      if (strengthGap >= 0.9 && favoriteMargin >= 2) {
        multiplier *= 1.08;
        notes.push("实力差距校准");
      }
      if (
        strengthGap >= 1.25 &&
        favoriteMargin === 1 &&
        Number.isFinite(context.spreadFavoriteCover) &&
        context.spreadFavoriteCover >= 0.54
      ) {
        multiplier *= 0.93;
        notes.push("让球强度修正");
      }
    } else if (direction === "draw") {
      const drawPenalty = strengthGap >= 1.15 || favoriteAgreement >= 0.75 ? 0.68 : 0.82;
      multiplier *= clamp(drawPenalty + context.drawBias * 0.15, 0.56, 0.95);
      notes.push("强弱差平局降权");
    } else if (favoriteAgreement >= 0.67 || strengthGap >= 0.9) {
      multiplier *= strengthGap >= 1.25 ? 0.58 : 0.72;
      notes.push("爆冷比分降权");
    }

    if (underdogXg <= 0.72 && strengthGap >= 0.75) {
      if (underdogGoals === 0) {
        multiplier *= 1.1;
        notes.push("弱队进球抑制");
      } else if (underdogGoals >= 2) {
        multiplier *= 0.55;
        notes.push("弱队多球降权");
      } else {
        multiplier *= 0.9;
      }
    } else if (Number(context.bttsBias || 0) >= 0.08 || underdogXg >= 1.08) {
      if (underdogGoals >= 1 && favoriteGoals >= 1) {
        multiplier *= 1.07;
        notes.push("双方进球校准");
      } else if (underdogGoals === 0) {
        multiplier *= 0.92;
      }
    }
  } else if (Number(context.drawBias || 0) > 0.04) {
    if (direction === "draw") {
      multiplier *= 1.08;
      notes.push("均势平局校准");
    } else if (Math.abs(scoreDiff) >= 2) {
      multiplier *= 0.82;
    }
  }

  const totalLine = Number.isFinite(Number(context.totalLine)) ? Number(context.totalLine) : 2.5;
  if (context.totalSide === "over" || expectedTotal >= Math.max(2.95, totalLine + 0.2) || Number(context.formTotal || 0) >= 0.1) {
    if (scoreTotal >= Math.ceil(totalLine + 0.25)) {
      multiplier *= expectedTotal >= 3.25 ? 1.14 : 1.08;
      notes.push("大球节奏校准");
    } else if (scoreTotal <= 1) {
      multiplier *= 0.68;
      notes.push("大球低比分降权");
    } else if (scoreTotal < totalLine && expectedTotal >= 3.15) {
      multiplier *= 0.82;
    }
  }

  if (context.totalSide === "under" || expectedTotal <= Math.min(2.2, totalLine - 0.15)) {
    if (scoreTotal < totalLine) {
      multiplier *= 1.07;
      notes.push("小球节奏校准");
    } else if (scoreTotal >= Math.ceil(totalLine + 1)) {
      multiplier *= 0.62;
      notes.push("小球高比分降权");
    } else if (scoreTotal >= 4 && expectedTotal <= 2.55) {
      multiplier *= 0.74;
    }
  }

  const xgTotalError = Math.abs(scoreTotal - expectedTotal);
  const xgDiffError = Math.abs(scoreDiff - expectedDiff);
  if (xgTotalError <= 0.7 && xgDiffError <= 0.75) {
    multiplier *= 1.05;
    notes.push("xG中心一致");
  }
  if (xgTotalError >= 2.1 || xgDiffError >= 2.1) {
    multiplier *= 0.78;
    notes.push("远离xG中心降权");
  }

  return {
    value: Number(clamp(multiplier, 0.28, 1.9).toFixed(3)),
    notes,
  };
}

function scoreConsensusMultiplier(candidate, scoreConsensus, context = {}) {
  if (!scoreConsensus?.available || !scoreConsensus.topScores?.length) return 1;
  const score = candidate.score || `${candidate.homeGoals}-${candidate.awayGoals}`;
  const exact = scoreConsensus.topScores.find((item) => item.score === score);
  const top = scoreConsensus.topScores[0];
  const candidateDirection = scoreDirection({ home: candidate.homeGoals, away: candidate.awayGoals });
  const topDirection = scoreDirection({ home: top.homeGoals, away: top.awayGoals });
  const scoreTotal = Number(candidate.homeGoals || 0) + Number(candidate.awayGoals || 0);
  const topTotal = Number(top.homeGoals || 0) + Number(top.awayGoals || 0);
  const consensusStrength = clamp(Number(scoreConsensus.totalWeight || 0) / 6, 0, 1);
  let multiplier = 1;

  if (exact) {
    multiplier *= clamp(
      1 + Number(exact.probability || 0) * 0.24 + Math.min(Number(exact.sourceCount || 0), 4) * 0.025,
      1.03,
      1.2
    );
  } else if (candidateDirection === topDirection && consensusStrength >= 0.25) {
    multiplier *= clamp(1.02 + consensusStrength * 0.08, 1.02, 1.09);
  } else if (candidateDirection !== topDirection && consensusStrength >= 0.55) {
    multiplier *= 0.95;
  }

  const totalSide = context.totalSide;
  if (["over", "under"].includes(totalSide)) {
    const line = Number(context.totalLine || 2.5);
    const candidateMatchesTotal = totalSide === "over" ? scoreTotal > line : scoreTotal < line;
    const consensusMatchesTotal = totalSide === "over" ? topTotal > line : topTotal < line;
    if (candidateMatchesTotal && consensusMatchesTotal) multiplier *= 1.025;
    if (!candidateMatchesTotal && consensusMatchesTotal && exact) multiplier *= 0.96;
  }

  if (context.favoriteSide && context.favoriteSide !== "draw") {
    if (candidateDirection === context.favoriteSide && topDirection === context.favoriteSide) multiplier *= 1.02;
    if (candidateDirection !== context.favoriteSide && topDirection === context.favoriteSide && consensusStrength >= 0.45) multiplier *= 0.97;
  }

  return Number(clamp(multiplier, 0.9, 1.22).toFixed(3));
}

const DEFAULT_SCORE_PRIORS = {
  "1-1": 0.115,
  "1-0": 0.105,
  "0-1": 0.085,
  "2-1": 0.09,
  "2-0": 0.078,
  "0-0": 0.074,
  "1-2": 0.07,
  "0-2": 0.052,
  "2-2": 0.048,
  "3-1": 0.04,
  "3-0": 0.034,
  "1-3": 0.032,
  "0-3": 0.024,
};

function scorePriorMultiplier(score, scoreCalibration) {
  const learnedPrior = scoreCalibration?.available ? Number(scoreCalibration.actualPriors?.[score]) : null;
  const prior = Number.isFinite(learnedPrior) && learnedPrior > 0
    ? learnedPrior
    : DEFAULT_SCORE_PRIORS[score] || defaultScorePrior(score);
  return Number(clamp(0.96 + prior * 0.55, 0.92, 1.035).toFixed(3));
}

function defaultScorePrior(score) {
  const parsed = parseScoreText(score);
  const total = parsed.home + parsed.away;
  const diff = Math.abs(parsed.home - parsed.away);
  if (total <= 1) return 0.045;
  if (total === 2 && diff <= 1) return 0.06;
  if (total === 3 && diff <= 2) return 0.048;
  if (total === 4 && diff <= 2) return 0.032;
  if (total >= 5) return 0.014;
  return 0.026;
}

function historicalScoreMultiplier(candidate, scoreCalibration) {
  if (!scoreCalibration?.available) return 1;
  const stats = scoreCalibration.scoreMultipliers?.[candidate.score];
  if (!stats || stats.sample < 2) return 1;
  return Number(clamp(stats.multiplier, 0.82, 1.14).toFixed(3));
}

function buildMatchSimulation({
  match,
  research,
  weather,
  expectedGoals,
  probabilities,
  primaryScore,
  scorePortfolio,
  derivativeMarkets,
  marketSummary,
  goalDiff,
  historyRecord,
}) {
  const lineup = research.structured?.lineupProjection || {};
  const homeTactic = buildSimulationTactic({
    side: "home",
    team: match.home,
    lineup: lineup.home,
    xg: expectedGoals.home,
    opponentXg: expectedGoals.away,
    goalDiff,
    signals: research.signals,
    weather,
  });
  const awayTactic = buildSimulationTactic({
    side: "away",
    team: match.away,
    lineup: lineup.away,
    xg: expectedGoals.away,
    opponentXg: expectedGoals.home,
    goalDiff: -goalDiff,
    signals: research.signals,
    weather,
  });
  const corners = buildSimulationCorners({ match, derivativeMarkets, expectedGoals, goalDiff });
  const cards = buildSimulationCards({ match, derivativeMarkets, probabilities, goalDiff });
  const rhythm = buildSimulationRhythm({ match, probabilities, expectedGoals, goalDiff, weather });
  const phases = buildSimulationPhases({
    match,
    expectedGoals,
    probabilities,
    primaryScore,
    homeTactic,
    awayTactic,
    corners,
    cards,
    rhythm,
    goalDiff,
  });
  const keyDuels = buildSimulationKeyDuels({
    match,
    homeTactic,
    awayTactic,
    expectedGoals,
    corners,
    cards,
    goalDiff,
  });
  const triggers = buildSimulationTriggers({
    match,
    probabilities,
    expectedGoals,
    primaryScore,
    marketSummary,
    corners,
    cards,
    rhythm,
    weather,
  });
  const actual = actualScoreFromMatch(match, research);
  const events = buildSimulationEvents({
    match,
    primaryScore,
    homeTactic,
    awayTactic,
    corners,
    cards,
    rhythm,
    phases,
    triggers,
  });
  const confidence = buildSimulationConfidence({ lineup, research, derivativeMarkets });
  if (actual.completed) {
    return buildActualMatchRecap({
      match,
      research,
      weather,
      expectedGoals,
      probabilities,
      primaryScore,
      scorePortfolio,
      marketSummary,
      corners,
      cards,
      rhythm,
      confidence,
      actual,
      historyRecord,
    });
  }
  const scoreLabel = primaryScore?.score || "0-0";
  const [scoreHomePart, scoreAwayPart] = String(scoreLabel).split("-");
  const parsedHomeGoals = Number(scoreHomePart);
  const parsedAwayGoals = Number(scoreAwayPart);
  const simulatedHomeGoals = Number.isFinite(Number(primaryScore?.homeGoals))
    ? Number(primaryScore.homeGoals)
    : Number.isFinite(parsedHomeGoals)
    ? parsedHomeGoals
    : 0;
  const simulatedAwayGoals = Number.isFinite(Number(primaryScore?.awayGoals))
    ? Number(primaryScore.awayGoals)
    : Number.isFinite(parsedAwayGoals)
    ? parsedAwayGoals
    : 0;
  const layeredReport = buildSimulationLayeredReport({
    match,
    research,
    weather,
    expectedGoals,
    probabilities,
    scorePortfolio,
    marketSummary,
    homeTactic,
    awayTactic,
    rhythm,
    corners,
    cards,
    goalDiff,
    confidence,
  });

  return {
    available: true,
    title: "阵容战术事件流模拟",
    sourceSummary: `已纳入 ${research.signals?.sourceCount || 0} 条网页信号、阵容可信度 ${lineup.confidence?.label || "--"}、角球/罚牌来源 ${corners.sourceCount + cards.sourceCount} 条。`,
    confidence,
    scoreboard: {
      score: scoreLabel,
      probability: primaryScore?.probability ?? null,
      homeGoals: simulatedHomeGoals,
      awayGoals: simulatedAwayGoals,
      reason: `模拟比分沿用最高概率比分 ${scoreLabel}，并与 xG ${expectedGoals.home}-${expectedGoals.away}、胜平负概率和盘口摘要交叉校验。`,
    },
    rhythm,
    tactics: [homeTactic, awayTactic],
    layeredReport,
    events,
    phases,
    keyDuels,
    triggers,
    setPieces: {
      corners,
      cards,
    },
    conclusion: [
      `比分推荐：${scoreLabel}，候选比分前列为 ${(scorePortfolio || []).slice(0, 3).map((item) => `${item.score}（${formatProbabilityPercent(item.probability)}）`).join("、") || "--"}。`,
      `大小球：${marketSummary?.total?.label || "观望"}。`,
      `角球模拟：${teamLabel(match.home)} ${corners.home} 个、${teamLabel(match.away)} ${corners.away} 个，总角球约 ${corners.total} 个。`,
      `罚牌模拟：${teamLabel(match.home)} ${cards.home} 张、${teamLabel(match.away)} ${cards.away} 张，总罚牌约 ${cards.total} 张。`,
    ],
  };
}

function buildActualMatchRecap({
  match,
  research,
  weather,
  expectedGoals,
  probabilities,
  primaryScore,
  scorePortfolio,
  marketSummary,
  corners,
  cards,
  rhythm,
  confidence,
  actual,
  historyRecord,
}) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  const actualScore = `${actual.home}-${actual.away}`;
  const historicalScore = historyRecord?.recommendedScore || "";
  const predictedScore = historicalScore || primaryScore?.score || "--";
  const predictedProbability = Number.isFinite(Number(historyRecord?.recommendedProbability))
    ? Number(historyRecord.recommendedProbability)
    : primaryScore?.probability ?? null;
  const displayTopScores = arrayFrom(historyRecord?.topScores).length ? historyRecord.topScores : scorePortfolio || [];
  const scoreDistance = predictedScore.includes("-")
    ? Math.abs(parseScoreText(predictedScore).home - actual.home) + Math.abs(parseScoreText(predictedScore).away - actual.away)
    : null;
  const resultHit = scoreDirection({ home: actual.home, away: actual.away }) === scoreDirection(parseScoreText(predictedScore));
  const topScores = displayTopScores.slice(0, 4).map((item) => `${item.score} ${formatProbabilityPercent(item.probability)}`).join(" / ");
  const predictionSourceLabel = historicalScore ? "赛前保存推荐" : "当前复盘模型";

  return {
    available: true,
    mode: "actual",
    title: "实际比赛复盘",
    sourceSummary: `实际比分来自 ${actual.source || "赛程/ESPN"}；${predictionSourceLabel} ${predictedScore}，实际比分 ${actualScore}。`,
    confidence: {
      ...confidence,
      label: "赛果已确认",
      score: 100,
    },
    scoreboard: {
      score: actualScore,
      probability: predictedProbability,
      homeGoals: actual.home,
      awayGoals: actual.away,
      reason: scoreDistance === 0
        ? `${predictionSourceLabel} ${predictedScore} 命中实际比分。`
        : `${predictionSourceLabel} ${predictedScore}，实际为 ${actualScore}，方向${resultHit ? "命中" : "未命中"}，比分偏差 ${scoreDistance ?? "--"} 球。`,
    },
    rhythm,
    tactics: [],
    layeredReport: {
      mode: "实际复盘",
      headline: `实际比赛情况：${homeName} ${actualScore} ${awayName}`,
      meta: [
        `赛程：${match.dateInfo?.label || "--"} · ${matchStageLabel(match)}`,
        `球场：${simulationVenueLine(match.stadium)}`,
        `赛果来源：${actual.source || "赛程/ESPN"}`,
      ],
      layers: [
        {
          title: "实际赛果",
          tone: "core",
          points: [
            `${homeName} ${actual.home} 球，${awayName} ${actual.away} 球，最终比分 ${actualScore}。`,
            `赛前/复盘 xG：${homeName} ${expectedGoals.home}，${awayName} ${expectedGoals.away}；${predictionSourceLabel} ${predictedScore}。`,
            `赛果方向：${resultHit ? "与赛前方向一致" : "与赛前方向不一致"}。`,
          ],
        },
        {
          title: "模型对账",
          tone: "model",
          points: [
            `候选比分：${topScores || "--"}。`,
            `比分偏差：${scoreDistance ?? "--"} 球；${scoreDistance === 0 ? "精确命中" : scoreDistance <= 2 ? "方向可参考，比分需修正" : "模型偏差较大，需要复盘权重"}。`,
            `大小球赛前口径：${marketSummary?.total?.label || "--"}；让球赛前口径：${marketSummary?.spread?.label || "--"}。`,
          ],
        },
        {
          title: "环境与节奏",
          tone: "venue",
          points: [
            `${simulationWeatherLine(weather)}。`,
            `赛前节奏判断：${rhythm.tempo}，${rhythm.control}。`,
            "实际技术统计若官方未返回，角球/罚牌仍以模型复盘值标注为估算。",
          ],
        },
        {
          title: "角球/罚牌复盘",
          tone: "discipline",
          points: [
            `角球模型复盘：${homeName} ${corners.home} - ${corners.away} ${awayName}，总角球约 ${corners.total}。`,
            `罚牌模型复盘：${homeName} ${cards.home} - ${cards.away} ${awayName}，总罚牌约 ${cards.total}。`,
            "若后续抓到官方技术统计，本区域会以实际角球/罚牌替换估算。",
          ],
        },
      ],
    },
    events: buildActualRecapEvents({ match, actual, predictedScore, marketSummary }),
    setPieces: {
      corners,
      cards,
    },
    conclusion: [
      `实际比分：${homeName} ${actualScore} ${awayName}。`,
      `${predictionSourceLabel}：${predictedScore}；${scoreDistance === 0 ? "比分准确" : `比分偏差 ${scoreDistance ?? "--"} 球`}。`,
      `赛果方向：${resultHit ? "命中" : "未命中"}；大小球赛前结论：${marketSummary?.total?.label || "--"}。`,
    ],
  };
}

function buildActualRecapEvents({ match, actual, predictedScore, marketSummary }) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  return [
    {
      minute: "FT",
      type: "赛果确认",
      side: "neutral",
      text: `${homeName} ${actual.home}-${actual.away} ${awayName}，实际比分已确认。`,
    },
    {
      minute: "模型",
      type: "赛前对账",
      side: "neutral",
      text: `赛前保存推荐比分为 ${predictedScore || "--"}，用于和实际比分对比历史准确率。`,
    },
    {
      minute: "盘口",
      type: "盘口复盘",
      side: "neutral",
      text: `赛前大小球：${marketSummary?.total?.label || "--"}；赛前让球：${marketSummary?.spread?.label || "--"}。`,
    },
  ];
}

function actualScoreFromMatch(match, research = {}) {
  const matchScore = match?.score || {};
  if (match?.finished && Number.isFinite(Number(matchScore.home)) && Number.isFinite(Number(matchScore.away))) {
    return {
      completed: true,
      home: Number(matchScore.home),
      away: Number(matchScore.away),
      source: match.footballData?.status ? "football-data.org" : "本地赛程",
    };
  }
  const espn = research.structured?.espn || {};
  if (espn.completed && Number.isFinite(Number(espn.score?.home)) && Number.isFinite(Number(espn.score?.away))) {
    return {
      completed: true,
      home: Number(espn.score.home),
      away: Number(espn.score.away),
      source: espn.mode || "ESPN",
    };
  }
  return { completed: false, home: null, away: null, source: "" };
}

function actualScoreLabel(match, research = {}) {
  const actual = actualScoreFromMatch(match, research);
  return actual.completed ? `${actual.home}-${actual.away}` : "";
}

function buildSimulationTactic({ side, team, lineup, xg, opponentXg, goalDiff, signals, weather }) {
  const formation = lineup?.formation || "4-3-3";
  const xgEdge = Number(xg) - Number(opponentXg);
  const isStronger = xgEdge >= 0.35;
  const isWeaker = xgEdge <= -0.35;
  const shapeNote = simulationFormationNote(formation);
  const approach = isStronger
    ? "主动压迫，争取把比赛推到对方半场"
    : isWeaker
    ? "中低位防守，依靠反击和定位球制造机会"
    : "稳控中场，避免过早拉开阵型";
  const attackLane = /3-5-2|3-4-/.test(formation)
    ? "边翼卫前插和肋部二点进攻"
    : /4-2-3-1/.test(formation)
    ? "双后腰保护下的前腰串联"
    : isStronger
    ? "边路提速后倒三角回做"
    : "快速纵向推进和身后球";
  const defensivePlan = isWeaker
    ? "防线保持紧凑，优先封锁禁区弧顶"
    : "前场就地反抢，丢球后限制对手第一脚出球";
  const setPiecePlan = isStronger
    ? "定位球主攻后点和二次进攻"
    : "定位球更偏向抢第一点后快速回收";
  const weatherRisk = weather?.available && Number(weather.current?.windSpeed) >= 24
    ? "风速偏高，长传和高球落点不稳定"
    : weather?.available && Number(weather.current?.precipitationProbability) >= 45
    ? "降水概率偏高，地面推进失误率上升"
    : "天气未形成明显负面约束";
  const injuryText = lineup?.injuryRisk && lineup.injuryRisk !== "未见明显信号"
    ? `伤停风险${lineup.injuryRisk}，轮换深度需要关注`
    : "阵容风险较低";
  const injuryScore = side === "home" ? signals?.homeInjuryScore : signals?.awayInjuryScore;

  return {
    side,
    team: teamLabel(team),
    formation,
    shapeNote,
    approach,
    attackLane,
    defensivePlan,
    setPiecePlan,
    risk: `${injuryText}；${weatherRisk}`,
    injuryScore: Number(injuryScore || 0),
    squadCount: lineup?.squadCount ?? team?.squadCount ?? null,
    source: lineup?.source || "官方首发未公布，按名单结构和网页战术信号推演",
  };
}

function simulationFormationNote(formation) {
  if (/4-2-3-1/.test(formation)) return "中路保护更完整，适合先稳后压";
  if (/3-5-2|3-4-/.test(formation)) return "边翼卫参与度高，角球和传中权重上升";
  if (/4-4-2/.test(formation)) return "双前锋便于压迫中卫，但中场覆盖要谨慎";
  if (/4-3-3/.test(formation)) return "三前锋拉开宽度，边路和反抢是主要入口";
  return "按常规国家队结构进行战术推演";
}

function buildSimulationLayeredReport({
  match,
  research,
  weather,
  expectedGoals,
  probabilities,
  scorePortfolio,
  marketSummary,
  homeTactic,
  awayTactic,
  rhythm,
  corners,
  cards,
  goalDiff,
  confidence,
}) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  const form = research.structured?.formGuide || research.signals?.form || {};
  const fifa = research.structured?.fifa || {};
  const fifaTeams = fifa.teams || {};
  const lineup = research.structured?.lineupProjection || {};
  const homeRank = fifaTeams.home?.rank ? `#${fifaTeams.home.rank}` : "暂无";
  const awayRank = fifaTeams.away?.rank ? `#${fifaTeams.away.rank}` : "暂无";
  const homeForm = simulationFormLine(form.home);
  const awayForm = simulationFormLine(form.away);
  const topScores = (scorePortfolio || []).slice(0, 4).map((item) => `${item.score} ${formatProbabilityPercent(item.probability)}`).join(" / ");
  const favoriteName = Math.abs(goalDiff) < 0.2 ? "双方接近" : goalDiff > 0 ? homeName : awayName;
  const weakerName = Math.abs(goalDiff) < 0.2 ? "双方" : goalDiff > 0 ? awayName : homeName;
  const h2h = form.headToHead?.matches
    ? `${form.headToHead.matches} 场样本，${homeName} ${form.headToHead.homeWins || 0} 胜 / 平 ${form.headToHead.draws || 0} / ${awayName} ${form.headToHead.awayWins || 0} 胜`
    : "暂未抓到稳定交锋样本";
  const refereeStrictness = simulationStrictness({ cards, probabilities, match });
  const fatigueText = simulationFatigueText(match, weather);
  const marketText = [
    marketSummary?.total?.label ? `大小球 ${marketSummary.total.label}` : "",
    marketSummary?.spread?.label ? `让球 ${marketSummary.spread.label}` : "",
  ].filter(Boolean).join("；") || "盘口摘要不足";
  const scoreConsensus = research.signals?.scoreConsensus;
  const scoreConsensusText = scoreConsensus?.available && scoreConsensus.topScores?.length
    ? `外部比分共识：${scoreConsensus.topScores.slice(0, 3).map((item) => `${item.score} ${formatProbabilityPercent(item.probability)}`).join(" / ")}，来源 ${scoreConsensus.sourceCount || 0} 个。`
    : "外部比分共识：暂未抓到可核验的推荐比分，当前主要依赖 xG、盘口和历史校准。";

  return {
    mode: "分层推演",
    headline: `按比赛时间轴模拟：${homeName} vs ${awayName}`,
    meta: [
      `赛程：${match.dateInfo?.label || "--"} · ${matchStageLabel(match)}`,
      `球场：${simulationVenueLine(match.stadium)}`,
      `推演可信度：${confidence.label} ${confidence.score}`,
    ],
    layers: [
      {
        title: "真实能力与近期状态",
        tone: "core",
        points: [
          `${homeName} xG ${expectedGoals.home}，${awayName} xG ${expectedGoals.away}，模型净差 ${formatSigned(goalDiff)}。`,
          `FIFA 排名：${homeName} ${homeRank} / ${awayName} ${awayRank}；近况：${homeName} ${homeForm}，${awayName} ${awayForm}。`,
          `历史交锋：${h2h}。`,
        ],
      },
      {
        title: "战术体系与适配",
        tone: "tactic",
        points: [
          `${homeName}：${homeTactic.formation}，${homeTactic.approach}；主要入口是${homeTactic.attackLane}。`,
          `${awayName}：${awayTactic.formation}，${awayTactic.approach}；主要入口是${awayTactic.attackLane}。`,
          `阵容可信度 ${lineup.confidence?.label || "--"} ${lineup.confidence?.score ?? "--"}；${homeTactic.shapeNote}，${awayTactic.shapeNote}。`,
        ],
      },
      {
        title: "环境与比赛节奏",
        tone: "venue",
        points: [
          `${rhythm.tempo}节奏，${rhythm.control}。`,
          `${simulationWeatherLine(weather)}；${fatigueText}。`,
          `环境结论：${rhythm.weather}。`,
        ],
      },
      {
        title: "对位克制",
        tone: "duel",
        points: [
          `${favoriteName}更可能掌握推进主动权，${weakerName}需要靠防守落位和反击质量保持比赛弹性。`,
          `关键区域：${homeName}的${homeTactic.attackLane} vs ${awayName}的${awayTactic.defensivePlan}。`,
          `定位球：${homeName}角球约 ${corners.home} 个，${awayName}约 ${corners.away} 个；${corners.handicap}。`,
        ],
      },
      {
        title: "裁判尺度与身体对抗",
        tone: "discipline",
        points: [
          `模拟严格度 ${refereeStrictness.label}，总罚牌约 ${cards.total} 张。`,
          `${homeName}罚牌约 ${cards.home} 张，${awayName}约 ${cards.away} 张；${cards.handicap}。`,
          `${refereeStrictness.reason}`,
        ],
      },
      {
        title: "近期层与心理层",
        tone: "mental",
        points: [
          `${simulationRecentLayer({ match, form, probabilities })}`,
          `${simulationMentalLayer({ match, probabilities, goalDiff })}`,
          `盘口心理：${marketText}。`,
        ],
      },
      {
        title: "模型校正",
        tone: "model",
        points: [
          `候选比分：${topScores || "--"}。`,
          scoreConsensusText,
          `角球/罚牌校正：总角球 ${corners.total}，总罚牌 ${cards.total}。`,
          `推荐口径：比分优先服从最高概率比分，大小球和让球若与比分方向冲突则降级为观望。`,
        ],
      },
    ],
  };
}

function simulationFormLine(side) {
  if (!side?.matches) return "暂无近10场样本";
  const wins = side.wins ?? 0;
  const draws = side.draws ?? 0;
  const losses = side.losses ?? 0;
  const goalsFor = Number(side.goalsForAvg ?? side.goalsForPerMatch);
  const goalsAgainst = Number(side.goalsAgainstAvg ?? side.goalsAgainstPerMatch);
  const goalText = Number.isFinite(goalsFor) && Number.isFinite(goalsAgainst)
    ? `，场均 ${goalsFor.toFixed(1)} / 失 ${goalsAgainst.toFixed(1)}`
    : "";
  return `${side.matches} 场 ${wins}胜${draws}平${losses}负${goalText}`;
}

function matchStageLabel(match) {
  if (match?.type === "group") return `小组 ${match.group || ""}`.trim();
  const labels = {
    r32: "三十二强",
    r16: "十六强",
    qf: "四分之一决赛",
    sf: "半决赛",
    final: "决赛",
    third: "三四名决赛",
  };
  return labels[String(match?.type || "").toLowerCase()] || match?.group || "赛程";
}

function simulationVenueLine(stadium = {}) {
  const rawVenue = stadium.fifaName || stadium.name || "";
  const rawCity = stadium.city || "";
  const venue = SIMULATION_VENUE_ZH[rawVenue] || SIMULATION_VENUE_ZH[stadium.name] || SIMULATION_VENUE_ZH[stadium.fifaName] || rawVenue || "待定球场";
  const city = SIMULATION_CITY_ZH[rawCity] || rawCity || "待定城市";
  return `${venue} · ${city}`;
}

function simulationWeatherLine(weather) {
  if (!weather?.available) return "天气暂不可用";
  const current = weather.current || {};
  return [
    current.condition || "天气待确认",
    Number.isFinite(Number(current.temperature)) ? `${current.temperature}C` : "",
    Number.isFinite(Number(current.windSpeed)) ? `风速 ${current.windSpeed} km/h` : "",
    Number.isFinite(Number(current.humidity)) ? `湿度 ${current.humidity}%` : "",
  ].filter(Boolean).join("，");
}

function simulationFatigueText(match, weather) {
  const lateKickoff = Number(match.dateInfo?.hour) >= 20;
  const hot = weather?.available && Number(weather.current?.temperature) >= 28;
  const humid = weather?.available && Number(weather.current?.humidity) >= 75;
  if (hot && humid) return "高温高湿会降低下半场连续冲刺质量";
  if (lateKickoff) return "晚场比赛体能节奏相对稳定，但注意下半场换人窗口";
  return "赛程时间对体能影响中性";
}

function simulationStrictness({ cards, probabilities, match }) {
  const total = Number(cards.total || 0);
  const knockout = /r16|r32|qf|sf|final|third/i.test(match.type);
  const drawTension = Number(probabilities.draw || 0) >= 0.27;
  if (total >= 5 || knockout) {
    return {
      label: "偏严",
      reason: knockout ? "淘汰赛或关键阶段容错更低，战术犯规价值上升。" : "总罚牌期望偏高，身体对抗会更影响节奏。",
    };
  }
  if (total <= 3 && !drawTension) {
    return {
      label: "偏松",
      reason: "胜负概率分化较明显，比赛可能更多通过控球和空间推进解决。",
    };
  }
  return {
    label: "中性",
    reason: "允许一定身体对抗，但禁区前沿和转换犯规仍会带来黄牌风险。",
  };
}

function simulationRecentLayer({ match, form, probabilities }) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  if (form.home?.matches || form.away?.matches) {
    return `近期层：${homeName} ${simulationFormLine(form.home)}；${awayName} ${simulationFormLine(form.away)}。`;
  }
  return `近期层：暂缺稳定近10场样本，使用 FIFA 排名、盘口和网页摘要补足。主胜 ${formatProbabilityPercent(probabilities.homeWin)}，平 ${formatProbabilityPercent(probabilities.draw)}，客胜 ${formatProbabilityPercent(probabilities.awayWin)}。`;
}

function simulationMentalLayer({ match, probabilities, goalDiff }) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  if (Math.abs(goalDiff) < 0.25 || probabilities.draw >= 0.28) {
    return "心理层：胜负分歧不大，先丢球的一方会明显提高边路和定位球投入。";
  }
  const favorite = goalDiff > 0 ? homeName : awayName;
  const underdog = goalDiff > 0 ? awayName : homeName;
  return `心理层：${favorite}承担主动进攻压力，${underdog}更适合把比赛拖入低比分和反击节奏。`;
}

function buildSimulationRhythm({ match, probabilities, expectedGoals, goalDiff, weather }) {
  const total = Number(expectedGoals.total || 0);
  const tempo = total >= 3.05
    ? "偏快"
    : total <= 2.15
    ? "偏慢"
    : "中速";
  const favoriteSide = Math.abs(goalDiff) < 0.2 ? "even" : goalDiff >= 0 ? "home" : "away";
  const favoriteName = favoriteSide === "even" ? "双方" : teamLabel(match[favoriteSide]);
  const weatherDrag = weather?.available && (
    Number(weather.current?.windSpeed) >= 24 ||
    Number(weather.current?.precipitationProbability) >= 45 ||
    Number(weather.current?.humidity) >= 80
  );
  return {
    tempo,
    control: favoriteSide === "even" ? "控球权预计接近，比赛更依赖转换效率" : `${favoriteName}预计拥有更多推进回合`,
    pressure: probabilities.draw >= 0.28 ? "平局权重偏高，双方会在中段降低冒险程度" : "胜负概率分化较明显，落后一方会更早提速",
    weather: weatherDrag ? "天气可能压低传控质量和射门稳定性" : "天气对节奏影响有限",
  };
}

function buildSimulationPhases({
  match,
  expectedGoals,
  probabilities,
  primaryScore,
  homeTactic,
  awayTactic,
  corners,
  cards,
  rhythm,
  goalDiff,
}) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  const favoriteSide = Math.abs(goalDiff) < 0.2 ? "even" : goalDiff >= 0 ? "home" : "away";
  const favoriteName = favoriteSide === "even" ? "双方" : teamLabel(match[favoriteSide]);
  const dogName = favoriteSide === "home" ? awayName : favoriteSide === "away" ? homeName : "双方";
  const homeGoals = Number(primaryScore?.homeGoals || 0);
  const awayGoals = Number(primaryScore?.awayGoals || 0);
  const totalGoals = Math.max(1, homeGoals + awayGoals);
  const phaseDefs = [
    ["0-15", "开局试探与压迫触发", 0.13, "前压强度", "第一波抢开局"],
    ["16-30", "边路推进与定位球累积", 0.18, "边路推进", "角球与二点球"],
    ["31-45+", "上半场收束与风险控制", 0.16, "中场保护", "避免临近半场失误"],
    ["46-60", "半场调整窗口", 0.17, "阵型修正", "换边后的第一轮压迫"],
    ["61-75", "换人提速与对抗升级", 0.2, "替补冲击", "体能下降后的空间"],
    ["76-90+", "收官阶段与比分管理", 0.16, "比分管理", "定位球和反击风险"],
  ];
  let runningHomeXg = 0;
  let runningAwayXg = 0;

  return phaseDefs.map(([range, title, share, focus, risk], index) => {
    const lateBoost = index >= 4 ? 1.08 : 1;
    const homeShare = clamp(share * (1 + (goalDiff > 0 ? 0.05 : -0.02)) * lateBoost, 0.08, 0.26);
    const awayShare = clamp(share * (1 + (goalDiff < 0 ? 0.05 : -0.02)) * lateBoost, 0.08, 0.26);
    const homeXgPart = Number((Number(expectedGoals.home || 0) * homeShare).toFixed(2));
    const awayXgPart = Number((Number(expectedGoals.away || 0) * awayShare).toFixed(2));
    runningHomeXg += homeXgPart;
    runningAwayXg += awayXgPart;
    const cornerTilt = index === 1 || index === 4 ? "偏高" : index === 5 && Math.abs(homeGoals - awayGoals) <= 1 ? "后段上升" : "常规";
    const cardRisk = index >= 4 || Number(cards.total || 0) >= 5 ? "偏高" : probabilities.draw >= 0.28 ? "中等偏高" : "中等";
    const dominant = favoriteSide === "even"
      ? index >= 4 ? "落后一方更主动" : "双方交替控场"
      : index >= 5 && Math.abs(homeGoals - awayGoals) <= 1
      ? `${dogName}会提高冒险程度`
      : `${favoriteName}更容易掌握推进主动权`;
    const tactic = favoriteSide === "away" ? awayTactic : homeTactic;

    return {
      range,
      title,
      focus,
      dominant,
      xg: `${homeName} ${homeXgPart.toFixed(2)} / ${awayName} ${awayXgPart.toFixed(2)}`,
      cumulativeXg: `${homeName} ${runningHomeXg.toFixed(2)} / ${awayName} ${runningAwayXg.toFixed(2)}`,
      cornerRisk: cornerTilt,
      cardRisk,
      risk,
      text: `${rhythm.tempo}节奏下，${dominant}；主要入口是${tactic.attackLane}，该阶段重点观察${focus}，风险点为${risk}。`,
    };
  });
}

function buildSimulationKeyDuels({ match, homeTactic, awayTactic, expectedGoals, corners, cards, goalDiff }) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  const favorite = Math.abs(goalDiff) < 0.2 ? "双方接近" : goalDiff > 0 ? homeName : awayName;
  const dog = goalDiff > 0 ? awayName : goalDiff < 0 ? homeName : "双方";
  return [
    {
      title: `${homeName}推进入口 vs ${awayName}防线保护`,
      edge: goalDiff >= 0.2 ? homeName : Math.abs(goalDiff) < 0.2 ? "均势" : awayName,
      detail: `${homeName}主要依靠${homeTactic.attackLane}，${awayName}需要执行${awayTactic.defensivePlan}。`,
    },
    {
      title: `${awayName}转换效率 vs ${homeName}反抢质量`,
      edge: goalDiff <= -0.2 ? awayName : Math.abs(goalDiff) < 0.2 ? "均势" : homeName,
      detail: `${awayName}的进攻入口是${awayTactic.attackLane}，如果被${homeName}前场反抢压住，客队射门质量会明显下降。`,
    },
    {
      title: "定位球与角球二次进攻",
      edge: corners.home === corners.away ? "均势" : corners.home > corners.away ? homeName : awayName,
      detail: `模拟角球 ${homeName} ${corners.home}-${corners.away} ${awayName}，总角球约 ${corners.total}，更可能由边路压迫和二点球形成。`,
    },
    {
      title: "身体对抗与牌面风险",
      edge: cards.home === cards.away ? "均势" : cards.home > cards.away ? `${homeName}风险更高` : `${awayName}风险更高`,
      detail: `模拟罚牌 ${homeName} ${cards.home}-${cards.away} ${awayName}，总牌约 ${cards.total}；${dog}在落后或受压时更容易付出犯规成本。`,
    },
    {
      title: "模型强弱差与比分弹性",
      edge: favorite,
      detail: `xG 对比为 ${homeName} ${expectedGoals.home} / ${awayName} ${expectedGoals.away}，若早段进球，比赛会从中低节奏转向更开放的反击场景。`,
    },
  ];
}

function buildSimulationTriggers({
  match,
  probabilities,
  expectedGoals,
  primaryScore,
  marketSummary,
  corners,
  cards,
  rhythm,
  weather,
}) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  const score = primaryScore?.score || "0-0";
  const totalGoals = Number(expectedGoals.total || 0);
  const triggers = [
    {
      label: "首球触发",
      level: probabilities.draw >= 0.28 ? "高" : "中",
      text: `若 30 分钟前出现首球，${score} 的静态路径会被打破，落后一方会更早提高边路投入，角球期望上浮约 0.6-1.0。`,
    },
    {
      label: "换人窗口",
      level: totalGoals >= 2.8 ? "中高" : "中",
      text: `60 分钟后若仍是平局或一球差，替补速度点会放大转换空间，比分候选会向 ${marketSummary?.total?.label || "大小球临界"} 方向重新校验。`,
    },
    {
      label: "牌面约束",
      level: Number(cards.total || 0) >= 5 ? "高" : "中",
      text: `若任一边后腰或中卫早早染黄，防区前沿保护会下降，${homeName} 与 ${awayName} 的禁区前二点球都会更危险。`,
    },
    {
      label: "定位球放大",
      level: Number(corners.total || 0) >= 10 ? "高" : "中",
      text: `模拟总角球 ${corners.total}，当连续角球出现时，比分更容易从低比分路径跳到 2 球以上路径。`,
    },
  ];
  if (weather?.available) {
    triggers.push({
      label: "天气扰动",
      level: Number(weather.current?.windSpeed) >= 24 || Number(weather.current?.precipitationProbability) >= 45 ? "中高" : "低",
      text: `${simulationWeatherLine(weather)}；天气主要影响长传落点、门将处理球和远射质量。`,
    });
  } else {
    triggers.push({
      label: "天气扰动",
      level: "待确认",
      text: "天气源暂不可用时，模型按中性环境处理；深度更新抓到天气后会重新校验节奏。"
    });
  }
  triggers.push({
    label: "末段比分管理",
    level: rhythm.tempo === "偏快" ? "中高" : "中",
    text: `75 分钟后领先方更倾向压缩中路并保护禁区弧顶，落后一方会把进攻转向传中、二点球和定位球。`,
  });
  return triggers;
}

function buildSimulationCorners({ match, derivativeMarkets, expectedGoals, goalDiff }) {
  const market = derivativeMarkets?.corners || {};
  const expected = Number(market.expected) || clamp(8.8 + Number(expectedGoals.total || 2.4) * 0.25, 7, 12);
  const side = derivativeTotalSide(market.total);
  const total = alignCountToMarketSide(Math.max(5, Math.round(expected)), market.total?.line, side, 5, 16);
  const xgEdge = Number(expectedGoals.home || 0) - Number(expectedGoals.away || 0);
  const homeShare = clamp(0.5 + xgEdge * 0.08 + goalDiff * 0.03, 0.34, 0.66);
  const aligned = alignCornerCountsToHandicap({
    home: clamp(Math.round(total * homeShare), 1, total - 1),
    total,
    market,
  });
  return {
    home: aligned.home,
    away: aligned.away,
    total,
    expected: Number(expected.toFixed(1)),
    line: market.total?.line ?? null,
    side,
    recommendation: market.total?.recommendation?.pick || "角球大小观望",
    handicap: market.handicap?.recommendation?.pick || "角球让球观望",
    sourceCount: market.sourceCount || 0,
  };
}

function buildSimulationCards({ match, derivativeMarkets, probabilities, goalDiff }) {
  const market = derivativeMarkets?.cards || {};
  const expected = Number(market.expected) || clamp(3.4 + Math.abs(goalDiff) * 0.28 + ((probabilities.draw || 0) >= 0.28 ? 0.25 : 0), 2.4, 6.2);
  const side = derivativeTotalSide(market.total);
  const total = alignCountToMarketSide(Math.max(2, Math.round(expected)), market.total?.line, side, 2, 10);
  const pressureSide = market.handicap?.pressureSide || (goalDiff >= 0 ? "away" : "home");
  const pressureShare = clamp(0.54 + Math.abs(goalDiff) * 0.035, 0.52, 0.68);
  const homeShare = pressureSide === "home" ? pressureShare : 1 - pressureShare;
  const home = clamp(Math.round(total * homeShare), 0, total);
  const away = total - home;
  return {
    home,
    away,
    total,
    expected: Number(expected.toFixed(1)),
    line: market.total?.line ?? null,
    side,
    recommendation: market.total?.recommendation?.pick || "罚牌大小观望",
    handicap: market.handicap?.recommendation?.pick || "罚牌让球观望",
    pressureSide,
    sourceCount: market.sourceCount || 0,
  };
}

function derivativeTotalSide(totalMarket = {}) {
  if (["over", "under", "watch"].includes(totalMarket?.side)) {
    return totalMarket.side;
  }
  const over = Number(totalMarket.over);
  const under = Number(totalMarket.under);
  return derivativePickSide(over, under);
}

function derivativePickSide(over, under, edgeThreshold = 0.025) {
  const overValue = Number(over);
  const underValue = Number(under);
  const threshold = Number(edgeThreshold);
  if (!Number.isFinite(overValue) || !Number.isFinite(underValue)) return "watch";
  if (Math.abs(overValue - underValue) < (Number.isFinite(threshold) ? threshold : 0.025)) return "watch";
  return overValue > underValue ? "over" : "under";
}

function alignCountToMarketSide(total, line, side, min, max) {
  const value = Number(total);
  const marketLine = Number(line);
  if (!Number.isFinite(value) || !Number.isFinite(marketLine) || side === "watch") {
    return clamp(Math.round(value || min), min, max);
  }
  if (side === "over" && value <= marketLine) {
    return clamp(Math.floor(marketLine) + 1, min, max);
  }
  if (side === "under" && value >= marketLine) {
    return clamp(Math.ceil(marketLine) - 1, min, max);
  }
  return clamp(Math.round(value), min, max);
}

function alignCornerCountsToHandicap({ home, total, market }) {
  let homeCorners = clamp(Number(home) || 1, 1, Math.max(1, total - 1));
  let awayCorners = total - homeCorners;
  const handicap = market?.handicap || {};
  const line = Number(handicap.line);
  const favoriteSide = handicap.favoriteSide;
  const favoriteCover = Number(handicap.favoriteCover);
  const underdogCover = Number(handicap.underdogCover);
  if (!Number.isFinite(line) || !["home", "away"].includes(favoriteSide)) {
    return { home: homeCorners, away: awayCorners };
  }

  const favoriteWantsCover = Number.isFinite(favoriteCover) && Number.isFinite(underdogCover) && favoriteCover > underdogCover + 0.03;
  const diff = () => favoriteSide === "home" ? homeCorners - awayCorners : awayCorners - homeCorners;
  let guard = 0;
  while (favoriteWantsCover && diff() <= line && guard < 12) {
    if (favoriteSide === "home" && awayCorners > 1) {
      homeCorners += 1;
      awayCorners -= 1;
    } else if (favoriteSide === "away" && homeCorners > 1) {
      awayCorners += 1;
      homeCorners -= 1;
    } else {
      break;
    }
    guard += 1;
  }
  while (!favoriteWantsCover && diff() >= line && guard < 24) {
    if (favoriteSide === "home" && homeCorners > 1) {
      homeCorners -= 1;
      awayCorners += 1;
    } else if (favoriteSide === "away" && awayCorners > 1) {
      awayCorners -= 1;
      homeCorners += 1;
    } else {
      break;
    }
    guard += 1;
  }
  return { home: homeCorners, away: awayCorners };
}

function buildSimulationEvents({ match, primaryScore, homeTactic, awayTactic, corners, cards, rhythm, phases = [], triggers = [] }) {
  const events = [];
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  const homeGoals = Number(primaryScore?.homeGoals ?? 0);
  const awayGoals = Number(primaryScore?.awayGoals ?? 0);
  const favoriteSide = homeGoals === awayGoals
    ? (homeTactic.injuryScore <= awayTactic.injuryScore ? "home" : "away")
    : homeGoals > awayGoals ? "home" : "away";
  const favoriteName = favoriteSide === "home" ? homeName : awayName;
  const dogName = favoriteSide === "home" ? awayName : homeName;
  const favoriteTactic = favoriteSide === "home" ? homeTactic : awayTactic;
  const dogTactic = favoriteSide === "home" ? awayTactic : homeTactic;

  events.push({
    minute: "0-10",
    side: "match",
    type: "开局脚本",
    text: `${rhythm.tempo}节奏开局，${homeName}以${homeTactic.formation}展开，${awayName}以${awayTactic.formation}回应。`,
  });
  events.push({
    minute: `${stableMinute(match, "first-chance", 12, 19)}'`,
    side: favoriteSide,
    type: "推进机会",
    text: `${favoriteName}通过${favoriteTactic.attackLane}形成第一波连续推进，但最后一传被压缩。`,
  });
  events.push({
    minute: "16-30",
    side: corners.home >= corners.away ? "home" : "away",
    type: "阶段变化",
    text: phases[1]?.text || `比赛进入边路推进阶段，${corners.home >= corners.away ? homeName : awayName}更容易把进攻转化为角球。`,
  });
  events.push({
    minute: `${stableMinute(match, "corner", 20, 31)}'`,
    side: corners.home >= corners.away ? "home" : "away",
    type: "角球",
    text: `${corners.home >= corners.away ? homeName : awayName}边路连续冲击制造角球，模拟全场角球比约 ${corners.home}-${corners.away}。`,
  });

  for (const event of simulationGoalEvents({ match, side: "home", goals: homeGoals, tactic: homeTactic })) {
    events.push(event);
  }
  for (const event of simulationGoalEvents({ match, side: "away", goals: awayGoals, tactic: awayTactic })) {
    events.push(event);
  }

  const cardSide = cards.home >= cards.away ? "home" : "away";
  events.push({
    minute: `${stableMinute(match, "card", 34, 48)}'`,
    side: cardSide,
    type: "黄牌",
    text: `${cardSide === "home" ? homeName : awayName}在防守转换中被迫犯规，模拟罚牌比约 ${cards.home}-${cards.away}。`,
  });
  events.push({
    minute: "HT",
    side: "match",
    type: "半场校准",
    text: phases[2]?.text || `半场前后会重新校验压迫强度和二点球保护，若仍是平局，双方冒险程度暂不拉满。`,
  });
  events.push({
    minute: `${stableMinute(match, "adjust", 58, 66)}'`,
    side: "match",
    type: "战术调整",
    text: `${dogName}加强${dogTactic.attackLane}，${favoriteName}则更重视${favoriteTactic.defensivePlan}。`,
  });
  events.push({
    minute: `${stableMinute(match, "sub-window", 62, 74)}'`,
    side: dogName === homeName ? "home" : dogName === awayName ? "away" : "match",
    type: "换人窗口",
    text: triggers.find((item) => item.label === "换人窗口")?.text || `落后一方或受压方会优先增加速度点，冲击对手边后卫身后空间。`,
  });
  events.push({
    minute: `${stableMinute(match, "trigger-card", 68, 79)}'`,
    side: cards.home >= cards.away ? "home" : "away",
    type: "牌面触发",
    text: triggers.find((item) => item.label === "牌面约束")?.text || `关键防区若出现早牌，会改变禁区前沿的保护尺度。`,
  });
  events.push({
    minute: `${stableMinute(match, "late", 76, 86)}'`,
    side: "match",
    type: "收官走势",
    text: `${rhythm.pressure}，末段更可能出现定位球和二点球争夺，而不是持续开放对攻。`,
  });
  events.push({
    minute: "85-90+",
    side: "match",
    type: "末段触发",
    text: triggers.find((item) => item.label === "末段比分管理")?.text || `领先方压缩中路，落后一方通过传中和定位球寻求最后机会。`,
  });

  return events
    .sort((a, b) => eventMinuteValue(a.minute) - eventMinuteValue(b.minute))
    .slice(0, 14);
}

function simulationGoalEvents({ match, side, goals, tactic }) {
  const name = teamLabel(match[side]);
  const ranges = side === "home"
    ? [[24, 37], [52, 65], [72, 84], [10, 21]]
    : [[31, 44], [57, 72], [78, 88], [14, 25]];
  const texts = [
    "边路压迫后的二次进攻",
    "中路连续传导后的禁区前沿机会",
    "定位球后的混战二点",
    "反击中的纵向推进",
  ];
  const out = [];
  for (let index = 0; index < goals; index += 1) {
    const [from, to] = ranges[index] || [82, 90];
    const minute = stableMinute(match, `${side}-goal-${index}`, from, to);
    out.push({
      minute: `${minute}'`,
      side,
      type: "进球",
      text: `${name}通过${texts[index % texts.length]}打开局面，战术来源是${tactic.attackLane}。`,
    });
  }
  return out;
}

function buildSimulationConfidence({ lineup, research, derivativeMarkets }) {
  const lineupScore = Number(lineup.confidence?.score || 45);
  const sourceCount = Number(research.signals?.sourceCount || 0);
  const derivativeSources = Number(derivativeMarkets?.corners?.sourceCount || 0) + Number(derivativeMarkets?.cards?.sourceCount || 0);
  const score = Math.round(clamp(34 + lineupScore * 0.3 + Math.min(22, sourceCount * 0.55) + Math.min(12, derivativeSources * 1.8), 35, 88));
  return {
    score,
    label: score >= 74 ? "较高" : score >= 58 ? "中" : "偏低",
  };
}

function stableMinute(match, label, min, max) {
  return stableInteger(`${match.id || match.sortKey || ""}:${label}`, min, max);
}

function stableInteger(seed, min, max) {
  const from = Math.ceil(Number(min));
  const to = Math.floor(Number(max));
  if (!Number.isFinite(from) || !Number.isFinite(to) || to <= from) return from;
  let hash = 2166136261;
  const text = String(seed || "");
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return from + (Math.abs(hash) % (to - from + 1));
}

function eventMinuteValue(value) {
  const text = String(value || "");
  if (/^HT$/i.test(text)) return 45;
  if (/^FT$/i.test(text)) return 100;
  const range = text.match(/^(\d+)\s*-\s*(\d+)/);
  if (range) return Number(range[1]);
  const minute = text.match(/\d+/);
  return minute ? Number(minute[0]) : 999;
}

function buildDerivativeMarkets({ match, probs, research, totalGoals, goalDiff, weather }) {
  const cornerSignals = research.signals?.corners || {};
  const cardSignals = research.signals?.cards || {};
  const corners = buildCornerDerivativeMarket({ match, probs, signals: cornerSignals, totalGoals, goalDiff });
  const cards = buildCardDerivativeMarket({ match, probs, signals: cardSignals, goalDiff, weather });
  const sourceTotal = Number(corners.sourceCount || 0) + Number(cards.sourceCount || 0);
  const sourceDiagnostics = buildDerivativeSourceDiagnostics(research, { corners, cards });
  const recommendations = [
    corners.total.recommendation,
    corners.handicap.recommendation,
    cards.total.recommendation,
    cards.handicap.recommendation,
  ].filter(Boolean);

  return {
    available: true,
    marketBacked: sourceTotal > 0,
    sourceSummary: sourceTotal > 0
      ? `已纳入角球盘口/推荐信号 ${corners.sourceCount || 0} 条，罚牌盘口/推荐信号 ${cards.sourceCount || 0} 条`
      : sourceDiagnostics.filteredResults > 0
      ? `已搜索 ${sourceDiagnostics.searchedGroups} 组附加盘来源、筛出 ${sourceDiagnostics.filteredResults} 条相关摘要，但未解析到可核验盘口线`
      : "未抓到稳定角球/罚牌盘口源，当前仅展示模型基准与观望提示",
    sourceDiagnostics,
    corners,
    cards,
    recommendations,
  };
}

const DERIVATIVE_SEARCH_GROUP_IDS = new Set([
  "corners-market",
  "cards-market",
  "special-odds-cn",
  "corners-cn",
  "cards-cn",
  "kaiyun-derivative-cn",
  "leisu-derivative-cn",
  "pinnacle-corners-cards",
  "fanduel-corners-cards",
  "rotowire-corners-cards",
  "oddschecker-corners-cards",
  "oddspedia-corners-cards",
  "oddsportal-corners-cards",
  "betexplorer-corners-cards",
  "flashscore-corners-cards",
  "global-props-corners-cards",
  "bookmaker-props-cn",
  "bookmaker-props-en",
  "euro-books-derivative",
  "us-books-derivative",
  "global-odds-aggregators",
  "asia-cn-markets",
  "stats-corners-cards",
]);

function buildDerivativeSourceDiagnostics(research, markets = {}) {
  const groups = arrayFrom(research?.searchGroups).filter((group) => DERIVATIVE_SEARCH_GROUP_IDS.has(group.id));
  const crawled = arrayFrom(research?.crawled).filter((page) =>
    /角球|罚牌|黄牌|红牌|corner|card|booking|props|盘口|odds/i.test(`${page.groupLabel || ""} ${page.title || ""} ${page.text || ""}`)
  );
  const directEntries = arrayFrom(research?.directSources?.entries);
  const filteredResults = groups.reduce((sum, group) => sum + arrayFrom(group.results).length, 0);
  const rawResults = groups.reduce((sum, group) => sum + Number(group.rawCount || 0), 0);
  const sourceCount = Number(markets.corners?.sourceCount || 0) + Number(markets.cards?.sourceCount || 0);
  const sourceQualityScore = Number(markets.corners?.sourceQuality?.score || 0) + Number(markets.cards?.sourceQuality?.score || 0);
  const sourceQuality = {
    score: Number(sourceQualityScore.toFixed(2)),
    label: derivativeSourceQualityLabel(sourceQualityScore, {
      direct: Number(markets.corners?.sourceQuality?.direct || 0) + Number(markets.cards?.sourceQuality?.direct || 0),
      cache: Number(markets.corners?.sourceQuality?.cache || 0) + Number(markets.cards?.sourceQuality?.cache || 0),
      aggregate: Number(markets.corners?.sourceQuality?.aggregate || 0) + Number(markets.cards?.sourceQuality?.aggregate || 0),
      web: Number(markets.corners?.sourceQuality?.web || 0) + Number(markets.cards?.sourceQuality?.web || 0),
    }),
    direct: Number(markets.corners?.sourceQuality?.direct || 0) + Number(markets.cards?.sourceQuality?.direct || 0),
    cache: Number(markets.corners?.sourceQuality?.cache || 0) + Number(markets.cards?.sourceQuality?.cache || 0),
    aggregate: Number(markets.corners?.sourceQuality?.aggregate || 0) + Number(markets.cards?.sourceQuality?.aggregate || 0),
    web: Number(markets.corners?.sourceQuality?.web || 0) + Number(markets.cards?.sourceQuality?.web || 0),
  };
  const targetDomains = [
    ["leisu.com", "雷速/Leisu"],
    ["kaiyun.com", "开云/Kaiyun"],
    ["bet365", "bet365"],
    ["pinnacle", "Pinnacle"],
    ["fanduel", "FanDuel"],
    ["rotowire", "RotoWire"],
    ["oddspedia", "Oddspedia"],
    ["oddsportal", "OddsPortal"],
    ["oddschecker", "OddsChecker"],
    ["betfair", "Betfair"],
    ["betway", "Betway"],
    ["unibet", "Unibet"],
    ["williamhill", "William Hill"],
    ["betmgm", "BetMGM"],
    ["caesars", "Caesars"],
    ["footystats", "FootyStats"],
    ["statbunker", "StatBunker"],
  ].map(([needle, label]) => {
    const searchHits = groups.reduce((sum, group) => {
      return sum + arrayFrom(group.results).filter((result) =>
        `${result.domain || ""} ${result.url || ""} ${result.title || ""} ${result.snippet || ""}`.toLowerCase().includes(needle.toLowerCase())
      ).length;
    }, 0);
    const directHits = directEntries.filter((entry) =>
      `${entry.domain || ""} ${entry.url || ""} ${entry.groupLabel || ""} ${entry.text || ""}`.toLowerCase().includes(needle.toLowerCase())
    ).length;
    const hits = searchHits + directHits;
    return {
      label,
      domain: needle,
      hits,
      status: directHits > 0 ? "直连采纳" : hits > 0 ? "命中搜索摘要" : "未命中/可能阻断",
    };
  });
  const topGroups = groups
    .map((group) => ({
      id: group.id,
      label: group.label,
      rawCount: Number(group.rawCount || 0),
      resultCount: arrayFrom(group.results).length,
    }))
    .filter((group) => group.rawCount || group.resultCount)
    .sort((a, b) => b.resultCount - a.resultCount || b.rawCount - a.rawCount)
    .slice(0, 5);

  return {
    searchedGroups: groups.length,
    rawResults,
    filteredResults,
    directResults: directEntries.length,
    crawledPages: crawled.length,
    sourceCount,
    sourceQuality,
    sourceState: sourceCount > 0
      ? "已命中可用附加盘信号"
      : filteredResults > 0
      ? "有相关摘要，但未解析到盘口线"
      : "目标源暂无可用摘要",
    targetDomains,
    topGroups,
    note: sourceCount > 0
      ? "已把可核验角球/罚牌盘口或推荐信号纳入模型；Pinnacle 直连命中时优先使用网页盘口线。"
      : "角球/罚牌附加盘常在临场才开放，且博彩公司页面经常登录、地区或反爬限制；当前只保留模型基准与来源状态。",
  };
}

function buildCornerDerivativeMarket({ match, probs, signals, totalGoals, goalDiff }) {
  const expected = clamp(8.7 + (totalGoals - 2.45) * 0.85 + Math.abs(goalDiff) * 0.38 + ((probs.btts || 0.5) - 0.5) * 0.55, 6.8, 12.6);
  const sourceCount = Number(signals.sourceCount || 0);
  const sourceQuality = normalizeDerivativeSourceQuality(signals.sourceQuality, sourceCount);
  const parsedTotalLine = positiveMarketLine(signals.totalLine);
  const totalMode = parsedTotalLine ? "web_line" : sourceCount > 0 ? "web_signal" : "model_fallback";
  const totalLine = parsedTotalLine
    ? parsedTotalLine
    : fallbackCornerTotalLine(expected, totalGoals, goalDiff);
  const signalLean = (signals.overLean || 0) - (signals.underLean || 0);
  const over = clamp(0.5 + (expected - totalLine) * 0.085 + signalLean * 0.035, 0.36, 0.68);
  const under = 1 - over;
  const totalEdge = Math.abs(over - under);
  const totalSide = totalMode === "model_fallback"
    ? "watch"
    : derivativePickSide(over, under, parsedTotalLine ? 0.02 : 0.035);
  const totalPickOver = totalSide === "over";
  const totalRecommendation = totalMode === "model_fallback"
    ? {
        market: "角球大小",
        pick: "角球大小观望（暂无稳定盘口源）",
        confidence: "低",
        reason: `未抓到可核验角球盘口，模型角球期望 ${expected.toFixed(1)}，基准线 ${formatTotalLine(totalLine)} 仅用于比赛节奏参考。`,
      }
    : totalSide === "watch"
    ? {
        market: "角球大小",
        pick: "角球大小观望",
        confidence: "低",
        reason: `${derivativeSourceText(sourceCount, totalMode)}，模型角球期望 ${expected.toFixed(1)}，大/小概率差 ${(totalEdge * 100).toFixed(1)} 个百分点，优势不足，按模拟推演保持观望。`,
      }
    : {
        market: "角球大小",
        pick: `${totalPickOver ? "大于" : "小于"} ${formatTotalLine(totalLine)} 个角球倾向`,
        confidence: derivativeConfidence(totalEdge, sourceCount, sourceQuality),
        reason: `${derivativeSourceText(sourceCount, totalMode)}，模型角球期望 ${expected.toFixed(1)}，${totalPickOver ? "大角球" : "小角球"}概率 ${(Math.max(over, under) * 100).toFixed(1)}%。`,
      };

  const favoriteSide = goalDiff >= 0 ? "home" : "away";
  const dogSide = favoriteSide === "home" ? "away" : "home";
  const favoriteName = teamLabel(match[favoriteSide]);
  const dogName = teamLabel(match[dogSide]);
  const parsedHandicapLine = positiveMarketLine(signals.handicapLine);
  const handicapMode = parsedHandicapLine ? "web_line" : sourceCount > 0 ? "web_signal" : "model_fallback";
  const handicapLine = parsedHandicapLine
    ? parsedHandicapLine
    : Math.abs(goalDiff) >= 1.3 ? 1.5 : 0.5;
  const favoriteSignal = favoriteSide === "home"
    ? (signals.homeHandicapLean || 0) - (signals.awayHandicapLean || 0)
    : (signals.awayHandicapLean || 0) - (signals.homeHandicapLean || 0);
  const favoriteCornerEdge = clamp(Math.abs(goalDiff) * 0.72 + Math.max(0, totalGoals - 2.2) * 0.18, 0.1, 2.6);
  const favoriteCover = clamp(0.5 + (favoriteCornerEdge - handicapLine) * 0.08 + favoriteSignal * 0.025, 0.38, 0.66);
  const handicapPickFavorite = favoriteCover >= 0.53;
  const handicapProbability = handicapPickFavorite ? favoriteCover : 1 - favoriteCover;
  const cornerHandicapTight = Math.max(favoriteCover, 1 - favoriteCover) < 0.53;
  const handicapRecommendation = handicapMode === "model_fallback"
    ? {
        market: "角球让球",
        pick: "角球让球观望（暂无稳定盘口源）",
        confidence: "低",
        reason: `未抓到可核验角球让球盘口，模型角球差约 ${favoriteCornerEdge.toFixed(1)}，基准线 ${formatTotalLine(handicapLine)} 只用于强弱对照。`,
      }
    : {
        market: "角球让球",
        pick: cornerHandicapTight
          ? "角球让球观望"
          : handicapPickFavorite
          ? `${favoriteName} 角球 -${formatTotalLine(handicapLine)} 谨慎关注`
          : `${dogName} 角球 +${formatTotalLine(handicapLine)} 更稳`,
        confidence: derivativeConfidence(Math.abs(favoriteCover - 0.5), sourceCount, sourceQuality),
        reason: cornerHandicapTight
          ? `${derivativeSourceText(sourceCount, handicapMode)}，强弱差推导角球差约 ${favoriteCornerEdge.toFixed(1)}，两侧概率接近，暂不强推。`
          : `${derivativeSourceText(sourceCount, handicapMode)}，强弱差推导角球差约 ${favoriteCornerEdge.toFixed(1)}，推荐侧概率 ${(handicapProbability * 100).toFixed(1)}%。`,
      };

  return {
    label: "角球",
    expected: Number(expected.toFixed(1)),
    evidence: signals.evidence || [],
    sourceCount,
    sourceQuality,
    marketBacked: sourceCount > 0,
    sourceSummary: sourceCount > 0
      ? `已抓取 ${sourceCount} 条角球盘口/推荐信号`
      : "暂无稳定角球盘口源，以下为模型基准参考",
    total: {
      line: totalLine,
      lineSource: parsedTotalLine ? "网页盘口线" : sourceCount > 0 ? "网页信号校准" : "模型基准线",
      lineSourceType: totalMode,
      over: Number(over.toFixed(4)),
      under: Number(under.toFixed(4)),
      side: totalSide,
      recommendation: totalRecommendation,
    },
    handicap: {
      line: handicapLine,
      favoriteSide,
      favoriteName,
      favoriteCover: Number(favoriteCover.toFixed(4)),
      underdogName: dogName,
      underdogCover: Number((1 - favoriteCover).toFixed(4)),
      lineSource: parsedHandicapLine ? "网页盘口线" : sourceCount > 0 ? "网页信号校准" : "模型基准线",
      lineSourceType: handicapMode,
      recommendation: handicapRecommendation,
    },
  };
}

function buildCardDerivativeMarket({ match, probs, signals, goalDiff, weather }) {
  const knockoutBoost = /r16|r32|qf|sf|final|third/i.test(match.type) ? 0.22 : 0;
  const weatherBoost = weather?.available && Number(weather.current?.precipitationProbability) >= 45 ? 0.12 : 0;
  const expected = clamp(3.65 + Math.abs(goalDiff) * 0.24 + ((probs.draw || 0.24) >= 0.28 ? 0.2 : 0) + knockoutBoost + weatherBoost, 2.6, 6.4);
  const sourceCount = Number(signals.sourceCount || 0);
  const sourceQuality = normalizeDerivativeSourceQuality(signals.sourceQuality, sourceCount);
  const parsedTotalLine = positiveMarketLine(signals.totalLine);
  const totalMode = parsedTotalLine ? "web_line" : sourceCount > 0 ? "web_signal" : "model_fallback";
  const totalLine = parsedTotalLine
    ? parsedTotalLine
    : fallbackCardTotalLine(expected, probs, goalDiff);
  const signalLean = (signals.overLean || 0) - (signals.underLean || 0);
  const over = clamp(0.5 + (expected - totalLine) * 0.095 + signalLean * 0.035, 0.36, 0.69);
  const under = 1 - over;
  const totalEdge = Math.abs(over - under);
  const totalSide = totalMode === "model_fallback"
    ? "watch"
    : derivativePickSide(over, under, parsedTotalLine ? 0.02 : 0.035);
  const totalPickOver = totalSide === "over";
  const totalRecommendation = totalMode === "model_fallback"
    ? {
        market: "罚牌大小",
        pick: "罚牌大小观望（暂无稳定盘口源）",
        confidence: "低",
        reason: `未抓到可核验罚牌盘口，模型罚牌期望 ${expected.toFixed(1)}，基准线 ${formatTotalLine(totalLine)} 仅用于裁判尺度参考。`,
      }
    : totalSide === "watch"
    ? {
        market: "罚牌大小",
        pick: "罚牌大小观望",
        confidence: "低",
        reason: `${derivativeSourceText(sourceCount, totalMode)}，模型罚牌期望 ${expected.toFixed(1)}，大/小概率差 ${(totalEdge * 100).toFixed(1)} 个百分点，优势不足，按模拟推演保持观望。`,
      }
    : {
        market: "罚牌大小",
        pick: `${totalPickOver ? "大于" : "小于"} ${formatTotalLine(totalLine)} 张罚牌倾向`,
        confidence: derivativeConfidence(totalEdge, sourceCount, sourceQuality),
        reason: `${derivativeSourceText(sourceCount, totalMode)}，模型罚牌期望 ${expected.toFixed(1)}，${totalPickOver ? "大罚牌" : "小罚牌"}概率 ${(Math.max(over, under) * 100).toFixed(1)}%。`,
      };

  const pressureSide = Math.abs(goalDiff) < 0.25
    ? ((signals.homeHandicapLean || 0) >= (signals.awayHandicapLean || 0) ? "home" : "away")
    : goalDiff >= 0 ? "away" : "home";
  const otherSide = pressureSide === "home" ? "away" : "home";
  const pressureName = teamLabel(match[pressureSide]);
  const otherName = teamLabel(match[otherSide]);
  const parsedHandicapLine = positiveMarketLine(signals.handicapLine);
  const handicapMode = parsedHandicapLine ? "web_line" : sourceCount > 0 ? "web_signal" : "model_fallback";
  const handicapLine = parsedHandicapLine || 0.5;
  const pressureSignal = pressureSide === "home"
    ? (signals.homeHandicapLean || 0) - (signals.awayHandicapLean || 0)
    : (signals.awayHandicapLean || 0) - (signals.homeHandicapLean || 0);
  const pressureEdge = clamp(Math.abs(goalDiff) * 0.42 + (1 - Math.abs((probs.homeWin || 0) - (probs.awayWin || 0))) * 0.08, 0.12, 1.5);
  const pressureCover = clamp(0.5 + (pressureEdge - handicapLine) * 0.075 + pressureSignal * 0.025, 0.39, 0.65);
  const pickPressure = pressureCover >= 0.52;
  const handicapProbability = pickPressure ? pressureCover : 1 - pressureCover;
  const cardHandicapTight = Math.max(pressureCover, 1 - pressureCover) < 0.53;
  const handicapRecommendation = handicapMode === "model_fallback"
    ? {
        market: "罚牌让球",
        pick: "罚牌让球观望（暂无稳定盘口源）",
        confidence: "低",
        reason: `未抓到可核验罚牌让球盘口，模型罚牌差约 ${pressureEdge.toFixed(1)}，基准线 ${formatTotalLine(handicapLine)} 只用于受压方判断。`,
      }
    : {
        market: "罚牌让球",
        pick: cardHandicapTight
          ? "罚牌让球观望"
          : pickPressure
          ? `${pressureName} 罚牌 +${formatTotalLine(handicapLine)} 方向`
          : `${otherName} 罚牌 +${formatTotalLine(handicapLine)} 方向`,
        confidence: derivativeConfidence(Math.abs(pressureCover - 0.5), sourceCount, sourceQuality),
        reason: cardHandicapTight
          ? `${derivativeSourceText(sourceCount, handicapMode)}，受压方/对抗强度推导罚牌差约 ${pressureEdge.toFixed(1)}，两侧概率接近，暂不强推。`
          : `${derivativeSourceText(sourceCount, handicapMode)}，受压方/对抗强度推导罚牌差约 ${pressureEdge.toFixed(1)}，推荐侧概率 ${(handicapProbability * 100).toFixed(1)}%。`,
      };

  return {
    label: "罚牌",
    expected: Number(expected.toFixed(1)),
    evidence: signals.evidence || [],
    sourceCount,
    sourceQuality,
    marketBacked: sourceCount > 0,
    sourceSummary: sourceCount > 0
      ? `已抓取 ${sourceCount} 条罚牌盘口/推荐信号`
      : "暂无稳定罚牌盘口源，以下为模型基准参考",
    total: {
      line: totalLine,
      lineSource: parsedTotalLine ? "网页盘口线" : sourceCount > 0 ? "网页信号校准" : "模型基准线",
      lineSourceType: totalMode,
      over: Number(over.toFixed(4)),
      under: Number(under.toFixed(4)),
      side: totalSide,
      recommendation: totalRecommendation,
    },
    handicap: {
      line: handicapLine,
      pressureSide,
      pressureName,
      pressureCover: Number(pressureCover.toFixed(4)),
      oppositeName: otherName,
      oppositeCover: Number((1 - pressureCover).toFixed(4)),
      lineSource: parsedHandicapLine ? "网页盘口线" : sourceCount > 0 ? "网页信号校准" : "模型基准线",
      lineSourceType: handicapMode,
      recommendation: handicapRecommendation,
    },
  };
}

function derivativeConfidence(edge, sourceCount = 0, sourceQuality = null) {
  const value = Math.abs(Number(edge) || 0);
  const quality = normalizeDerivativeSourceQuality(sourceQuality, sourceCount);
  if (Number(sourceCount || 0) <= 0 || quality.score <= 0) return "低";
  if (quality.score >= 2.25 && value >= 0.16) return "中";
  if (quality.score >= 1 && value >= 0.1) return "中低";
  return "低";
}

function normalizeDerivativeSourceQuality(sourceQuality, sourceCount = 0) {
  const score = Number(sourceQuality?.score ?? sourceQuality?.sourceWeight ?? 0);
  if (Number.isFinite(score) && score > 0) {
    return {
      score: Number(score.toFixed(2)),
      label: sourceQuality.label || derivativeSourceQualityLabel(score, sourceQuality),
      direct: Number(sourceQuality.direct || 0),
      cache: Number(sourceQuality.cache || 0),
      aggregate: Number(sourceQuality.aggregate || 0),
      web: Number(sourceQuality.web || 0),
      domains: arrayFrom(sourceQuality.domains).slice(0, 6),
      latestCapturedAt: sourceQuality.latestCapturedAt || "",
    };
  }
  const count = Number(sourceCount || 0);
  return {
    score: count > 0 ? Math.min(count * 0.25, 1) : 0,
    label: count > 0 ? "低" : "无",
    direct: 0,
    cache: 0,
    aggregate: 0,
    web: count,
    domains: [],
    latestCapturedAt: "",
  };
}

function derivativeSourceText(sourceCount = 0, mode = "web_signal") {
  if (sourceCount <= 0) return "暂未抓到稳定网页盘口，按模型弱参考";
  if (mode === "web_line") return `已纳入 ${sourceCount} 条网页盘口/推荐信号，并解析到盘口线`;
  return `已纳入 ${sourceCount} 条网页盘口/推荐信号，但未解析到明确盘口线，按模型基准线校准`;
}

function fallbackCornerTotalLine(expected, totalGoals, goalDiff) {
  let line = expected >= 10.35 ? 10.5 : expected <= 8.35 ? 8.5 : 9.5;
  if (totalGoals >= 3.1 && Math.abs(goalDiff) >= 1.15 && line < 10.5) line += 1;
  if (totalGoals <= 2.05 && Math.abs(goalDiff) < 0.55 && line > 8.5) line -= 1;
  return clamp(line, 7.5, 11.5);
}

function fallbackCardTotalLine(expected, probs, goalDiff) {
  let line = expected >= 4.45 ? 4.5 : expected <= 3.25 ? 3.5 : 4;
  if ((probs.draw || 0) >= 0.3 && Math.abs(goalDiff) < 0.45 && line < 4.5) line += 0.5;
  if (Math.abs(goalDiff) >= 1.6 && line > 3.5) line -= 0.5;
  return clamp(line, 3.5, 5.5);
}

function positiveMarketLine(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : null;
}

function weatherGoalImpact(weather, venueSignals) {
  const current = weather.current || {};
  let impact = 0;
  const temp = Number(current.temperature);
  const humidity = Number(current.humidity);
  const wind = Number(current.windSpeed);
  const gust = Number(current.windGusts);
  const precip = Number(current.precipitationProbability);
  const roofModifier = venueSignals?.roofScore > 0 ? 0.55 : 1;

  if (Number.isFinite(temp) && temp >= 30) impact -= 0.1;
  if (Number.isFinite(temp) && temp <= 6) impact -= 0.06;
  if (Number.isFinite(humidity) && humidity >= 80 && temp >= 24) impact -= 0.06;
  if (Number.isFinite(wind) && wind >= 24) impact -= 0.08;
  if (Number.isFinite(gust) && gust >= 40) impact -= 0.06;
  if (Number.isFinite(precip) && precip >= 55) impact -= 0.08;

  return Number((impact * roofModifier).toFixed(3));
}

function altitudeGoalImpact(meters) {
  const value = Number(meters);
  if (!Number.isFinite(value)) return { total: 0, diff: 0 };
  if (value >= 1800) return { total: -0.13, diff: 0 };
  if (value >= 1200) return { total: -0.08, diff: 0 };
  if (value >= 700) return { total: -0.03, diff: 0 };
  return { total: 0, diff: 0 };
}

function buildMarketSummary({ match, probs, primaryScore, totalLines, spreadLine }) {
  return {
    total: buildTotalMarketSummary({ probs, primaryScore, totalLines }),
    spread: buildSpreadMarketSummary({ match, spreadLine }),
    btts: buildBttsMarketSummary(probs),
  };
}

function buildTotalMarketSummary({ probs, primaryScore, totalLines }) {
  const market = totalLines?.market?.available ? totalLines.market : totalLines?.twoPointFive;
  const line = Number(market?.line ?? 2.5);
  const over = Number(market?.over ?? probs?.over25);
  const under = Number(market?.under ?? probs?.under25);
  if (!Number.isFinite(line) || !Number.isFinite(over) || !Number.isFinite(under)) {
    return { available: false, label: "暂无盘口", pick: "大小球观望", confidence: "低", side: "watch" };
  }

  const scoreTotal = (primaryScore?.homeGoals ?? 0) + (primaryScore?.awayGoals ?? 0);
  const lineLabel = formatTotalLine(line);
  const sourceLabel = totalLines?.market?.available ? `盘口线 ${lineLabel}` : "常规 2.5 线";
  const scoreSide = scoreTotal > line ? "over" : scoreTotal < line ? "under" : "push";
  const probabilitySide = over >= under ? "over" : "under";
  const topProbability = Math.max(over, under);
  const edge = Math.abs(over - under);
  const weakEdge = edge < 0.06 || topProbability < 0.55;
  const conflictsWithScore = scoreSide !== "push" && scoreSide !== probabilitySide;
  const scoreText = `最高概率比分 ${primaryScore?.score || "--"} 的总进球为 ${scoreTotal}`;

  if (weakEdge || conflictsWithScore || scoreSide === "push") {
    const note = conflictsWithScore
      ? `${scoreText}，与盘口概率方向不完全一致`
      : scoreSide === "push"
      ? `${scoreText}，刚好落在盘口线附近`
      : `盘口概率差 ${(edge * 100).toFixed(1)} 个百分点，优势不足`;
    return {
      available: true,
      side: "watch",
      line,
      over,
      under,
      probability: topProbability,
      confidence: "低",
      consistent: false,
      label: `观望 · 大 ${formatProbabilityPercent(over)} / 小 ${formatProbabilityPercent(under)}`,
      pick: "大小球观望",
      reason: `${sourceLabel}：大 ${formatProbabilityPercent(over)}、小 ${formatProbabilityPercent(under)}；${note}，不强推大小球。`,
    };
  }

  const isOver = probabilitySide === "over";
  return {
    available: true,
    side: probabilitySide,
    line,
    over,
    under,
    probability: topProbability,
    confidence: confidenceLabel(topProbability - 0.5),
    consistent: true,
    label: `${isOver ? "大于" : "小于"} ${lineLabel} · ${formatProbabilityPercent(topProbability)}`,
    pick: `${isOver ? "大于" : "小于"} ${lineLabel} 球倾向`,
    reason: `${sourceLabel} ${isOver ? "大球" : "小球"}概率 ${formatProbabilityPercent(topProbability)}，${scoreText}，方向一致。`,
  };
}

function buildSpreadMarketSummary({ match, spreadLine }) {
  if (!spreadLine?.available) {
    return { available: false, label: "暂无盘口", pick: "让球盘观望", confidence: "低", side: "watch" };
  }

  const lineLabel = formatTotalLine(spreadLine.line);
  const favoriteCover = Number(spreadLine.favoriteCover);
  const underdogCover = Number(spreadLine.underdogCover);
  const dogName = spreadLine.favoriteSide === "home" ? teamLabel(match.away) : teamLabel(match.home);
  const favoritePick = `${spreadLine.favoriteName} -${lineLabel}`;
  const dogPick = `${dogName} +${lineLabel}`;
  if (!Number.isFinite(favoriteCover) || !Number.isFinite(underdogCover)) {
    return {
      available: true,
      side: "watch",
      confidence: "低",
      consistent: false,
      label: "观望 · 概率不足",
      pick: "让球盘观望",
      reason: "盘口赔率结构不完整，暂不强推让球方向。",
    };
  }

  if (favoriteCover >= 0.56 && favoriteCover >= underdogCover) {
    return {
      available: true,
      side: "favorite",
      line: spreadLine.line,
      probability: favoriteCover,
      confidence: confidenceLabel(favoriteCover - 0.5),
      consistent: true,
      label: `${favoritePick} · ${formatProbabilityPercent(favoriteCover)}`,
      pick: `${favoritePick} 可关注`,
      reason: `模型穿盘概率 ${formatProbabilityPercent(favoriteCover)}，盘口赔率 ${formatAmerican(spreadLine.favoriteOdds)}。`,
    };
  }

  if (underdogCover >= 0.56 && underdogCover > favoriteCover) {
    return {
      available: true,
      side: "underdog",
      line: spreadLine.line,
      probability: underdogCover,
      confidence: confidenceLabel(underdogCover - 0.5),
      consistent: true,
      label: `${dogPick} · ${formatProbabilityPercent(underdogCover)}`,
      pick: `${dogPick} 更稳`,
      reason: `${spreadLine.favoriteName}是盘口让方，模型穿 -${lineLabel} 的概率 ${formatProbabilityPercent(favoriteCover)}，受让方向 ${formatProbabilityPercent(underdogCover)}。`,
    };
  }

  return {
    available: true,
    side: "watch",
    line: spreadLine.line,
    probability: Math.max(favoriteCover, underdogCover),
    confidence: "低",
    consistent: false,
    label: `观望 · 让方 ${formatProbabilityPercent(favoriteCover)} / 受让 ${formatProbabilityPercent(underdogCover)}`,
    pick: "让球盘观望",
    reason: `让球盘两侧概率接近，模型穿盘 ${formatProbabilityPercent(favoriteCover)}，受让 ${formatProbabilityPercent(underdogCover)}。`,
  };
}

function buildBttsMarketSummary(probs) {
  const yes = Number(probs?.btts);
  if (!Number.isFinite(yes)) return { available: false, label: "--", pick: "双方进球观望", confidence: "低" };
  const no = 1 - yes;
  const side = yes >= no ? "yes" : "no";
  const probability = Math.max(yes, no);
  return {
    available: true,
    side,
    probability,
    confidence: confidenceLabel(probability - 0.5),
    consistent: true,
    label: `${side === "yes" ? "是" : "否"} · ${formatProbabilityPercent(probability)}`,
    pick: `双方进球：${side === "yes" ? "是" : "否"} 倾向`,
    reason: `双方进球${side === "yes" ? "发生" : "不发生"}概率 ${formatProbabilityPercent(probability)}。`,
  };
}

function buildRecommendations({ match, probs, topScores, primaryScore, odds, research, totalLines, spreadLine, marketSummary }) {
  const out = [];
  const homeEdge = probs.homeWin - probs.awayWin;
  const strongestScore = primaryScore || topScores[0];
  const espnOdds = research.structured?.espn?.odds;
  const summary = marketSummary || buildMarketSummary({ match, probs, primaryScore: strongestScore, totalLines, spreadLine });

  if (Math.abs(homeEdge) >= 0.12) {
    const favoriteName = homeEdge > 0 ? teamLabel(match.home) : teamLabel(match.away);
    const pick = Math.abs(homeEdge) >= 0.28
      ? `${favoriteName} 胜方向`
      : `${favoriteName} 不败/平手方向`;
    out.push({
      market: "赛果方向",
      pick,
      confidence: confidenceLabel(Math.abs(homeEdge)),
      reason: `胜率差 ${(Math.abs(homeEdge) * 100).toFixed(1)} 个百分点，最可能比分 ${strongestScore.score}。`,
    });
  } else if (probs.draw >= 0.28) {
    out.push({
      market: "赛果方向",
      pick: "平局保护/谨慎观望",
      confidence: "中低",
      reason: `平局概率 ${(probs.draw * 100).toFixed(1)}%，胜负分歧不足。`,
    });
  } else {
    out.push({
      market: "赛果方向",
      pick: "胜平负暂不强推",
      confidence: "低",
      reason: "模型没有形成足够大的方向差。",
    });
  }

  if (summary.total?.available) {
    out.push({
      market: "大小球",
      pick: summary.total.pick,
      confidence: summary.total.confidence,
      reason: summary.total.reason,
    });
  }

  if (summary.spread?.available) {
    out.push({
      market: "让球盘",
      pick: summary.spread.pick,
      confidence: summary.spread.confidence,
      reason: summary.spread.reason,
    });
  }

  if (probs.btts >= 0.54) {
    out.push({
      market: "双方进球",
      pick: "双方进球：是 倾向",
      confidence: confidenceLabel(probs.btts - 0.5),
      reason: `双方进球概率 ${(probs.btts * 100).toFixed(1)}%。`,
    });
  }

  if (!odds.available && research.structured?.espn?.odds?.available) {
    out.push({
      market: "盘口参考",
      pick: "已纳入 ESPN/DraftKings 摘要",
      confidence: "中",
      reason: `${espnOdds.details || "ESPN scoreboard 提供盘口摘要"}；大小球 ${formatTotalLine(espnOdds.total?.line ?? espnOdds.overUnder)}，让球 ${espnOdds.spread?.line ? formatTotalLine(espnOdds.spread.line) : "--"}。`,
    });
  } else if (!odds.available && research.signals.oddsConsensus.evidence.length > 0) {
    out.push({
      market: "盘口参考",
      pick: "优先看来源面板再决策",
      confidence: "低",
      reason: "当前盘口只来自网页搜索/抓取摘要，不等同于实时庄家均值。",
    });
  }

  return out;
}

function buildBettingPlatform({
  match,
  research,
  odds,
  sporttery,
  marketSummary,
  derivativeMarkets,
  sportteryRecommendation,
  validation,
  quality,
  primaryScore,
  scorePortfolio,
  probabilities,
  totalLines,
  spreadLine,
}) {
  const sourceCoverage = buildBettingSourceCoverage({ research, odds, sporttery, derivativeMarkets });
  const directSources = sourceCoverage.filter((source) => source.mode === "direct" || source.mode === "api").length;
  const sourceHits = sourceCoverage.reduce((sum, source) => sum + Number(source.hits || 0), 0);
  const marketMatrix = buildBettingMarketMatrix({
    match,
    odds,
    sporttery,
    sportteryRecommendation,
    marketSummary,
    derivativeMarkets,
    primaryScore,
    scorePortfolio,
    probabilities,
    totalLines,
    spreadLine,
    sourceCoverage,
  });
  const acceptedMarkets = marketMatrix.filter((item) => item.status !== "观望" && item.status !== "缺口").length;
  const issues = arrayFrom(validation?.issues);
  const cacheSnapshot = derivativeCoverageState || {};
  const sourceHealth = {
    totalSources: GLOBAL_BETTING_SOURCE_CATALOG.length,
    sourceHits,
    directSources,
    acceptedMarkets,
    conflictCount: issues.length,
    qualityScore: quality?.score ?? null,
    qualityLabel: quality?.label || "--",
    derivativeCoverage: {
      status: cacheSnapshot.status || "idle",
      windowHours: cacheSnapshot.windowHours || 24,
      totalMatches: cacheSnapshot.totalMatches || 0,
      completeMatches: cacheSnapshot.completeMatches || 0,
      cornerMatches: cacheSnapshot.cornerMatches || 0,
      cardMatches: cacheSnapshot.cardMatches || 0,
      directEntries: cacheSnapshot.directEntries || 0,
      refreshedAt: cacheSnapshot.refreshedAt || "",
    },
  };

  return {
    available: true,
    headline: issues.length
      ? "平台已完成多源核对，存在推荐冲突并已降级处理"
      : "平台已完成多源核对，核心推荐口径一致",
    sourceHealth,
    sourceCoverage,
    marketMatrix,
    consistency: {
      ok: !issues.length,
      issues,
      anchorScore: primaryScore?.score || "--",
      anchorProbability: primaryScore?.probability ?? null,
      rule: "比分、大小球、让球、角球、罚牌、体彩推荐统一服从最高概率比分与盘口概率锚点；冲突时降级观望。",
    },
    fetchPolicy: {
      layers: [
        "结构化接口：football-data、FIFA、ESPN、Open-Meteo、中国体彩网、Pinnacle",
        "可选赔率 API：The Odds API，配置 key 后扩展请求更多盘口市场",
        "全网网页抓取：赔率聚合站、博彩公司网页、中文彩经、角球/罚牌技术统计站",
        "本地缓存：角球/罚牌直连或网页盘口命中后写入 derivative-market-cache.json",
      ],
      warning: "博彩网站经常有登录、地区、反爬和临场才开放特殊盘口的问题；平台会标记真实来源与模型兜底，不把兜底当实时盘口。",
    },
  };
}

function buildBettingSourceCoverage({ research, odds, sporttery, derivativeMarkets }) {
  const haystacks = bettingSourceHaystacks(research);
  return GLOBAL_BETTING_SOURCE_CATALOG.map((source) => {
    const hits = source.domains.reduce((sum, domain) => sum + countSourceNeedleHits(haystacks, domain), 0);
    const directHit = source.id === "sporttery"
      ? Boolean(sporttery?.available)
      : source.id === "pinnacle"
      ? Number(derivativeMarkets?.sourceDiagnostics?.directResults || 0) > 0 || source.domains.some((domain) => /pinnacle|arcadia/i.test(domain) && countSourceNeedleHits(haystacks.direct, domain) > 0)
      : source.id === "espn-draftkings"
      ? Boolean(research?.structured?.espn?.available || research?.structured?.espn?.odds?.available)
      : source.id === "odds-api"
      ? Boolean(odds?.enabled)
      : false;
    const adopted = source.id === "sporttery"
      ? Boolean(sporttery?.available)
      : source.id === "odds-api"
      ? Boolean(odds?.available)
      : source.id === "pinnacle"
      ? Number(derivativeMarkets?.sourceDiagnostics?.directResults || 0) > 0
      : hits > 0;
    const mode = directHit
      ? source.id === "odds-api" ? "api" : "direct"
      : hits > 0 ? "web" : source.requiresKey && !odds?.enabled ? "need_key" : "missing";
    const status = directHit
      ? "直连可用"
      : hits > 0
      ? "网页命中"
      : source.requiresKey && !odds?.enabled
      ? "待配置 Key"
      : "未命中/受限";
    return {
      ...source,
      hits,
      adopted,
      mode,
      status,
      marketsLabel: source.markets.join("、"),
    };
  }).sort((a, b) => Number(b.adopted) - Number(a.adopted) || b.hits - a.hits || a.label.localeCompare(b.label));
}

function bettingSourceHaystacks(research = {}) {
  const search = arrayFrom(research.searchGroups).flatMap((group) =>
    arrayFrom(group.results).map((result) => `${group.id} ${group.label} ${result.domain || ""} ${result.url || ""} ${result.title || ""} ${result.snippet || ""}`)
  );
  const crawled = arrayFrom(research.crawled).map((page) =>
    `${page.domain || ""} ${page.url || ""} ${page.title || ""} ${page.groupLabel || ""} ${page.text || ""}`
  );
  const direct = arrayFrom(research.directSources?.entries).map((entry) =>
    `${entry.domain || ""} ${entry.url || ""} ${entry.groupLabel || ""} ${entry.text || ""}`
  );
  const structured = [
    research.structured?.espn?.available ? "site.api.espn.com espn draftkings" : "",
    research.structured?.footballData?.available ? "api.football-data.org football-data" : "",
    research.structured?.fifa?.available ? "api.fifa.com fifa" : "",
  ];
  return {
    all: [...search, ...crawled, ...direct, ...structured].map((item) => String(item || "").toLowerCase()),
    direct: direct.map((item) => String(item || "").toLowerCase()),
  };
}

function countSourceNeedleHits(haystacks, needle) {
  const values = Array.isArray(haystacks) ? haystacks : haystacks?.all || [];
  const normalized = String(needle || "").toLowerCase();
  if (!normalized) return 0;
  return values.filter((item) => item.includes(normalized)).length;
}

function buildBettingMarketMatrix({
  match,
  odds,
  sporttery,
  sportteryRecommendation,
  marketSummary,
  derivativeMarkets,
  primaryScore,
  scorePortfolio,
  probabilities,
  totalLines,
  spreadLine,
  sourceCoverage,
}) {
  const sourceHit = (id) => sourceCoverage.find((source) => source.id === id)?.adopted;
  const sourceLabels = (ids) => ids
    .map((id) => sourceCoverage.find((source) => source.id === id))
    .filter((source) => source && (source.adopted || source.hits > 0 || source.mode === "direct" || source.mode === "api"));
  const resultSide = strongestResultSide(probabilities);
  const resultLabel = resultSide === "home"
    ? `${teamLabel(match.home)} 胜`
    : resultSide === "away"
    ? `${teamLabel(match.away)} 胜`
    : "平局";
  const totalSummary = marketSummary?.total || {};
  const spreadSummary = marketSummary?.spread || {};
  const bttsSummary = marketSummary?.btts || {};
  const scorePick = primaryScore?.score || scorePortfolio?.[0]?.score || "--";
  const sportteryItems = arrayFrom(sportteryRecommendation?.items);
  const corners = derivativeMarkets?.corners || {};
  const cards = derivativeMarkets?.cards || {};

  return [
    platformMarketRow({
      market: "胜平负",
      pick: resultLabel,
      probability: resultSide === "home" ? probabilities?.homeWin : resultSide === "away" ? probabilities?.awayWin : probabilities?.draw,
      status: resultSide ? "采纳" : "缺口",
      confidence: confidenceLabel(Math.max(probabilities?.homeWin || 0, probabilities?.draw || 0, probabilities?.awayWin || 0) - 0.5),
      sources: sourceLabels(["odds-api", "espn-draftkings", "sporttery", "oddspedia", "oddsportal", "tips-global"]),
      note: odds?.available ? "赔率 API 均值参与校准" : sourceHit("espn-draftkings") ? "ESPN/DraftKings 摘要参与校准" : "使用模型概率与网页倾向弱校准",
    }),
    platformMarketRow({
      market: "让球",
      pick: spreadSummary.pick || "让球盘观望",
      probability: spreadSummary.probability,
      status: spreadSummary.side === "watch" ? "观望" : "采纳",
      confidence: spreadSummary.confidence,
      line: spreadLine?.available ? spreadLine.line : null,
      sources: sourceLabels(["odds-api", "espn-draftkings", "sporttery", "oddspedia", "oddsportal", "leisu-kaiyun"]),
      note: spreadSummary.reason || "等待稳定让球盘口",
    }),
    platformMarketRow({
      market: "大小球",
      pick: totalSummary.pick || "大小球观望",
      probability: totalSummary.probability,
      status: totalSummary.side === "watch" ? "观望" : "采纳",
      confidence: totalSummary.confidence,
      line: totalSummary.line ?? totalLines?.market?.line ?? 2.5,
      sources: sourceLabels(["odds-api", "espn-draftkings", "sporttery", "oddspedia", "oddsportal", "tips-global"]),
      note: totalSummary.reason || "等待稳定大小球盘口",
    }),
    platformMarketRow({
      market: "比分",
      pick: scorePick,
      probability: primaryScore?.probability,
      status: scorePick === "--" ? "缺口" : "采纳",
      confidence: confidenceLabel(Number(primaryScore?.probability || 0)),
      sources: sourceLabels(["sporttery", "tips-global", "global-odds-aggregators", "stats-props"]),
      note: `候选比分 ${arrayFrom(scorePortfolio).slice(0, 4).map((item) => `${item.score} ${formatProbabilityPercent(item.probability)}`).join(" / ") || "--"}`,
    }),
    platformMarketRow({
      market: "双方进球",
      pick: bttsSummary.pick || "双方进球观望",
      probability: bttsSummary.probability,
      status: bttsSummary.side === "watch" ? "观望" : "采纳",
      confidence: bttsSummary.confidence,
      sources: sourceLabels(["odds-api", "espn-draftkings", "tips-global"]),
      note: bttsSummary.reason || "由进球矩阵推导",
    }),
    platformMarketRow({
      market: "角球大小",
      pick: corners.total?.recommendation?.pick || "角球大小观望",
      probability: Math.max(Number(corners.total?.over || 0), Number(corners.total?.under || 0)) || null,
      status: corners.total?.lineSourceType === "model_fallback" ? "观望" : "采纳",
      confidence: corners.total?.recommendation?.confidence,
      line: corners.total?.line,
      sources: sourceLabels(["pinnacle", "leisu-kaiyun", "oddspedia", "oddsportal", "oddschecker", "stats-props"]),
      note: corners.sourceSummary || "等待角球盘口源",
    }),
    platformMarketRow({
      market: "角球让球",
      pick: corners.handicap?.recommendation?.pick || "角球让球观望",
      probability: Math.max(Number(corners.handicap?.favoriteCover || 0), Number(corners.handicap?.underdogCover || 0)) || null,
      status: corners.handicap?.lineSourceType === "model_fallback" ? "观望" : "采纳",
      confidence: corners.handicap?.recommendation?.confidence,
      line: corners.handicap?.line,
      sources: sourceLabels(["pinnacle", "leisu-kaiyun", "oddspedia", "oddsportal", "oddschecker", "stats-props"]),
      note: corners.handicap?.recommendation?.reason || "等待角球让球盘口源",
    }),
    platformMarketRow({
      market: "罚牌大小",
      pick: cards.total?.recommendation?.pick || "罚牌大小观望",
      probability: Math.max(Number(cards.total?.over || 0), Number(cards.total?.under || 0)) || null,
      status: cards.total?.lineSourceType === "model_fallback" ? "观望" : "采纳",
      confidence: cards.total?.recommendation?.confidence,
      line: cards.total?.line,
      sources: sourceLabels(["pinnacle", "leisu-kaiyun", "oddspedia", "oddsportal", "oddschecker", "stats-props"]),
      note: cards.sourceSummary || "等待罚牌盘口源",
    }),
    platformMarketRow({
      market: "罚牌让球",
      pick: cards.handicap?.recommendation?.pick || "罚牌让球观望",
      probability: Math.max(Number(cards.handicap?.pressureCover || 0), Number(cards.handicap?.oppositeCover || 0)) || null,
      status: cards.handicap?.lineSourceType === "model_fallback" ? "观望" : "采纳",
      confidence: cards.handicap?.recommendation?.confidence,
      line: cards.handicap?.line,
      sources: sourceLabels(["pinnacle", "leisu-kaiyun", "oddspedia", "oddsportal", "oddschecker", "stats-props"]),
      note: cards.handicap?.recommendation?.reason || "等待罚牌让球盘口源",
    }),
    ...sportteryItems.slice(0, 4).map((item) => platformMarketRow({
      market: `体彩 · ${item.market}`,
      pick: item.pick,
      probability: item.probability,
      status: sporttery?.available && item.side !== "watch" ? "采纳" : "观望",
      confidence: item.confidence,
      odds: item.odds,
      sources: sourceLabels(["sporttery"]),
      note: item.reason || "中国体彩网/竞彩网官方固定奖金",
    })),
  ];
}

function platformMarketRow({ market, pick, probability, status, confidence, line, odds, sources, note }) {
  const cleanSources = arrayFrom(sources).map((source) => source.label).slice(0, 4);
  return {
    market,
    pick: pick || "--",
    probability: Number.isFinite(Number(probability)) ? Number(Number(probability).toFixed(4)) : null,
    status: status || "观望",
    confidence: confidence || "低",
    line: Number.isFinite(Number(line)) ? Number(line) : null,
    odds: Number.isFinite(Number(odds)) ? Number(odds) : null,
    sources: cleanSources,
    sourceCount: cleanSources.length,
    note: note || "",
  };
}

function strongestResultSide(probabilities = {}) {
  const rows = [
    ["home", Number(probabilities.homeWin || 0)],
    ["draw", Number(probabilities.draw || 0)],
    ["away", Number(probabilities.awayWin || 0)],
  ].sort((a, b) => b[1] - a[1]);
  return rows[0]?.[1] > 0 ? rows[0][0] : "";
}

function buildBettingToolkit({
  match,
  probabilities,
  primaryScore,
  scorePortfolio,
  marketSummary,
  derivativeMarkets,
  weather,
  research,
  validation,
}) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  const favoriteSide = probabilities.homeWin >= probabilities.awayWin ? "home" : "away";
  const favoriteName = favoriteSide === "home" ? homeName : awayName;
  const favoriteProb = Math.max(probabilities.homeWin || 0, probabilities.awayWin || 0);
  const drawProb = probabilities.draw || 0;
  const topScores = (scorePortfolio || []).slice(0, 3).map((item) => `${item.score} ${formatProbabilityPercent(item.probability)}`).join(" / ");
  const total = marketSummary?.total || {};
  const spread = marketSummary?.spread || {};
  const btts = marketSummary?.btts || {};
  const corners = derivativeMarkets?.corners || {};
  const cards = derivativeMarkets?.cards || {};
  const fifa = research.structured?.fifa?.teams || {};
  const rankGap = fifa.home?.rank && fifa.away?.rank ? Math.abs(fifa.home.rank - fifa.away.rank) : null;
  const weatherTag = weather?.available
    ? weather.estimated
      ? "天气为气候兜底"
      : "天气已实时校验"
    : "天气未校验";

  return [
    {
      title: "稳健组合",
      pick: `${favoriteName} 不败 + ${total.pick && total.side !== "watch" ? total.pick : "大小球观望"}`,
      confidence: favoriteProb >= 0.62 && total.consistent !== false ? "中高" : "中",
      body: `胜平负优势 ${formatProbabilityPercent(favoriteProb)}，平局 ${formatProbabilityPercent(drawProb)}；候选比分 ${topScores || primaryScore?.score || "--"}。`,
      tags: [spread.label || "让球观望", btts.label ? `双方进球 ${btts.label}` : "双方进球观望"],
    },
    {
      title: "半场剧本",
      pick: favoriteProb >= 0.58 ? `${favoriteName} 半场不败倾向` : "半场平局保护",
      confidence: favoriteProb >= 0.68 ? "中高" : "中低",
      body: favoriteProb >= 0.58
        ? `${favoriteName} 模型推进权更高，但若前 25 分钟射门质量不足，应降低让球穿盘预期。`
        : "两队胜负差距不足，半场更适合观察节奏和定位球数量后再判断。",
      tags: [`最高比分 ${primaryScore?.score || "--"}`, weatherTag],
    },
    {
      title: "角球附加盘",
      pick: corners.total?.recommendation?.pick || "角球大小观望",
      confidence: corners.total?.recommendation?.confidence || "低",
      body: corners.marketBacked
        ? `模型角球期望 ${corners.expected ?? "--"}，${corners.total?.lineSource || "盘口线"} ${formatTotalLine(corners.total?.line)}；让球参考：${corners.handicap?.recommendation?.pick || "观望"}。`
        : `未抓到稳定角球盘口源，当前只展示模型期望 ${corners.expected ?? "--"} 与基准线 ${formatTotalLine(corners.total?.line)}，不作为正式盘口推荐。`,
      tags: [corners.sourceSummary || `来源 ${corners.sourceCount || 0} 条`, corners.total?.lineSource || "模型基准线", corners.handicap?.recommendation?.confidence ? `让球信心 ${corners.handicap.recommendation.confidence}` : "让球信心低"],
    },
    {
      title: "罚牌附加盘",
      pick: cards.total?.recommendation?.pick || "罚牌大小观望",
      confidence: cards.total?.recommendation?.confidence || "低",
      body: cards.marketBacked
        ? `模型罚牌期望 ${cards.expected ?? "--"}，${cards.total?.lineSource || "盘口线"} ${formatTotalLine(cards.total?.line)}；让球参考：${cards.handicap?.recommendation?.pick || "观望"}。`
        : `未抓到稳定罚牌盘口源，当前只展示模型期望 ${cards.expected ?? "--"} 与基准线 ${formatTotalLine(cards.total?.line)}，不作为正式盘口推荐。`,
      tags: [cards.sourceSummary || `来源 ${cards.sourceCount || 0} 条`, cards.total?.lineSource || "模型基准线", cards.handicap?.recommendation?.confidence ? `让球信心 ${cards.handicap.recommendation.confidence}` : "让球信心低"],
    },
    {
      title: "风险核对",
      pick: validation?.ok ? "推荐口径已通过一致性检查" : "存在冲突，降级观望",
      confidence: validation?.ok ? "中" : "低",
      body: validation?.ok
        ? `FIFA 排名差 ${rankGap ?? "未完整"} 位，${weatherTag}，推荐比分与大小球/让球方向未发现硬冲突。`
        : `冲突项：${(validation?.issues || []).join("；") || "模型与盘口方向不一致"}。`,
      tags: [research.structured?.fifa?.validation?.ok ? "FIFA 已核对" : "FIFA 待补强", weather?.estimated ? "天气估算" : "天气实时"],
    },
  ];
}

function buildIntelligence24h({
  match,
  venue,
  research,
  weather,
  marketSummary,
  derivativeMarkets,
  primaryScore,
  probabilities,
  validation,
}) {
  const recentEntries = collectIntelligenceEntries(research, { onlyRecent: true, hours: 24 });
  const fallbackEntries = collectIntelligenceEntries(research, { onlyRecent: false, hours: 24 })
    .filter((entry) => !recentEntries.some((recent) => recent.url && recent.url === entry.url))
    .slice(0, 12);
  const structuredEntries = buildStructuredIntelligenceEntries({
    match,
    venue,
    research,
    weather,
    marketSummary,
    derivativeMarkets,
    primaryScore,
    probabilities,
    validation,
  });
  const entries = rankIntelligenceEntries(
    recentEntries.length
      ? [...recentEntries, ...structuredEntries, ...fallbackEntries.slice(0, 4)]
      : [...structuredEntries, ...fallbackEntries],
    match
  ).slice(0, 20);
  const classified = classifyIntelligenceEntries(entries, match);
  const sourceCount = entries.length;
  const verifiedRecentCount = recentEntries.length;
  const structuredCount = structuredEntries.length;
  const status = verifiedRecentCount ? "recent_verified" : structuredCount ? "structured_summary" : "fallback_summary";
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  const favorite = probabilities.homeWin >= probabilities.awayWin ? homeName : awayName;
  const favoriteProbability = Math.max(probabilities.homeWin || 0, probabilities.awayWin || 0);
  const edgeText = `${favorite} 胜面 ${formatProbabilityPercent(favoriteProbability)}，校准首选比分 ${primaryScore?.score || "--"}`;
  const totalText = marketSummary?.total?.pick || "大小球观望";
  const spreadText = marketSummary?.spread?.pick || "让球盘观望";
  const cornersText = derivativeMarkets?.corners?.total?.recommendation?.pick || "角球盘观望";
  const cardsText = derivativeMarkets?.cards?.total?.recommendation?.pick || "罚牌盘观望";
  const recencyText = verifiedRecentCount
    ? `已抓到 ${verifiedRecentCount} 条带发布时间的近24小时情报`
    : structuredCount
    ? `已提取 ${structuredCount} 条结构化情报，网页实时材料作为补充核对`
    : "暂未抓到可验证发布时间的近24小时网页，以下为搜索摘要补充";
  const briefTexts = classified.briefs.map((brief) => `${brief.title}：${brief.verdict}`);

  return {
    available: true,
    windowHours: 24,
    status,
    refreshedAt: new Date().toISOString(),
    sourceCount,
    verifiedRecentCount,
    structuredCount,
    sourceStats: {
      recent: recentEntries.length,
      fallback: fallbackEntries.length,
      structured: structuredEntries.length,
      crawled: arrayFrom(research?.crawled).length,
    },
    headline: `${homeName} 对 ${awayName} 近24小时情报汇总`,
    summary: [
      `${recencyText}；系统已按伤停阵容、盘口市场、战术节奏、场地天气四层重新提炼。`,
      `${edgeText}；${spreadText}；${totalText}。`,
      briefTexts.slice(0, 2).join("；") || "当前没有单一强情报，建议以模型和临场名单刷新为主。",
    ],
    keyPoints: classified.keyPoints,
    briefs: classified.briefs,
    recommendation: {
      pick: validation?.ok
        ? `${favorite} 方向优先，比分参考 ${primaryScore?.score || "--"}，${totalText}`
        : "存在模型/盘口口径冲突，胜平负与大小球均降级为谨慎观察",
      confidence: validation?.ok && verifiedRecentCount >= 2 ? "中高" : validation?.ok ? "中" : "低",
      reason: validation?.ok
        ? `${edgeText}；${spreadText}；${cornersText}；${cardsText}。`
        : `冲突项：${(validation?.issues || []).join("；") || "情报与模型方向未形成一致"}。`,
    },
    cards: classified.briefs.map((brief) => ({
      title: brief.title,
      text: `${brief.verdict}${brief.impact ? `；${brief.impact}` : ""}`,
      tone: brief.tone,
    })),
    sources: entries.slice(0, 12).map((entry) => ({
      title: entry.title || entry.domain || "情报来源",
      snippet: entry.snippet || entry.text || "",
      url: entry.url || "",
      domain: entry.domain || "",
      publishedAt: entry.publishedAt || "",
      category: entry.category || "",
      recent: entry.recent,
      structured: entry.structured,
    })),
  };
}

function buildStructuredIntelligenceEntries({
  match,
  venue,
  research,
  weather,
  marketSummary,
  derivativeMarkets,
  primaryScore,
  probabilities,
  validation,
}) {
  const homeName = teamLabel(match.home);
  const awayName = teamLabel(match.away);
  const entries = [];
  const add = (entry) => {
    if (!entry?.text) return;
    entries.push({
      title: entry.title,
      snippet: entry.text,
      text: entry.text,
      url: entry.url || "",
      domain: entry.domain || "本地结构化数据",
      publishedAt: entry.publishedAt || "",
      category: entry.category || "结构化情报",
      groupLabel: entry.groupLabel || entry.category || "结构化情报",
      bucket: entry.bucket,
      recent: false,
      structured: true,
      confidence: entry.confidence || "中",
      scoreBoost: Number(entry.scoreBoost || 0),
    });
  };

  const fifaImpact = fifaRankingImpact(research?.structured?.fifa);
  if (fifaImpact.available) {
    add({
      bucket: "tactical",
      title: "FIFA排名核对",
      category: "排名/实力",
      confidence: "高",
      scoreBoost: 12,
      text: `${fifaImpact.detail} 排名差已经纳入胜平负和比分校准。`,
    });
  }

  const formImpact = recentFormImpact(research?.signals?.form || research?.structured?.formGuide);
  if (formImpact.available) {
    add({
      bucket: "tactical",
      title: "近况与近10场",
      category: "近况",
      confidence: "中高",
      scoreBoost: 10,
      text: `${formImpact.detail} 近况差值对净胜球期望影响 ${formatSigned(formImpact.diff)}。`,
    });
  }

  const lineup = research?.structured?.lineupProjection;
  if (lineup?.available) {
    add({
      bucket: "teamNews",
      title: "阵容/伤停信号",
      category: "阵容伤停",
      confidence: lineup.confidence?.label || "中",
      scoreBoost: 9,
      text: `${homeName}预计阵型 ${lineup.home?.formation || "--"}、伤停风险 ${lineup.home?.injuryRisk || "未见明显信号"}；${awayName}预计阵型 ${lineup.away?.formation || "--"}、伤停风险 ${lineup.away?.injuryRisk || "未见明显信号"}。阵容可信度 ${lineup.confidence?.label || "--"} ${lineup.confidence?.score ?? "--"}。`,
    });
  }

  const espnOdds = research?.structured?.espn?.odds;
  const marketParts = [
    marketSummary?.spread?.pick,
    marketSummary?.total?.pick,
    marketSummary?.btts?.pick,
    derivativeMarkets?.corners?.total?.recommendation?.pick,
    derivativeMarkets?.cards?.total?.recommendation?.pick,
  ].filter(Boolean);
  if (marketParts.length || espnOdds?.available) {
    add({
      bucket: "market",
      title: "盘口/附加盘校验",
      category: "盘口市场",
      confidence: validation?.ok ? "中" : "低",
      scoreBoost: 11,
      text: `${marketParts.join("；") || "盘口方向暂不强推"}。${espnOdds?.details ? `ESPN/DraftKings 摘要：${espnOdds.details}。` : ""}${validation?.ok ? "当前推荐口径未发现硬冲突。" : `需降级观察：${arrayFrom(validation?.issues).join("；") || "模型与盘口方向不完全一致"}。`}`,
    });
  }

  const directEntries = arrayFrom(research?.directSources?.entries);
  if (directEntries.length) {
    const labels = directEntries
      .map((entry) => `${entry.kind === "cards" ? "罚牌" : "角球"}${entry.totalLine ? ` ${entry.totalLine}` : ""}${entry.handicapLine ? ` / 让 ${entry.handicapLine}` : ""}`)
      .slice(0, 4);
    add({
      bucket: "market",
      title: "角球/罚牌直连盘口",
      category: "附加盘口",
      domain: research?.directSources?.domain || "盘口缓存",
      confidence: "中高",
      scoreBoost: 13,
      text: `已读取 ${directEntries.length} 条角球/罚牌盘口或缓存：${labels.join("；")}。这些数据优先用于修正角球、罚牌推荐。`,
    });
  }

  add({
    bucket: "environment",
    title: "场地与天气",
    category: "场地天气",
    confidence: weather?.available && !weather?.estimated ? "高" : "中",
    scoreBoost: weather?.available ? 8 : 4,
    text: `${simulationVenueLine(venue)}；${simulationWeatherLine(weather)}。${weather?.estimated ? "当前天气为气候兜底，临场刷新后会重新计入节奏。" : "天气已纳入节奏和总进球修正。"}`,
  });

  add({
    bucket: "tactical",
    title: "模型与比分校准",
    category: "模型推演",
    confidence: validation?.ok ? "中高" : "低",
    scoreBoost: 8,
    text: `胜平负：${homeName} ${formatProbabilityPercent(probabilities?.homeWin)} / 平 ${formatProbabilityPercent(probabilities?.draw)} / ${awayName} ${formatProbabilityPercent(probabilities?.awayWin)}；比分首选 ${primaryScore?.score || "--"}，${primaryScore?.calibrationNote || "已做一致性校准"}。`,
  });

  return entries;
}

function rankIntelligenceEntries(entries, match) {
  const seen = new Set();
  return arrayFrom(entries)
    .filter((entry) => entry?.text || entry?.snippet || entry?.title)
    .map((entry) => {
      const text = normalizeWhitespace(entry.text || entry.snippet || entry.title || "");
      const key = normalizeWhitespace(`${entry.url || ""}|${entry.title || ""}|${text.slice(0, 140)}`).toLowerCase();
      if (seen.has(key)) return null;
      seen.add(key);
      return {
        ...entry,
        text,
        intelligenceScore: intelligenceEntryScore({ ...entry, text }, match),
      };
    })
    .filter(Boolean)
    .sort((a, b) => b.intelligenceScore - a.intelligenceScore);
}

function intelligenceEntryScore(entry, match) {
  const text = normalizeWhitespace(`${entry.title || ""} ${entry.snippet || ""} ${entry.text || ""}`).toLowerCase();
  let score = 0;
  if (entry.structured) score += 18;
  if (entry.recent) score += 12;
  if (entry.url) score += 4;
  if (entry.bucket) score += 8;
  score += Number(entry.scoreBoost || 0);
  const homeTokens = teamLookupKeys(match.home.name).slice(0, 4);
  const awayTokens = teamLookupKeys(match.away.name).slice(0, 4);
  if (homeTokens.some((token) => text.includes(token))) score += 5;
  if (awayTokens.some((token) => text.includes(token))) score += 5;
  if (/injury|lineup|squad|odds|handicap|corner|card|weather|tactical|伤停|阵容|盘口|角球|罚牌|天气|战术|彩经/.test(text)) score += 6;
  if ((entry.text || "").length > 180) score += 2;
  return score;
}

function collectIntelligenceEntries(research, options = {}) {
  const hours = Number(options.hours || 24);
  const groups = arrayFrom(research?.searchGroups);
  const crawled = arrayFrom(research?.crawled);
  const results = [];
  for (const group of groups) {
    const includeGroup =
      group.side === "intel" ||
      [
        "match-preview",
        "injury-deep",
        "tactical-preview",
        "odds-en",
        "odds-cn",
        "caijing-cn",
        "corners-market",
        "cards-market",
        "special-odds-cn",
        "corners-cn",
        "cards-cn",
        "kaiyun-derivative-cn",
        "leisu-derivative-cn",
        "pinnacle-corners-cards",
        "fanduel-corners-cards",
        "rotowire-corners-cards",
        "oddschecker-corners-cards",
        "oddspedia-corners-cards",
        "oddsportal-corners-cards",
        "betexplorer-corners-cards",
        "flashscore-corners-cards",
        "global-props-corners-cards",
        "bookmaker-props-cn",
        "bookmaker-props-en",
      ].includes(group.id);
    if (!includeGroup) continue;
    for (const result of arrayFrom(group.results)) {
      const recent = isPublishedWithinHours(result.publishedAt, hours);
      if (options.onlyRecent && !recent) continue;
      results.push({
        title: result.title,
        snippet: result.snippet,
        text: `${result.title || ""}. ${result.snippet || ""}`,
        url: result.url,
        domain: result.domain,
        publishedAt: result.publishedAt,
        groupLabel: group.label,
        category: group.side === "intel" ? "24小时情报" : group.label,
        recent,
      });
    }
  }
  for (const page of crawled) {
    if (!["intel", "match", "home", "away", "odds", "venue"].includes(page.side)) continue;
    if (options.onlyRecent) continue;
    results.push({
      title: page.title || page.h1,
      snippet: page.text,
      text: page.text,
      url: page.url,
      domain: page.domain,
      publishedAt: "",
      groupLabel: page.groupLabel,
      category: page.groupLabel,
      recent: false,
    });
  }
  return uniqueSearchResults(results).slice(0, 18);
}

function classifyIntelligenceEntries(entries, match) {
  const buckets = {
    teamNews: [],
    market: [],
    tactical: [],
    environment: [],
  };
  const keywordSets = {
    teamNews: ["injury", "injured", "suspension", "suspended", "team news", "lineup", "squad", "伤停", "受伤", "停赛", "阵容", "首发", "名单"],
    market: ["odds", "betting", "handicap", "spread", "over", "under", "corner", "card", "盘口", "赔率", "让球", "大小", "角球", "罚牌", "彩经", "推荐"],
    tactical: ["tactic", "formation", "pressing", "transition", "preview", "战术", "阵型", "压迫", "反击", "控球", "节奏"],
    environment: ["stadium", "pitch", "weather", "roof", "surface", "altitude", "球场", "天气", "草皮", "海拔", "屋顶", "场地"],
  };

  for (const entry of entries) {
    const text = normalizeWhitespace(`${entry.title || ""} ${entry.snippet || ""} ${entry.text || ""}`).toLowerCase();
    if (entry.bucket && buckets[entry.bucket]) {
      buckets[entry.bucket].push(entry);
      continue;
    }
    for (const [bucket, keywords] of Object.entries(keywordSets)) {
      if (keywords.some((keyword) => text.includes(String(keyword).toLowerCase()))) {
        buckets[bucket].push(entry);
      }
    }
  }

  const briefs = [
    buildIntelligenceBrief({
      title: "阵容伤停",
      bucket: "teamNews",
      tone: buckets.teamNews.some((entry) => entry.confidence === "高" || entry.confidence === "中高") ? "alert" : "neutral",
      entries: buckets.teamNews,
      match,
      fallback: "暂未出现明确新增伤停或首发变化，按官方名单、网页摘要和伤停信号继续监控。",
      impactFallback: "临场首发确认前，阵容项不单独改变比分结论。",
    }),
    buildIntelligenceBrief({
      title: "盘口市场",
      bucket: "market",
      tone: "market",
      entries: buckets.market,
      match,
      fallback: "盘口材料不足时，以胜平负、大小球、角球/罚牌模型和缓存盘口交叉参考。",
      impactFallback: "盘口侧若与比分或推演冲突，推荐会自动降级为观望。",
    }),
    buildIntelligenceBrief({
      title: "战术节奏",
      bucket: "tactical",
      tone: "tactic",
      entries: buckets.tactical,
      match,
      fallback: "暂无新的战术报道，按近期状态、FIFA排名和模拟推演判断比赛节奏。",
      impactFallback: "战术项主要影响控球、转换速度和总进球区间。",
    }),
    buildIntelligenceBrief({
      title: "场地天气",
      bucket: "environment",
      tone: "venue",
      entries: buckets.environment,
      match,
      fallback: "天气或场地信息不足时，先使用球场城市和气候兜底，临场刷新后再修正。",
      impactFallback: "天气项主要影响总进球、角球节奏和下半场体能。",
    }),
  ];
  const keyPoints = briefs
    .map((brief) => `${brief.title}：${brief.verdict}`)
    .slice(0, 4);

  return {
    teamNews: briefs.find((brief) => brief.bucket === "teamNews")?.verdict || "",
    market: briefs.find((brief) => brief.bucket === "market")?.verdict || "",
    tactical: briefs.find((brief) => brief.bucket === "tactical")?.verdict || "",
    environment: briefs.find((brief) => brief.bucket === "environment")?.verdict || "",
    keyPoints,
    briefs,
  };
}

function buildIntelligenceBrief({ title, bucket, tone, entries, match, fallback, impactFallback }) {
  const ranked = rankIntelligenceEntries(entries, match).slice(0, 5);
  const evidenceEntries = ranked.some((entry) => entry.structured)
    ? ranked.filter((entry) => entry.structured)
    : ranked;
  const evidence = evidenceEntries
    .map((entry) => entry.structured
      ? (entry.text || entry.snippet || entry.title || "")
      : selectEvidenceSentence(entry.text || entry.snippet || entry.title || "", [
        "injury",
        "team news",
        "lineup",
        "squad",
        "odds",
        "handicap",
        "over",
        "under",
        "corner",
        "card",
        "tactical",
        "weather",
        "ranking",
        "form",
        "伤停",
        "阵容",
        "名单",
        "盘口",
        "让球",
        "大小",
        "角球",
        "罚牌",
        "战术",
        "天气",
        "排名",
        "近况",
      ]) || entry.text || entry.snippet || entry.title || "")
    .map((text) => truncateText(localizeIntelText(text, match), 118))
    .filter(Boolean);
  const uniqueEvidence = [...new Set(evidence)].slice(0, 3);
  const sourceLabels = [...new Set(ranked.map((entry) => entry.domain || entry.category || entry.groupLabel || "结构化数据").filter(Boolean))].slice(0, 3);
  const verdict = uniqueEvidence[0] || fallback;
  const impact = uniqueEvidence.length > 1
    ? uniqueEvidence.slice(1).join("；")
    : impactFallback;
  return {
    title,
    bucket,
    tone,
    verdict,
    impact,
    evidence: uniqueEvidence,
    sourceCount: ranked.length,
    sources: sourceLabels,
    confidence: briefConfidence(ranked),
  };
}

function briefConfidence(entries) {
  if (!entries.length) return "低";
  if (entries.some((entry) => entry.confidence === "高" || entry.confidence === "中高") || entries.length >= 3) return "中高";
  if (entries.length >= 2 || entries.some((entry) => entry.structured)) return "中";
  return "低";
}

function truncateText(text, max = 120) {
  const clean = normalizeWhitespace(text);
  return clean.length > max ? `${clean.slice(0, max - 1)}…` : clean;
}

function summarizeIntelligenceBucket(entries, match, label) {
  const evidence = entries
    .map((entry) => selectEvidenceSentence(entry.text || entry.snippet || entry.title || "", [
      "injury",
      "team news",
      "lineup",
      "odds",
      "handicap",
      "over",
      "under",
      "corner",
      "card",
      "tactical",
      "weather",
      "伤停",
      "阵容",
      "盘口",
      "让球",
      "大小",
      "角球",
      "罚牌",
      "战术",
      "天气",
    ]))
    .filter(Boolean)
    .slice(0, 2)
    .map((text) => localizeIntelText(text, match));
  if (!evidence.length) return "";
  return `${label}：${evidence.join("；")}。`;
}

function localizeIntelText(text, match) {
  return replaceMatchTeamAliases(normalizeWhitespace(text), match)
    .replace(/\bteam news\b/gi, "球队情报")
    .replace(/\binjur(?:y|ies|ed)\b/gi, "伤停")
    .replace(/\bsuspensions?\b/gi, "停赛")
    .replace(/\bpredicted lineups?\b/gi, "预测首发")
    .replace(/\blineups?\b/gi, "阵容")
    .replace(/\bodds\b/gi, "赔率")
    .replace(/\bhandicap\b/gi, "让球")
    .replace(/\bover\b/gi, "大于")
    .replace(/\bunder\b/gi, "小于")
    .replace(/\bcorners?\b/gi, "角球")
    .replace(/\bcards?\b/gi, "罚牌")
    .replace(/\btactical\b/gi, "战术")
    .replace(/\bpreview\b/gi, "前瞻")
    .replace(/\bPPG\b/g, "场均积分")
    .replace(/\bWorld Cup\b/gi, "世界杯");
}

function replaceMatchTeamAliases(text, match) {
  let out = String(text || "");
  for (const team of [match?.home, match?.away]) {
    const label = teamLabel(team);
    const aliases = new Set([team?.name, team?.displayName, team?.code]);
    for (const [alias, zh] of Object.entries(TEAM_NAME_ZH)) {
      if (zh === label) aliases.add(alias);
    }
    for (const alias of [...aliases].filter(Boolean).sort((a, b) => b.length - a.length)) {
      if (!alias || alias === label) continue;
      const escaped = escapeRegExp(alias);
      const pattern = /^[A-Za-z0-9 .()'-]+$/.test(alias)
        ? new RegExp(`\\b${escaped}\\b`, "gi")
        : new RegExp(escaped, "g");
      out = out.replace(pattern, label);
    }
  }
  return out;
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function isPublishedWithinHours(value, hours = 24) {
  const timestamp = Date.parse(value || "");
  if (!Number.isFinite(timestamp)) return false;
  const delta = Date.now() - timestamp;
  return delta >= 0 && delta <= hours * 60 * 60 * 1000;
}

function validatePredictionConsistency({ primaryScore, probabilities, recommendations, marketSummary, derivativeMarkets, simulation }) {
  const issues = [];
  const scoreTotal = (primaryScore?.homeGoals ?? 0) + (primaryScore?.awayGoals ?? 0);
  const text = recommendations.map((item) => `${item.market} ${item.pick} ${item.reason}`).join(" ");
  const smallPick = text.match(/小于\s*(\d+(?:\.\d+)?)\s*球/);
  const bigPick = text.match(/大于\s*(\d+(?:\.\d+)?)\s*球/);
  if (smallPick && scoreTotal >= Number(smallPick[1])) {
    issues.push(`最高概率比分 ${primaryScore.score} 与小 ${smallPick[1]} 推荐冲突`);
  }
  if (bigPick && scoreTotal <= Number(bigPick[1])) {
    issues.push(`最高概率比分 ${primaryScore.score} 与大 ${bigPick[1]} 推荐冲突`);
  }
  const totalSummary = marketSummary?.total;
  if (totalSummary?.side === "under" && scoreTotal >= Number(totalSummary.line)) {
    issues.push(`大小球摘要与最高概率比分 ${primaryScore.score} 冲突`);
  }
  if (totalSummary?.side === "over" && scoreTotal <= Number(totalSummary.line)) {
    issues.push(`大小球摘要与最高概率比分 ${primaryScore.score} 冲突`);
  }
  addDerivativeSimulationIssue(issues, "角球", derivativeMarkets?.corners?.total, simulation?.setPieces?.corners || simulation?.corners);
  addDerivativeSimulationIssue(issues, "罚牌", derivativeMarkets?.cards?.total, simulation?.setPieces?.cards || simulation?.cards);
  return {
    ok: issues.length === 0,
    issues,
  };
}

function alignRecommendationsWithValidation(recommendations, validation) {
  const issues = arrayFrom(validation?.issues);
  if (!issues.length) return recommendations;
  return arrayFrom(recommendations).map((item) => {
    const market = String(item.market || "");
    const related = issues.filter((issue) => {
      if (/大小球/.test(market)) return /大小球|小于|大于/.test(issue);
      if (/让球/.test(market)) return /让球|穿盘|受让/.test(issue);
      if (/角球/.test(market)) return /角球/.test(issue);
      if (/罚牌/.test(market)) return /罚牌/.test(issue);
      if (/赛果|比分/.test(market)) return /比分|胜平负/.test(issue);
      return false;
    });
    if (!related.length) return item;
    return {
      ...item,
      pick: `${item.market || "推荐"}观望`,
      confidence: "低",
      reason: `一致性校验触发降级：${related.join("；")}。`,
      aligned: false,
    };
  });
}

function addDerivativeSimulationIssue(issues, label, totalMarket, simulated) {
  const side = derivativeTotalSide(totalMarket);
  const line = Number(totalMarket?.line);
  const total = Number(simulated?.total);
  if (!Number.isFinite(line) || !Number.isFinite(total) || side === "watch") return;
  if (side === "over" && total <= line) {
    issues.push(`${label}模拟总数 ${total} 与大于 ${formatTotalLine(line)} 推荐冲突`);
  }
  if (side === "under" && total >= line) {
    issues.push(`${label}模拟总数 ${total} 与小于 ${formatTotalLine(line)} 推荐冲突`);
  }
}

function buildDataChecks({ match, venue, geo, weather, elevation, research, odds, prediction }) {
  const fifa = research.structured?.fifa || {};
  const espn = research.structured?.espn || {};
  const checks = [
    {
      key: "venue",
      label: "球场",
      ok: Boolean(venue?.name || venue?.fifaName),
      level: venue?.source === "missing venue" ? "warning" : "ok",
      detail: venue?.name || venue?.fifaName
        ? `${simulationVenueLine(venue)}；来源：${venue.source || "赛程源"}`
        : "赛程源未提供球场，暂未能回填",
    },
    {
      key: "geo",
      label: "定位",
      ok: Boolean(geo?.lat && geo?.lon),
      level: geo?.lat && geo?.lon ? "ok" : "warning",
      detail: geo?.lat && geo?.lon ? `${geo.label || "已定位"}；${geo.source || "--"}` : "缺少经纬度，天气只能用城市兜底",
    },
    {
      key: "weather",
      label: "天气",
      ok: Boolean(weather?.available),
      level: weather?.estimated ? "warning" : weather?.available ? "ok" : "danger",
      detail: weather?.available
        ? `${weather.estimated ? "气候兜底" : "实时预报"}；${simulationWeatherLine(weather)}`
        : weather?.message || "天气不可用",
    },
    {
      key: "fifa",
      label: "FIFA 排名",
      ok: Boolean(fifa?.teams?.home?.rank && fifa?.teams?.away?.rank),
      level: fifa?.validation?.fresh === false ? "warning" : fifa?.teams?.home?.rank && fifa?.teams?.away?.rank ? "ok" : "warning",
      detail: fifa?.teams?.home?.rank && fifa?.teams?.away?.rank
        ? `${teamLabel(match.home)} #${fifa.teams.home.rank} / ${teamLabel(match.away)} #${fifa.teams.away.rank}；${fifa.sourceMode || "FIFA API"}；发布 ${fifa.publishedAt || "--"}`
        : fifa?.validation?.message || "排名未完整匹配",
    },
    {
      key: "odds",
      label: "盘口",
      ok: Boolean(odds?.available || espn?.odds?.available || prediction?.derivativeMarkets?.available),
      level: odds?.available || espn?.odds?.available ? "ok" : "warning",
      detail: odds?.available
        ? "已接入赔率 API 均值"
        : espn?.odds?.available
        ? "已纳入 ESPN/DraftKings 摘要"
        : prediction?.derivativeMarkets?.available
        ? prediction.derivativeMarkets.sourceSummary || "网页盘口信号 + 模型推导"
        : "暂无稳定盘口源",
    },
    {
      key: "finished",
      label: "完场状态",
      ok: true,
      level: match?.finished || espn?.completed ? "ok" : "info",
      detail: match?.finished || espn?.completed
        ? `已完场，实际比分 ${actualScoreLabel(match, research) || "--"}`
        : "未完场，使用赛前模型推演",
    },
  ];

  if (elevation?.available) {
    checks.push({
      key: "elevation",
      label: "海拔",
      ok: true,
      level: "ok",
      detail: `${Math.round(elevation.meters || 0)} 米；Open-Meteo elevation`,
    });
  }

  return checks;
}

function dataQuality({ weather, odds, research }) {
  let score = 45;
  const notes = [];
  if (weather.available) score += weather.estimated ? 8 : 15;
  else notes.push("天气预报暂不可用");
  if (odds.available) score += 25;
  else if (research.structured?.espn?.odds?.available) score += 15;
  else notes.push("未接入实时赔率 API");
  if (research.structured?.footballData?.available) score += 10;
  if (research.structured?.espn?.available) score += 10;
  if (research.structured?.sportsDb?.available) score += 5;
  if (research.structured?.fifa?.available) score += 5;
  if ((research.structured?.formGuide?.home?.matches || 0) >= 5 && (research.structured?.formGuide?.away?.matches || 0) >= 5) score += 5;
  if (research.signals.sourceCount >= 18) score += 10;
  if (research.signals.lineupScore >= 2) score += 5;
  if (!research.crawled.length) notes.push("部分网站可能阻止抓取，已保留搜索摘要");

  score = clamp(score, 0, 100);
  return {
    score: Math.round(score),
    label: score >= 80 ? "高" : score >= 60 ? "中" : "偏低",
    notes,
  };
}

function recentFormImpact(form) {
  const home = form?.home;
  const away = form?.away;
  if (!home?.matches || !away?.matches) return { available: false, diff: 0, total: 0, detail: "" };

  const ppgDiff = (home.pointsPerGame ?? 1.4) - (away.pointsPerGame ?? 1.4);
  const gdDiff = (home.goalDiffPerGame ?? 0) - (away.goalDiffPerGame ?? 0);
  const attackAverage = ((home.goalsForPerGame ?? 1.2) + (away.goalsForPerGame ?? 1.2)) / 2;
  const diff = clamp(ppgDiff * 0.16 + gdDiff * 0.18, -0.65, 0.65);
  const total = clamp((attackAverage - 1.25) * 0.16, -0.16, 0.22);
  return {
    available: true,
    diff: Number(diff.toFixed(3)),
    total: Number(total.toFixed(3)),
    detail: `主队近 ${home.matches} 场 ${home.wins ?? 0}胜${home.draws ?? 0}平${home.losses ?? 0}负，PPG ${home.pointsPerGame ?? "--"} / 净胜 ${home.goalDiffPerGame ?? "--"}；客队近 ${away.matches} 场 ${away.wins ?? 0}胜${away.draws ?? 0}平${away.losses ?? 0}负，PPG ${away.pointsPerGame ?? "--"} / 净胜 ${away.goalDiffPerGame ?? "--"}。`,
  };
}

function scoreMatrix(homeXg, awayXg, maxGoals) {
  const matrix = [];
  for (let home = 0; home <= maxGoals; home += 1) {
    const row = [];
    for (let away = 0; away <= maxGoals; away += 1) {
      row.push(poisson(home, homeXg) * poisson(away, awayXg));
    }
    matrix.push(row);
  }
  return matrix;
}

function summarizeMatrix(matrix) {
  let homeWin = 0;
  let draw = 0;
  let awayWin = 0;
  let over25 = 0;
  let under25 = 0;
  let btts = 0;
  let totalMass = 0;

  for (let home = 0; home < matrix.length; home += 1) {
    for (let away = 0; away < matrix[home].length; away += 1) {
      const p = matrix[home][away];
      totalMass += p;
      if (home > away) homeWin += p;
      else if (home === away) draw += p;
      else awayWin += p;
      if (home + away >= 3) over25 += p;
      else under25 += p;
      if (home > 0 && away > 0) btts += p;
    }
  }

  return {
    homeWin: Number((homeWin / totalMass).toFixed(4)),
    draw: Number((draw / totalMass).toFixed(4)),
    awayWin: Number((awayWin / totalMass).toFixed(4)),
    over25: Number((over25 / totalMass).toFixed(4)),
    under25: Number((under25 / totalMass).toFixed(4)),
    btts: Number((btts / totalMass).toFixed(4)),
  };
}

function buildMarketTotalLine(matrix, espnOdds) {
  const line = espnOdds?.total?.line ?? espnOdds?.overUnder;
  if (!Number.isFinite(line)) return { available: false };
  const summary = summarizeTotalLine(matrix, line);
  return {
    ...summary,
    available: true,
    provider: espnOdds.provider || "",
    overOdds: espnOdds.total?.overOdds ?? null,
    underOdds: espnOdds.total?.underOdds ?? null,
  };
}

function buildMarketSpreadLine(matrix, espnOdds, match) {
  const spread = espnOdds?.spread;
  if (!spread?.home || !spread?.away) return { available: false };
  const homeLine = Number(spread.home.line);
  const awayLine = Number(spread.away.line);
  const favoriteSide = homeLine < 0 ? "home" : awayLine < 0 ? "away" : espnOdds.favorite?.side;
  if (!["home", "away"].includes(favoriteSide)) return { available: false };
  const favoriteLine = favoriteSide === "home" ? homeLine : awayLine;
  if (!Number.isFinite(favoriteLine)) return { available: false };

  let favoriteCover = 0;
  let underdogCover = 0;
  let push = 0;
  let totalMass = 0;
  for (let home = 0; home < matrix.length; home += 1) {
    for (let away = 0; away < matrix[home].length; away += 1) {
      const probability = matrix[home][away];
      const adjusted = favoriteSide === "home"
        ? home - away + favoriteLine
        : away - home + favoriteLine;
      totalMass += probability;
      if (adjusted > 0) favoriteCover += probability;
      else if (adjusted < 0) underdogCover += probability;
      else push += probability;
    }
  }

  return {
    available: true,
    line: Math.abs(favoriteLine),
    favoriteSide,
    favoriteName: teamLabel(match[favoriteSide]),
    favoriteCover: Number((favoriteCover / totalMass).toFixed(4)),
    underdogCover: Number((underdogCover / totalMass).toFixed(4)),
    push: Number((push / totalMass).toFixed(4)),
    favoriteOdds: spread[favoriteSide]?.odds ?? null,
    underdogOdds: spread[favoriteSide === "home" ? "away" : "home"]?.odds ?? null,
  };
}

function summarizeTotalLine(matrix, line) {
  let over = 0;
  let under = 0;
  let push = 0;
  let totalMass = 0;
  const numericLine = Number(line);

  for (let home = 0; home < matrix.length; home += 1) {
    for (let away = 0; away < matrix[home].length; away += 1) {
      const probability = matrix[home][away];
      const totalGoals = home + away;
      totalMass += probability;
      if (totalGoals > numericLine) over += probability;
      else if (totalGoals < numericLine) under += probability;
      else push += probability;
    }
  }

  return {
    available: true,
    line: numericLine,
    over: Number((over / totalMass).toFixed(4)),
    under: Number((under / totalMass).toFixed(4)),
    push: Number((push / totalMass).toFixed(4)),
  };
}

function formatTotalLine(line) {
  const value = Number(line);
  if (!Number.isFinite(value)) return "--";
  return Number.isInteger(value) ? String(value) : value.toFixed(1);
}

function formatProbabilityPercent(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "--";
  return `${(number * 100).toFixed(1)}%`;
}

function formatAmerican(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "--";
  return number > 0 ? `+${number}` : String(number);
}

function poisson(k, lambda) {
  return (Math.exp(-lambda) * Math.pow(lambda, k)) / factorial(k);
}

const factorialMemo = [1];
function factorial(n) {
  if (factorialMemo[n]) return factorialMemo[n];
  let value = factorialMemo[factorialMemo.length - 1];
  for (let i = factorialMemo.length; i <= n; i += 1) {
    value *= i;
    factorialMemo[i] = value;
  }
  return factorialMemo[n];
}

async function cached(key, ttlMs, loader) {
  const now = Date.now();
  const hit = cache.get(key);
  if (hit && now - hit.created < ttlMs) return hit.value;
  if (pendingCache.has(key)) return pendingCache.get(key);
  const pending = Promise.resolve()
    .then(loader)
    .then((value) => {
      cache.set(key, { created: Date.now(), value });
      return value;
    })
    .finally(() => {
      pendingCache.delete(key);
    });
  pendingCache.set(key, pending);
  return pending;
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function withTimeout(promise, ms, fallbackValue) {
  let timer;
  return Promise.race([
    Promise.resolve(promise),
    new Promise((resolve) => {
      timer = setTimeout(() => resolve(fallbackValue), Math.max(1, Number(ms) || 1));
    }),
  ]).finally(() => clearTimeout(timer));
}

async function mapLimit(items, limit, mapper) {
  const list = arrayFrom(items);
  const concurrency = Math.max(1, Math.min(Number(limit) || 1, list.length || 1));
  const output = new Array(list.length);
  let index = 0;
  async function worker() {
    while (index < list.length) {
      const current = index;
      index += 1;
      output[current] = await mapper(list[current], current);
    }
  }
  await Promise.all(Array.from({ length: concurrency }, () => worker()));
  return output;
}

async function fetchJson(url, options = {}) {
  const text = await fetchText(url, options);
  return JSON.parse(text);
}

async function fetchText(url, options = {}) {
  if (options.preferPowerShell && process.platform === "win32") {
    return fetchTextPowerShell(url, options).catch(() => fetchTextNative(url, options));
  }
  return fetchTextNative(url, options).catch((error) => {
    if (process.platform === "win32" && shouldPowerShellFallback(url)) {
      return fetchTextPowerShell(url, options);
    }
    throw error;
  });
}

async function fetchTextNative(url, options = {}) {
  return fetchTextHttp(url, options, 0);
}

function fetchTextHttp(url, options = {}, redirectCount = 0) {
  const timeout = options.timeout || 12000;
  const maxRedirects = options.maxRedirects ?? 4;
  return new Promise((resolve, reject) => {
    let settled = false;
    let parsed;
    try {
      parsed = new URL(url);
    } catch (error) {
      reject(new Error(`无效 URL：${url}`));
      return;
    }

    const transport = parsed.protocol === "http:" ? http : https;
    const request = transport.request(
      parsed,
      {
        method: "GET",
        headers: {
          ...REQUEST_HEADERS,
          "Accept-Encoding": "gzip, deflate, br",
          ...(options.headers || {}),
        },
      },
      (response) => {
        const status = Number(response.statusCode || 0);
        const location = response.headers.location;
        if ([301, 302, 303, 307, 308].includes(status) && location && redirectCount < maxRedirects) {
          settled = true;
          response.resume();
          const nextUrl = new URL(location, parsed).toString();
          fetchTextHttp(nextUrl, options, redirectCount + 1).then(resolve, reject);
          return;
        }

        const chunks = [];
        response.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
        response.on("end", () => {
          if (settled) return;
          settled = true;
          try {
            const body = decodeHttpBody(Buffer.concat(chunks), response.headers["content-encoding"]);
            if (status < 200 || status >= 300) {
              reject(new Error(`${status} ${response.statusMessage || ""}${body ? `: ${body.slice(0, 180)}` : ""}`));
              return;
            }
            resolve(body);
          } catch (error) {
            reject(error);
          }
        });
      }
    );

    request.setTimeout(timeout, () => {
      if (settled) return;
      settled = true;
      const error = new Error(`请求超时：${timeout}ms`);
      request.destroy(error);
      reject(error);
    });
    request.on("error", (error) => {
      if (settled) return;
      settled = true;
      reject(error);
    });
    request.end();
  });
}

function decodeHttpBody(buffer, encoding = "") {
  const normalized = String(encoding || "").toLowerCase();
  const decoded = normalized.includes("br")
    ? brotliDecompressSync(buffer)
    : normalized.includes("gzip")
    ? gunzipSync(buffer)
    : normalized.includes("deflate")
    ? inflateSync(buffer)
    : buffer;
  return decoded.toString("utf8");
}

async function fetchTextPowerShell(url, options = {}) {
  const timeout = options.timeout || 18000;
  const headerJson = JSON.stringify({
    "User-Agent": REQUEST_HEADERS["User-Agent"],
    "Accept-Language": REQUEST_HEADERS["Accept-Language"],
    ...(options.headers || {}),
  });
  const command = [
    "$ProgressPreference='SilentlyContinue';",
    "$uri=$env:FETCH_URL;",
    "$headers=$env:FETCH_HEADERS | ConvertFrom-Json;",
    "$hash=@{};",
    "$headers.PSObject.Properties | ForEach-Object { $hash[$_.Name]=$_.Value };",
    "$response=Invoke-WebRequest -Uri $uri -Headers $hash -UseBasicParsing -TimeoutSec 18;",
    "$response.Content",
  ].join(" ");

  const { stdout } = await execFileAsync(
    "powershell.exe",
    ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
    {
      timeout: timeout + 5000,
      maxBuffer: 8 * 1024 * 1024,
      windowsHide: true,
      env: {
        ...process.env,
        FETCH_URL: url,
        FETCH_HEADERS: headerJson,
      },
    }
  );
  return stdout;
}

function shouldPowerShellFallback(url) {
  const host = safeHostname(url);
  return /duckduckgo|brave|google|yahoo|bing|jina/.test(host);
}

function errorPayload(error, fallback) {
  return {
    message: fallback,
    detail: error?.message || String(error),
  };
}

function arrayFrom(value) {
  return Array.isArray(value) ? value : [];
}

function cleanCity(value) {
  return String(value || "").replace(/\([^)]*\)/g, "").replace(/\/.*/g, "").trim();
}

function uniqueWords(value) {
  const parts = String(value || "")
    .split(/[, ]+/)
    .map((part) => part.trim())
    .filter(Boolean);
  return [...new Set(parts)].join(" ");
}

function nearestHourIndex(times, target) {
  let best = 0;
  let bestDelta = Infinity;
  const targetMs = new Date(target).getTime();
  times.forEach((time, idx) => {
    const delta = Math.abs(new Date(time).getTime() - targetMs);
    if (delta < bestDelta) {
      best = idx;
      bestDelta = delta;
    }
  });
  return best;
}

function numberOrNull(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function numberOrZero(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function describeWeather(code) {
  const table = {
    0: "晴朗",
    1: "大部晴朗",
    2: "局部多云",
    3: "阴天",
    45: "雾",
    48: "雾凇",
    51: "小毛毛雨",
    53: "毛毛雨",
    55: "强毛毛雨",
    61: "小雨",
    63: "中雨",
    65: "大雨",
    71: "小雪",
    73: "中雪",
    75: "大雪",
    80: "阵雨",
    81: "中等阵雨",
    82: "强阵雨",
    95: "雷暴",
    96: "雷暴伴冰雹",
    99: "强雷暴伴冰雹",
  };
  return table[code] || "未知天气";
}

function unavailable(message) {
  return {
    available: false,
    message,
  };
}

function unwrapDuckDuckGoUrl(rawUrl) {
  if (!rawUrl) return "";
  try {
    const url = new URL(rawUrl, "https://duckduckgo.com");
    const uddg = url.searchParams.get("uddg");
    return uddg ? decodeURIComponent(uddg) : url.href;
  } catch {
    return rawUrl;
  }
}

function unwrapBingUrl(rawUrl) {
  if (!rawUrl) return "";
  try {
    const url = new URL(rawUrl, "https://www.bing.com");
    if (!url.hostname.includes("bing.com")) return url.href;
    const encoded = url.searchParams.get("u");
    if (!encoded) return url.href;
    const payload = encoded.startsWith("a1") ? encoded.slice(2) : encoded;
    const padded = payload.padEnd(payload.length + ((4 - (payload.length % 4)) % 4), "=");
    const decoded = Buffer.from(padded.replaceAll("-", "+").replaceAll("_", "/"), "base64").toString("utf8");
    return decoded || url.href;
  } catch {
    return rawUrl;
  }
}

function unwrapBingNewsUrl(rawUrl) {
  if (!rawUrl) return "";
  try {
    const url = new URL(rawUrl);
    const target = url.searchParams.get("url");
    return target ? decodeURIComponent(target) : rawUrl;
  } catch {
    return rawUrl;
  }
}

function safeHostname(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

function isCrawlable(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}

function normalizeWhitespace(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function stripHtml(value) {
  return cheerio.load(String(value || "")).text();
}

function decodeHtml(value) {
  return cheerio.load(`<span>${String(value || "")}</span>`)("span").text();
}

function selectEvidenceSentence(text, keywords) {
  const sentences = splitSentences(text);
  const lowerKeywords = keywords.map((keyword) => String(keyword).toLowerCase());
  const hit =
    sentences.find((sentence) =>
      lowerKeywords.some((keyword) => sentence.toLowerCase().includes(keyword))
    ) || sentences[0] || "";
  return normalizeWhitespace(hit).slice(0, 260);
}

function splitSentences(text) {
  return normalizeWhitespace(text)
    .split(/(?<=[.!?。！？])\s+|[;；]\s*/)
    .map((sentence) => sentence.trim())
    .filter(Boolean);
}

function countMatches(text, regex) {
  return (String(text || "").match(regex) || []).length;
}

function normalizeTeamName(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9 ]/g, "")
    .replace(/\b(the|national|team|fc)\b/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeCountryCode(value) {
  return String(value || "").trim().toUpperCase();
}

function teamLookupKeys(value) {
  const base = normalizeTeamName(value);
  const aliases = {
    usa: "united states",
    "u s a": "united states",
    "united states of america": "united states",
    "korea republic": "south korea",
    "republic of korea": "south korea",
    "cote divoire": "ivory coast",
    "cote d ivoire": "ivory coast",
    "turkiye": "turkey",
    "ir iran": "iran",
    "dr congo": "congo dr",
    "congo dr": "dr congo",
    "democratic republic of congo": "congo dr",
    "congo democratic republic": "congo dr",
    "drc": "congo dr",
    "bosnia herzegovina": "bosnia and herzegovina",
    "bosniaherzegovina": "bosnia and herzegovina",
    "bosnia and herzegovina": "bosnia herzegovina",
    "bosnia": "bosnia and herzegovina",
    "bosnia bih": "bosnia and herzegovina",
    "curaao": "curacao",
  };
  const out = new Set([base]);
  if (aliases[base]) {
    out.add(aliases[base]);
    if (aliases[aliases[base]]) out.add(aliases[aliases[base]]);
  }
  for (const [alias, canonical] of Object.entries(aliases)) {
    if (canonical === base || canonical === aliases[base]) out.add(alias);
  }
  return [...out].filter(Boolean);
}

function teamNamesOverlap(left, right) {
  const leftKeys = teamLookupKeys(left);
  const rightKeys = teamLookupKeys(right);
  return leftKeys.some((key) => rightKeys.includes(key));
}

function teamChineseName(code, name) {
  const byCode = TEAM_NAME_ZH[normalizeCountryCode(code)];
  if (byCode) return byCode;
  const normalized = normalizeTeamName(name);
  const byName = Object.entries(TEAM_NAME_ZH).find(([key]) => normalizeTeamName(key) === normalized);
  return byName?.[1] || name || "待定";
}

function teamLabel(team) {
  return team?.displayName || teamChineseName(team?.code, team?.name);
}

function normalizeImpliedProbabilities(market) {
  const home = market.homeAvg ? 1 / market.homeAvg : 0;
  const draw = market.drawAvg ? 1 / market.drawAvg : 0;
  const away = market.awayAvg ? 1 / market.awayAvg : 0;
  const total = home + draw + away || 1;
  return {
    home: home / total,
    draw: draw / total,
    away: away / total,
  };
}

function isHostTeam(teamName, country) {
  const team = normalizeTeamName(teamName);
  const venueCountry = normalizeTeamName(country);
  if (!team || !venueCountry) return false;
  return (
    (venueCountry.includes("mexico") && team === "mexico") ||
    (venueCountry.includes("united states") && team === "united states") ||
    (venueCountry.includes("canada") && team === "canada")
  );
}

function average(values) {
  const clean = values.filter((value) => Number.isFinite(value) && value > 0);
  if (!clean.length) return null;
  return Number((clean.reduce((sum, value) => sum + value, 0) / clean.length).toFixed(3));
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, Number(value) || 0));
}

function logit(probability) {
  const p = clamp(probability, 0.001, 0.999);
  return Math.log(p / (1 - p));
}

function formatSigned(value) {
  const number = Number(value);
  return `${number >= 0 ? "+" : ""}${number.toFixed(2)}`;
}

function confidenceLabel(edge) {
  if (edge >= 0.32) return "高";
  if (edge >= 0.18) return "中高";
  if (edge >= 0.1) return "中";
  return "中低";
}
